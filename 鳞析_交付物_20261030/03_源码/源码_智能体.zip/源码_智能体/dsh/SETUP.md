# 在 DSH 里挂载「鳞析」

目标：用 DSH 的 Web/CLI 作为对话壳，模型走**本地 Ollama** 或**校内 API**，
工具走本仓库的 `python -m fishflow.cli`，技能走 `.dsh/skills/fishflow-guard`。

---

## 0. 前置

```powershell
python -c "import numpy, pandas, pyarrow, matplotlib; print('ok')"
```

如果缺包：

```powershell
python -m pip install numpy pandas pyarrow matplotlib
```

本地模型（可选，但离线演示必须）：

```powershell
ollama pull qwen2.5:7b-instruct
ollama serve
```

---

## 1. 确认 skill 被发现

DSH 的项目根是最近的 `.git` 祖先；没有 `.git` 时用当前目录。
本仓库的 skill 在：

```
<workspace>/.dsh/skills/fishflow-guard/SKILL.md
```

启动 DSH 时把工作目录设为 `<workspace>`（也就是本目录），
在会话的技能目录里应能看到 `fishflow-guard`。

---

## 2. 配置本地模型 / 校内 API

编辑 profile 的 `cordis.patch.yml`（通常在 `$DSH_HOME/profiles/web/`），
加入下面这段（示例见 [`cordis.patch.example.yml`](cordis.patch.example.yml)）：

```yaml
- name: '@deepseek-ai/dsh-llm-pi-ai'
  config:
    providers:
      local:
        displayName: Local Qwen
        api: openai-completions
        baseURL: http://127.0.0.1:11434/v1
        apiKeyEnv: LOCAL_LLM_KEY
        models:
          - id: qwen2.5:7b-instruct
            contextWindow: 32768
      campus:
        displayName: Campus API
        api: openai-completions
        baseURL: https://<校内地址>/v1
        apiKeyEnv: CAMPUS_API_KEY
        models:
          - id: <校内模型 id>
            contextWindow: 131072

# 把 6 个工具挂成原生 MCP 工具（可选；不挂也能用 CLI）
- id: mcp-fishflow
  name: '@deepseek-ai/dsh-mcp-client'
  config:
    serverName: fishflow
    transport: stdio
    command: python
    args: ['-m', 'fishflow.mcp_server']
    cwd: C:/path/to/project
    toolCallTimeoutMs: 900000
```

环境变量（本地无密钥也要占位）：

```powershell
$env:LOCAL_LLM_KEY="ollama"
$env:CAMPUS_API_KEY="<校内 key>"
```

验证配置（不启动）：

```powershell
dsh --profile web --dump-config
```

> 说明：`api: openai-completions` 是 OpenAI 兼容协议；Ollama、vLLM、
> 大多数校内网关都走这个。若校内 API 不是 OpenAI 兼容，需要加一个适配层。

---

## 3. 启动并试问

```powershell
dsh web
```

然后在对话框里：

> 用 fishflow-guard 回答：DMD 能不能外推到 25 秒之后？

期望行为：

1. agent 先调用 `python -m fishflow.cli diagnose --question "..."`；
2. 拿到 JSON 后，按 `answer → evidence → guardrail` 复述；
3. 不自己编数字，不把 A 口径说成绝对精度。

再试：

> 用 fishflow-guard 查探针 17 在 0.1–0.2 s 的压强，并画出来。

期望：调用 `query` + `field`，返回数值和 `outputs/field.png`。

---

## 4. 离线演示（比赛现场）

1. 先 `ollama pull` 好模型，确保 `ollama serve` 本地可跑；
2. 断网（或禁用网卡）；
3. `dsh web` 仍可用：模型走 `127.0.0.1:11434`，工具走本地 Python；
4. 试问三个金牌问题，确认不依赖外网。

> 如果 DSH 的某个插件在启动时探测外网，先在联网状态启动，再断网演示；
> 或在 profile 里禁用 web search / 更新检查。

---

## 5. 常见问题

| 现象 | 处理 |
|---|---|
| 模型列表没有 `local` | 检查 `baseURL` 是否带 `/v1`；`apiKeyEnv` 是否解析到非空值 |
| 技能目录没有 `fishflow-guard` | 确认 cwd 是 workspace 根；`.dsh/skills/fishflow-guard/SKILL.md` 存在 |
| `python -m fishflow.cli` 报 `IndexNotReady` | 先跑 `python -m fishflow.build_index` |
| 首次查询 0.5–0.9 s | 正常，冷启动读盘；热查询 3–5 ms |
| 中文输出乱码 | CLI 已把 stdout 设为 UTF-8；若仍乱码，`chcp 65001` |

---

## 6. MCP（可选，已提供）

`fishflow/mcp_server.py` 是一个无依赖的 stdio MCP server，暴露：

```
diagnose  query  compare  manifest  field  report
```

挂上后，工具会以 `mcp__fishflow__diagnose` 这种名字出现，模型可以直接调用；
不挂也能用 skill 里的 CLI。两种方式参数一致，输出都是 JSON。

自测：

```powershell
python -c "import fishflow.mcp_server as m; print(len(m.TOOLS))"
```

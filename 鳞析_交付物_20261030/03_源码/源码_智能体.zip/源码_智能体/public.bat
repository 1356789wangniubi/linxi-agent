@echo off
cd /d "%~dp0"
chcp 65001 >nul
call "开始公开.bat"

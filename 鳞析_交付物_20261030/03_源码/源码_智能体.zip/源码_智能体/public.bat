@echo off
cd /d "%~dp0"
set "PY=python"
where python >nul 2>nul
if errorlevel 1 set "PY=py -3"

%PY% -c "import socket,sys; s=socket.socket(); s.settimeout(0.4); sys.exit(0 if s.connect_ex(('127.0.0.1',8765))==0 else 1)"
if errorlevel 1 (
  echo Chat server is not running. Start chat_lan.bat first.
  pause
  exit /b
)

set "SSHHOME=%~dp0.sshhome"
if not exist "%SSHHOME%\.ssh" mkdir "%SSHHOME%\.ssh"
set "USERPROFILE=%SSHHOME%"
set "HOME=%SSHHOME%"

echo Starting public tunnel...
echo Keep this window open. The public URL will appear below.
ssh -F NUL -o UserKnownHostsFile="%SSHHOME%\.ssh\known_hosts" -o StrictHostKeyChecking=no -o ServerAliveInterval=30 -o ExitOnForwardFailure=yes -R 80:127.0.0.1:8765 nokey@localhost.run
echo.
pause

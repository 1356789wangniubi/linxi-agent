"""Developer self-test log (not a user trial).

Runs six real commands against the local artifacts, records timings and key
results, and writes validation/selftest_log.jsonl + validation/SELFTEST.md.

Run: python validation/selftest.py
"""

from __future__ import annotations

import json
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "validation"
OUT.mkdir(parents=True, exist_ok=True)

TASKS = [
    ("T1", "DMD 外推护栏", ["diagnose", "--question", "DMD 能不能外推到 25 秒之后？"]),
    ("T2", "A/B 口径护栏", ["diagnose", "--question", "p 的 R² 都 0.99 了，为什么还说压强不准？"]),
    ("T3", "单探针查询", ["query", "--probe", "17", "--t0", "0.1", "--t1", "0.2", "--q", "p"]),
    ("T4", "物理模型对比", ["compare", "--physical", "--quantity", "p", "--trim", "24"]),
    ("T5", "短工况运行", ["run", "--t-end", "0.02", "--freq", "2.0", "--no-compare"]),
    ("T6", "证据报告", ["report"]),
]


def key_result(task_id: str, data: dict | None) -> str:
    if not data:
        return "non-json"
    if task_id in ("T1", "T2"):
        return f"{data.get('matched')} / conf={data.get('confidence')}"
    if task_id == "T3":
        return f"n={data.get('n')} first={data.get('value', [None])[0]}"
    if task_id == "T4":
        return f"A={data.get('A'):.4f} B={data.get('B'):.4f} probes={data.get('probes')}"
    if task_id == "T5":
        return f"{data.get('status')} / {data.get('seconds')}s / {data.get('run_id')}"
    if task_id == "T6":
        return f"{Path(data.get('html', '')).name}"
    return "ok"


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    records = []
    for tid, name, args in TASKS:
        cmd = [sys.executable, "-m", "fishflow.cli", *args]
        t0 = time.time()
        proc = subprocess.run(cmd, cwd=str(ROOT), capture_output=True,
                              text=True, encoding="utf-8", errors="replace")
        seconds = round(time.time() - t0, 2)
        try:
            data = json.loads(proc.stdout)
        except Exception:
            data = None
        rec = {
            "task_id": tid,
            "name": name,
            "command": "python -m fishflow.cli " + " ".join(args),
            "seconds": seconds,
            "returncode": proc.returncode,
            "result": key_result(tid, data),
            "stdout_head": (proc.stdout or "")[:1200],
            "stderr_head": (proc.stderr or "")[:600],
        }
        records.append(rec)
        print(f"{tid} {name:12s} rc={proc.returncode} {seconds:6.2f}s  {rec['result']}")

    with (OUT / "selftest_log.jsonl").open("w", encoding="utf-8") as f:
        for r in records:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

    lines = [
        "# 开发者自测日志",
        "",
        "> 这是本地可复现的**开发者自测**，不是用户试用；不作为“真实用户效果”申报。",
        "",
        "| 任务 | 命令 | 耗时 | 返回码 | 关键结果 |",
        "|---|---|---|---|---|",
    ]
    for r in records:
        lines.append(
            f"| {r['task_id']} {r['name']} | `{r['command']}` | {r['seconds']} s | "
            f"{r['returncode']} | {r['result']} |"
        )
    lines += [
        "",
        "## 复现",
        "",
        "```powershell",
        "python validation/selftest.py",
        "```",
        "",
        "## 说明",
        "",
        "- 所有命令在本机、本地数据上运行；不联网、不读老师原始 1.81 GB 数据。",
        "- T5 的 0.02 s 工况落在启动瞬态内，只验证管线跑通；不能当稳态结论。",
    ]
    (OUT / "SELFTEST.md").write_text("\n".join(lines), encoding="utf-8")
    print(f"wrote {OUT / 'SELFTEST.md'}")
    return 0 if all(r["returncode"] == 0 for r in records) else 1


if __name__ == "__main__":
    raise SystemExit(main())

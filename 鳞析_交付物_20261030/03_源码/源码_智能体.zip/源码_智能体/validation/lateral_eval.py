"""Routing benchmark for the lateral-line knowledge base."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from fishflow import lateral_line

CASES = [
    ("侧线是什么？", "what"),
    ("表浅和管道神经丘有什么区别？", "types"),
    ("侧线能感知什么？", "sense"),
    ("侧线能感知涡吗？", "sense"),
    ("鱼类侧线怎么仿真？", "pipeline"),
    ("传感器模型怎么建？", "sensor_model"),
    ("侧线阵列怎么布置？", "array"),
    ("偶极子源怎么定位？", "dipole"),
    ("鱼自己摆动干扰怎么处理？", "self"),
    ("机器学习在侧线里怎么用？", "ml"),
    ("用什么软件做侧线仿真？", "software"),
    ("我的 404 探针能当侧线用吗？", "probes"),
    ("怎么评估侧线仿真？", "eval"),
    ("最常见的坑是什么？", "pitfalls"),
    ("机器鱼侧线怎么做？", "robot"),
    ("侧线和视觉的区别？", "vs"),
    ("侧线在集群里有什么用？", "behavior"),
]


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ok = 0
    for q, expected in CASES:
        r = lateral_line.answer(q)
        got = r.get("id")
        hit = got == expected
        ok += hit
        print(f"{'OK ' if hit else 'MISS'}  {q}  -> {got} (want {expected})")
    print(f"\n{ok}/{len(CASES)} = {ok/len(CASES)*100:.1f}%")
    return 0 if ok == len(CASES) else 1


if __name__ == "__main__":
    raise SystemExit(main())

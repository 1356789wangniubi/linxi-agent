# 验证状态（哪些是真数据，哪些还没做）

> 原则：**不生成虚假用户日志**。大赛申报表里有诚信承诺，AI 编的“用户试用”一旦被追问就站不住。

## 1. 已完成的真实验证

| 项 | 结果 | 证据 |
|---|---|---|
| 方法学路由 | **15/15** | `python -m fishflow.eval` |
| 开发者自测 | **6/6 任务通过** | [SELFTEST.md](SELFTEST.md)、`selftest_log.jsonl` |
| 单探针查询 | 201 点，热查询 3–5 ms | `BENCHMARK.md` |
| 物理模型一致性 | 与交付包物理表**逐位相同** | `RUN_INTEGRATION.md` |
| 3 Hz 新工况 | 1,001 帧，216 s，A=0.375 / B=−0.023 | `data/runs/20261027_223010_f3` |
| DSH 端到端 | 子 agent 实际调用 CLI，并主动给出瞬态护栏 | 对话记录 / `DEMO.md` |

开发者自测的 6 个任务（真实耗时）：

| 任务 | 耗时 | 结果 |
|---|---|---|
| T1 DMD 外推护栏 | 2.4 s | `dmd_no_extrapolation` |
| T2 A/B 口径护栏 | 2.5 s | `metric_ab` |
| T3 单探针查询 | 4.0 s | 201 点 |
| T4 物理模型对比 | 4.6 s | A=0.4427 / trim24 |
| T5 短工况运行 | 21.0 s | status=ok |
| T6 证据报告 | 6.4 s | `guard_report.html` |

## 2. 还没做（需要真人）

| 项 | 状态 | 怎么做 |
|---|---|---|
| 5–10 人用户试用 | **未做** | 按 [TRIAL_KIT.md](TRIAL_KIT.md)，每人 30 分钟 |
| SUS 可用性评分 | **未做** | 填 `sus_form.csv`，跑 `analyze_trial.py` |
| 3 分钟 MP4 | **没生成** | 见下方说明 |

## 3. 为什么没有“AI 生成的使用日志”

- 申报表诚信承诺：信息真实、不抄袭；
- 评委常追问“日志原始表”“参与者编号”“当场复现”；
- 编造数据会毁掉整个项目的可信度，而“可信”正是这个项目的卖点。

**可以做替代：**

1. 把 [SELFTEST.md](SELFTEST.md) 作为“开发者自测”写进材料，明确标注不是用户试用；
2. 找 5 位同学，按 [TRIAL_KIT.md](TRIAL_KIT.md) 跑 30 分钟，就有真实日志；
3. 只做 5 人也如实写 5 人，不要写 10 人。

## 4. 视频状态

- 已生成 **[demo_reel.gif](outputs/demo_reel.gif)**：28 秒、8 页、800×450，可直接播放/发微信；
- 已生成 **`outputs/demo_reel.avi`**：28 秒、MJPEG、8.4 MB，Windows 上用 VLC/PotPlayer 最稳；
- 已生成 **`outputs/demo_reel.mp4`**：同一内容，MJPEG-in-MP4（不是 H.264）；
- 已生成 **[guard_report.html](outputs/guard_report.html)**：单文件，图/动画内嵌；
- 说明：当前环境的 ffmpeg 只有 MJPEG 编码器，没有 x264；所以 MP4 不是通用 H.264。
  如果播放器不认，用 GIF，或在别的机器上 `ffmpeg -i demo_reel.avi -c:v libx264 ...` 转一次。

## 5. 一句话

> 真的部分已经跑出来了；假的部分我不做。
> 你只需要找 5 个人、花 30 分钟，试用日志就是真的。

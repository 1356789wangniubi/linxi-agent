# 开发者自测日志

> 这是本地可复现的**开发者自测**，不是用户试用；不作为“真实用户效果”申报。

| 任务 | 命令 | 耗时 | 返回码 | 关键结果 |
|---|---|---|---|---|
| T1 DMD 外推护栏 | `python -m fishflow.cli diagnose --question DMD 能不能外推到 25 秒之后？` | 2.42 s | 0 | dmd_no_extrapolation / conf=0.81 |
| T2 A/B 口径护栏 | `python -m fishflow.cli diagnose --question p 的 R² 都 0.99 了，为什么还说压强不准？` | 2.47 s | 0 | metric_ab / conf=0.58 |
| T3 单探针查询 | `python -m fishflow.cli query --probe 17 --t0 0.1 --t1 0.2 --q p` | 4.01 s | 0 | n=201 first=-0.6453085499 |
| T4 物理模型对比 | `python -m fishflow.cli compare --physical --quantity p --trim 24` | 4.64 s | 0 | A=0.4427 B=0.0075 probes=308 |
| T5 短工况运行 | `python -m fishflow.cli run --t-end 0.02 --freq 2.0 --no-compare` | 21.04 s | 0 | ok / 7.0s / 20261028_151521_f2 |
| T6 证据报告 | `python -m fishflow.cli report` | 6.37 s | 0 | guard_report.html |

## 复现

```powershell
python validation/selftest.py
```

## 说明

- 所有命令在本机、本地数据上运行；不联网、不读老师原始 1.81 GB 数据。
- T5 的 0.02 s 工况落在启动瞬态内，只验证管线跑通；不能当稳态结论。
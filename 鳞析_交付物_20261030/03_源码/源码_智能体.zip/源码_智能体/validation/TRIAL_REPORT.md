# 用户试用报告

还没有真实试用数据。

请按 `validation/TRIAL_KIT.md` 找 5–10 名同学，把结果填进
`validation/trial_form.csv` 和 `validation/sus_form.csv`，再运行本脚本。

**不要用 AI 生成的日志代替真实用户数据。**

"""Analyze real user-trial logs. Never invents rows.

Inputs (fill with real participants):
  validation/trial_form.csv  participant_id,role,task_id,success,seconds,notes
  validation/sus_form.csv    participant_id,q1..q10  (1..5)

Output:
  validation/TRIAL_REPORT.md
"""

from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
VAL = ROOT / "validation"
TRIAL = VAL / "trial_form.csv"
SUS = VAL / "sus_form.csv"
OUT = VAL / "TRIAL_REPORT.md"

TASKS = {
    "T1": "DMD 外推护栏",
    "T2": "A/B 口径护栏",
    "T3": "单探针查询",
    "T4": "物理模型对比",
    "T5": "短工况运行",
    "T6": "证据报告",
}


def sus_score(row: pd.Series) -> float:
    total = 0
    for i in range(1, 11):
        v = int(row[f"q{i}"])
        total += (v - 1) if i % 2 == 1 else (5 - v)
    return total * 2.5


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    lines = ["# 用户试用报告", ""]
    if not TRIAL.exists():
        print("missing", TRIAL)
        return 1
    df = pd.read_csv(TRIAL)
    df = df.dropna(subset=["participant_id", "task_id"])
    if df.empty:
        msg = (
            "还没有真实试用数据。\n\n"
            "请按 `validation/TRIAL_KIT.md` 找 5–10 名同学，把结果填进\n"
            "`validation/trial_form.csv` 和 `validation/sus_form.csv`，再运行本脚本。\n\n"
            "**不要用 AI 生成的日志代替真实用户数据。**\n"
        )
        (VAL / "TRIAL_REPORT.md").write_text("# 用户试用报告\n\n" + msg, encoding="utf-8")
        print(msg)
        return 0

    n_people = df["participant_id"].nunique()
    lines += [f"- 参与人数：**{n_people}**", f"- 任务记录：**{len(df)}** 条", ""]
    lines += ["## 分任务", "", "| 任务 | 完成率 | 平均耗时 | 样本 |", "|---|---|---|---|"]
    for tid, name in TASKS.items():
        sub = df[df["task_id"] == tid]
        if sub.empty:
            lines.append(f"| {tid} {name} | — | — | 0 |")
            continue
        rate = float(sub["success"].mean())
        secs = float(sub["seconds"].mean())
        lines.append(f"| {tid} {name} | {rate:.0%} | {secs:.0f} s | {len(sub)} |")

    overall = float(df["success"].mean())
    lines += ["", f"**总体完成率：{overall:.0%}**", ""]

    if SUS.exists():
        sus = pd.read_csv(SUS).dropna(subset=["participant_id"])
        if not sus.empty:
            scores = sus.apply(sus_score, axis=1)
            lines += [
                "## SUS 可用性",
                "",
                f"- 人数：**{len(sus)}**",
                f"- 均分：**{scores.mean():.1f} / 100**",
                f"- 范围：{scores.min():.1f} – {scores.max():.1f}",
                "",
            ]
        else:
            lines += ["## SUS 可用性", "", "尚未填写。", ""]

    lines += [
        "## 备注",
        "",
        "- 数据来自 `validation/trial_form.csv` / `sus_form.csv`；本脚本不生成任何行。",
        "- 若样本 < 5，请在申报材料中如实写“初步试用”。",
    ]
    OUT.write_text("\n".join(lines), encoding="utf-8")
    print("\n".join(lines))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

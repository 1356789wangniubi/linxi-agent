@echo off
cd /d "%~dp0"
set "PY=python"
where python >nul 2>nul
if errorlevel 1 set "PY=py -3"
echo ============================================
echo    LinXi - Bionic Fish Flow Guard Agent
echo ============================================
%PY% -m fishflow.cli doctor
%PY% -m fishflow.demo --open
if errorlevel 1 echo [ERROR] Failed. Check Python and dependencies.
echo.
pause

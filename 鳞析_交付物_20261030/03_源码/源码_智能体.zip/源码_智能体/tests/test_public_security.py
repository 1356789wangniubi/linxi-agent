"""Security regression tests; no remote API calls or real credentials."""
import base64
import http.client
import io
import json
from pathlib import Path
import sys
import threading

import pytest
from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from fishflow import agent, chat, chat_server as server, image_tool, public_launcher

CODE = "unit-test-access-code-only"


@pytest.fixture(autouse=True)
def reset_state(monkeypatch):
    for name in ("FISHFLOW_ACCESS_CODE", "FISHFLOW_LLM_KEY", "ZHIPU_API_KEY", "FISHFLOW_LLM_URL"):
        monkeypatch.delenv(name, raising=False)
    server._REQUEST_TIMES.clear()
    monkeypatch.setattr(server, "_WORKERS", threading.BoundedSemaphore(1))


@pytest.fixture
def endpoint(tmp_path, monkeypatch):
    monkeypatch.setattr(server, "OUT", tmp_path)
    class AuthHandler(server.Handler):
        access_code = CODE
    instance = server.BoundedHTTPServer(("127.0.0.1", 0), AuthHandler)
    worker = threading.Thread(target=instance.serve_forever, daemon=True)
    worker.start()
    def request(path="/api/chat", data=None, *, authorized=True, origin=None, method="POST", headers=None):
        connection = http.client.HTTPConnection("127.0.0.1", instance.server_port, timeout=3)
        hdr = {"Content-Type": "application/json"}
        if authorized:
            hdr["Authorization"] = "Basic " + base64.b64encode(f"fish:{CODE}".encode()).decode()
        if origin:
            hdr["Origin"] = origin
        hdr.update(headers or {})
        body = json.dumps(data or {}) if method == "POST" else None
        connection.request(method, path, body=body, headers=hdr)
        response = connection.getresponse()
        payload = response.read()
        result = response.status, payload, dict(response.getheaders())
        connection.close()
        return result
    request.port = instance.server_port
    yield request
    instance.shutdown()
    instance.server_close()
    worker.join(timeout=3)


def test_unauthenticated_clients_cannot_call_model(endpoint, monkeypatch):
    monkeypatch.setattr(chat, "answer", lambda *a: pytest.fail("unauthenticated tool call"))
    assert endpoint(data={"message": "hello"}, authorized=False)[0] == 401
    assert endpoint(data={"message": "hello"}, headers={"Authorization": "Basic invalid"})[0] == 401
    assert endpoint("/api/health", method="GET", authorized=False)[0] == 200


def test_public_startup_rejects_missing_or_short_code(monkeypatch):
    for code in ("", "short-test-code"):
        monkeypatch.setenv("FISHFLOW_ACCESS_CODE", code)
        monkeypatch.setattr(sys, "argv", ["chat_server", "--host", "0.0.0.0", "--no-open"])
        with pytest.raises(SystemExit) as exc:
            server.main()
        assert exc.value.code == 2


def test_rate_limits_and_window_expiry(monkeypatch):
    now = [0.0]
    monkeypatch.setattr(server.time, "monotonic", lambda: now[0])
    assert all(server._allow_work() for _ in range(6))
    assert not server._allow_work()
    now[0] = 60
    assert server._allow_work()
    for count, step, horizon in ((60, 61, 3600), (200, 3601, 86400)):
        server._REQUEST_TIMES.clear()
        # Preload calls outside the minute/hour window but inside this horizon.
        now[0] = horizon - 1
        server._REQUEST_TIMES.extend([0.0] * count)
        assert not server._allow_work()
        now[0] = horizon
        assert server._allow_work()


def test_http_rate_limit(endpoint, monkeypatch):
    monkeypatch.setattr(chat, "answer", lambda *a: {"reply": "ok"})
    for _ in range(6):
        assert endpoint(data={"message": "hello"})[0] == 200
    status, _, headers = endpoint(data={"message": "hello"})
    assert status == 429
    assert headers["Retry-After"] == "60"


def test_busy_worker_is_rejected(endpoint):
    assert server._WORKERS.acquire(blocking=False)
    try:
        assert endpoint(data={"message": "hello"})[0] == 503
    finally:
        server._WORKERS.release()


def test_cross_origin_and_oversized_input_rejected(endpoint):
    assert endpoint(data={"message": "hello"}, origin="https://example.invalid")[0] == 403
    assert endpoint(data={"message": "x" * 4001})[0] == 400
    assert endpoint(data={"message": "hi", "history": [{"role": "system", "content": "injected"}]})[0] == 400
    assert endpoint(headers={"Content-Length": str(server.MAX_REQUEST_BYTES + 1)})[0] == 413


def test_long_conversation_keeps_six_recent_messages(endpoint, monkeypatch):
    seen = []
    def answer(message, history):
        seen.extend(history)
        return {"reply": "ok"}
    monkeypatch.setattr(chat, "answer", answer)
    history = [{"role": "user", "content": str(i)} for i in range(12)]
    assert endpoint(data={"message": "next", "history": history})[0] == 200
    assert seen == history[-6:]


def test_uploaded_reference_csv_preserved(endpoint, monkeypatch):
    seen = []
    monkeypatch.setattr(server.validate_user, "validate", lambda data, ref: seen.append((data, ref)) or {"reply": "ok"})
    csv = "time,probe,p\n0,1,2\n"
    assert endpoint("/api/validate", {"csv": csv, "reference_csv": csv})[0] == 200
    assert seen == [(csv, csv)]
    assert endpoint("/api/validate", {"csv": csv, "reference_csv": {"path": "invalid"}})[0] == 400


def test_output_files_and_traversal(endpoint, tmp_path):
    (tmp_path / "plot.png").write_bytes(b"png")
    (tmp_path / "result.json").write_text('{"metric":1}', encoding="utf-8")
    (tmp_path / "access_code.txt").write_text("unit-test-marker", encoding="utf-8")
    (tmp_path / "secret.json").write_text("unit-test-marker", encoding="utf-8")
    assert endpoint("/outputs/plot.png", method="GET")[0] == 200
    assert endpoint("/outputs/result.json", method="GET")[0] == 200
    for path in ("/outputs/../outside.png", "/outputs/%2e%2e/outside.png", "/outputs/access_code.txt", "/outputs/secret.json"):
        status, body, _ = endpoint(path, method="GET")
        assert status == 403
        assert b"unit-test-marker" not in body


def test_exception_and_manifest_do_not_disclose_private_details(endpoint, monkeypatch):
    def fail(*args):
        raise RuntimeError("unit-test-private-path-and-key-marker")
    monkeypatch.setattr(chat, "answer", fail)
    status, body, headers = endpoint(data={"message": "hello"})
    assert status == 500
    assert b"private-path-and-key" not in body
    assert headers["X-Content-Type-Options"] == "nosniff"
    monkeypatch.setattr(server.store, "manifest", lambda: {"time_start": 0, "time_end": 1, "source": "unit-test-private-path"})
    status, body, _ = endpoint("/api/range", method="GET")
    assert status == 200
    assert "source" not in json.loads(body)


def test_large_decoded_image_rejected():
    image = Image.new("RGB", (2001, 2000))
    buf = io.BytesIO()
    image.save(buf, format="PNG")
    with pytest.raises(ValueError, match="400"):
        image_tool._decode(base64.b64encode(buf.getvalue()).decode())


def test_access_codes_are_generated_locally_and_old_short_codes_fail(tmp_path):
    code = public_launcher.access_code(tmp_path)
    assert len(code) >= 24
    assert public_launcher.access_code(tmp_path) == code
    (tmp_path / "secrets" / "access_code.txt").write_text("old-test-code", encoding="utf-8")
    with pytest.raises(ValueError):
        public_launcher.access_code(tmp_path)


def test_launcher_refuses_existing_listener(monkeypatch):
    monkeypatch.setattr(sys, "argv", ["public_launcher"])
    monkeypatch.setattr(public_launcher, "port_in_use", lambda port: True)
    monkeypatch.setattr(public_launcher.subprocess, "Popen", lambda *a, **k: pytest.fail("opened a process"))
    monkeypatch.setattr(public_launcher, "access_code", lambda: pytest.fail("changed credentials"))
    assert public_launcher.main() == 1


def test_launcher_verifies_both_authentication_paths(endpoint):
    assert public_launcher.verify_auth(endpoint.port, CODE)
    with pytest.raises(Exception):
        public_launcher.verify_auth(endpoint.port, "wrong-test-access-code")


@pytest.mark.parametrize("module", [chat, agent])
def test_llm_key_stays_in_server_header_and_generation_is_bounded(module, monkeypatch):
    monkeypatch.setenv("FISHFLOW_LLM_URL", "https://open.bigmodel.cn/api/paas/v4/chat/completions")
    monkeypatch.setenv("FISHFLOW_LLM_KEY", "unit-test-key")
    monkeypatch.setenv("FISHFLOW_LLM_MODEL", "glm-5.3-flash")
    def response(request, **kwargs):
        body = json.loads(request.data)
        assert body["model"] == "glm-5.3-flash"
        assert body["max_tokens"] == 1024
        assert b"unit-test-key" not in request.data
        assert request.get_header("Authorization") == "Bearer unit-test-key"
        class Reply(io.BytesIO):
            pass
        return Reply(json.dumps({"choices": [{"message": {"content": "OK"}}]}).encode())
    monkeypatch.setattr(module.urllib.request, "urlopen", response)
    result = chat._llm("hello", []) if module is chat else agent._llm([{"role": "user", "content": "hello"}])
    assert result == "OK"

"""Plain-assert smoke tests (no pytest needed).

Run: python tests/test_guard.py
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from fishflow import diagnose, metrics, store  # noqa: E402


def test_diagnose_routes():
    cases = {
        "DMD 能不能外推到 25 秒之后？": "dmd_no_extrapolation",
        "p 的 R² 都 0.99 了，为什么还说压强不准？": "metric_ab",
        "u_x 为什么卡在 0.83？": "hankel_pitfalls",
        "首帧要不要剔除？": "trim_rules",
        "鼻尖探针怎么处理？": "cusp_probes",
        "物理模型和 DMD 选哪个？": "method_choice",
        "物理模型和 DMD 差多少？": "physical_run_gap",
    }
    for q, expected in cases.items():
        r = diagnose.answer(q)
        assert r["status"] == "ok", (q, r)
        assert r["matched"] == expected, (q, r["matched"], expected)
        assert r["evidence"], q
    print(f"diagnose routes: {len(cases)} ok")


def test_metrics():
    rows = metrics.table()
    assert len(rows) == 6, rows
    assert abs(metrics.mean_scores()["dmd_v2"]["A"] - 0.9842) < 0.001
    assert abs(metrics.mean_scores()["dmd_v2"]["B"] - 0.9630) < 0.001
    print("metrics: 6 rows, means ok")


def test_index_and_query():
    m = store.manifest()
    assert m["n_frames"] == 49800, m
    assert m["n_rows"] == 20119200, m
    d = store.query(17, 0.1, 0.2, "p")
    assert d["n"] == 201, d["n"]
    assert abs(d["time"][0] - 0.1) < 1e-9
    assert abs(d["time"][-1] - 0.2) < 1e-9
    print(f"index: {m['n_rows']:,} rows; query: {d['n']} points")


def test_frame():
    f = store.frame_at(0.2)
    assert len(f["p"]) == 404, len(f["p"])
    assert abs(f["time"] - 0.2) < 1e-9
    print("frame: 404 probes at t=0.2")


def test_physical():
    from fishflow import compare, config
    m = store.manifest(config.INDEX_PHYSICAL)
    assert m["n_frames"] == 1001, m
    assert m["n_rows"] == 404404, m
    r = compare.compare_physical("p", trim=24)
    assert r["probes"] == 308, r
    assert 0.35 < r["A"] < 0.55, r
    print(f"physical: {m['n_frames']} frames; A(trim24)={r['A']:.3f}")


if __name__ == "__main__":
    test_diagnose_routes()
    test_metrics()
    test_index_and_query()
    test_frame()
    test_physical()
    print("ALL OK")

"""JSON-first CLI used by the DSH skill and by humans.

Examples:
    python -m fishflow.cli manifest
    python -m fishflow.cli query --probe 17 --t0 0.1 --t1 0.2
    python -m fishflow.cli field --t 0.2 --q p --out outputs/field.png
    python -m fishflow.cli diagnose --question "DMD 能不能外推到 25 秒之后？"
    python -m fishflow.cli report
"""

from __future__ import annotations

import argparse
import json
import sys
import threading
import time

from . import config, diagnose, metrics, plots, provenance, report, store


def _index_for(dataset: str):
    return config.INDEX_PHYSICAL if dataset == "physical_run" else config.INDEX


def _print(obj) -> None:
    print(json.dumps(obj, ensure_ascii=False, indent=1))


def main(argv=None) -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    p = argparse.ArgumentParser(prog="fishflow")
    sub = p.add_subparsers(dest="cmd", required=True)

    sub.add_parser("manifest")
    sub.add_parser("doctor")
    sub.add_parser("repl")
    sub.add_parser("topics")
    c = sub.add_parser("compare")
    c.add_argument("--physical", action="store_true", help="compare DMD v2 vs 可运行 physical output")
    c.add_argument("--quantity", default="p", choices=["p", "ux", "uy"])
    c.add_argument("--trim", type=int, default=0, help="drop N probes at nose/tail per surface")

    q = sub.add_parser("query")
    q.add_argument("--probe", type=int, required=True)
    q.add_argument("--t0", type=float, default=0.1)
    q.add_argument("--t1", type=float, default=0.2)
    q.add_argument("--q", default="p", choices=["p", "ux", "uy", "x", "y"])
    q.add_argument("--dataset", default="dmd_v2", choices=["dmd_v2", "physical_run"])

    f = sub.add_parser("field")
    f.add_argument("--t", type=float, default=0.2)
    f.add_argument("--q", default="p", choices=["p", "ux", "uy"])
    f.add_argument("--out", default="outputs/field.png")
    f.add_argument("--dataset", default="dmd_v2", choices=["dmd_v2", "physical_run"])

    d = sub.add_parser("diagnose")
    d.add_argument("--question", required=True)

    s = sub.add_parser("series")
    s.add_argument("--probe", type=int, default=17)
    s.add_argument("--q", default="p", choices=["p", "ux", "uy"])
    s.add_argument("--t0", type=float, default=0.1)
    s.add_argument("--t1", type=float, default=2.0)
    s.add_argument("--out", default="outputs/series.png")
    s.add_argument("--dataset", default="dmd_v2", choices=["dmd_v2", "physical_run"])

    sub.add_parser("report")
    sub.add_parser("runs")

    rsr = sub.add_parser("research")
    rsr.add_argument("--goal", default="extrapolation",
                     choices=["extrapolation", "gap", "quality"])
    rsr.add_argument("--freq", type=float, default=3.0)
    rsr.add_argument("--t-end", type=float, default=1.0)
    rsr.add_argument("--dt", type=float, default=0.001)
    rsr.add_argument("--trim", type=int, default=24)
    rsr.add_argument("--quantity", default="p", choices=["p", "ux", "uy"])
    rsr.add_argument("--execute", action="store_true")
    rsr.add_argument("--run-dir", default=None)

    rlog = sub.add_parser("research-log")
    rlog.add_argument("--n", type=int, default=10)

    rs = sub.add_parser("run-status")
    rs.add_argument("run_id", nargs="?", default=None)

    rl = sub.add_parser("run-logs")
    rl.add_argument("run_id")
    rl.add_argument("--tail", type=int, default=60)

    r = sub.add_parser("run")
    r.add_argument("--freq", type=float, default=2.0)
    r.add_argument("--t-end", type=float, default=1.0)
    r.add_argument("--dt", type=float, default=0.001)
    r.add_argument("--quantity", default="p", choices=["p", "ux", "uy"])
    r.add_argument("--trim", type=int, default=24)
    r.add_argument("--timeout", type=float, default=900.0)
    r.add_argument("--no-compare", action="store_true")
    r.add_argument("--background", action="store_true")
    r.add_argument("--progress", action="store_true", help="print live progress lines")

    ev = sub.add_parser("evidence")
    ev.add_argument("--n", type=int, default=10)

    args = p.parse_args(argv)
    config.ensure_dirs()

    try:
        if args.cmd == "manifest":
            m = dict(store.manifest())
            m.pop("files", None)
            _print(m)
        elif args.cmd == "doctor":
            from .doctor import main as doctor_main
            return doctor_main()
        elif args.cmd == "repl":
            from .repl import main as repl_main
            return repl_main()
        elif args.cmd == "topics":
            from .knowledge import topics
            _print({"topics": topics()})
        elif args.cmd == "compare":
            if args.physical:
                from . import compare as cmp
                _print(cmp.compare_physical(args.quantity, args.trim))
            else:
                _print({"rows": metrics.table(), "mean": metrics.mean_scores(),
                        "definitions": {"A": "per-frame spatial corr² (shape)",
                                        "B": "1 - SSE/SST (absolute)"}})
        elif args.cmd == "query":
            _print(store.query(args.probe, args.t0, args.t1, args.q,
                               index_dir=_index_for(args.dataset)))
        elif args.cmd == "field":
            out = plots.field_plot(args.t, args.q, args.out,
                                   index_dir=_index_for(args.dataset))
            _print({"figure": str(out), "t": store.nearest_time(args.t, _index_for(args.dataset)),
                    "quantity": args.q, "dataset": args.dataset})
        elif args.cmd == "diagnose":
            _print(diagnose.answer(args.question))
        elif args.cmd == "series":
            out = plots.series_plot(args.probe, args.q, args.t0, args.t1, args.out,
                                    index_dir=_index_for(args.dataset))
            _print({"figure": str(out), "probe": args.probe, "quantity": args.q,
                    "dataset": args.dataset})
        elif args.cmd == "report":
            _print(report.build())
        elif args.cmd == "runs":
            from . import runner
            _print({"runs": runner.list_runs()})
        elif args.cmd == "research":
            from . import research as research_mod
            _print(research_mod.research(
                goal=args.goal, freq=args.freq, t_end=args.t_end, dt=args.dt,
                trim=args.trim, quantity=args.quantity,
                execute=args.execute, run_dir=args.run_dir,
            ))
        elif args.cmd == "research-log":
            from . import research as research_mod
            _print({"records": research_mod.log(args.n)})
        elif args.cmd == "run-status":
            from . import runner
            _print(runner.status(args.run_id))
        elif args.cmd == "run-logs":
            from . import runner
            _print({"run_id": args.run_id, "log": runner.logs(args.run_id, args.tail)})
        elif args.cmd == "run":
            from . import runner
            if args.background:
                _print(runner.start_background(
                    freq=args.freq, t_end=args.t_end, dt=args.dt,
                    do_compare=not args.no_compare, quantity=args.quantity,
                    trim=args.trim,
                ))
            elif args.progress:
                run_dir = runner._new_run_dir(args.freq)
                result = {}

                def work():
                    result.update(runner.run_physical(
                        freq=args.freq, t_end=args.t_end, dt=args.dt,
                        do_compare=not args.no_compare, quantity=args.quantity,
                        trim=args.trim, timeout=args.timeout, run_dir=run_dir,
                    ))

                th = threading.Thread(target=work, daemon=True)
                th.start()
                last = None
                while th.is_alive():
                    prog = runner._read_json(run_dir / "progress.json")
                    if prog and prog.get("step") != last:
                        print(f"[run {run_dir.name}] {prog.get('percent', 0):5.1f}%  "
                              f"{prog.get('step')}/{prog.get('total')}  "
                              f"{prog.get('elapsed_s', 0)}s", flush=True)
                        last = prog.get("step")
                    time.sleep(1.5)
                th.join()
                _print(result)
            else:
                _print(runner.run_physical(
                    freq=args.freq, t_end=args.t_end, dt=args.dt,
                    do_compare=not args.no_compare, quantity=args.quantity,
                    trim=args.trim, timeout=args.timeout,
                ))
        elif args.cmd == "evidence":
            _print({"records": provenance.last(args.n)})
    except store.IndexNotReady as exc:
        _print({"error": "index_not_ready", "message": str(exc)})
        return 2
    except Exception as exc:
        _print({"error": type(exc).__name__, "message": str(exc)})
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())

"""Evaluate the panel-method velocity on a 2-D grid and compute true ω_z.

This is the physical model's own field, not a pressure proxy.  Important:
the solver is potential flow + a bound vortex sheet, so the *external* field is
irrotational; vorticity is concentrated in the body vortex sheet / trailing
edge.  The plot says this explicitly instead of pretending it is CFD wake
vorticity.
"""

from __future__ import annotations

import sys
import time
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib import font_manager
from scipy.spatial import cKDTree

for _name in ("Microsoft YaHei", "SimHei", "DejaVu Sans"):
    try:
        font_manager.findfont(_name, fallback_to_default=False)
        plt.rcParams["font.sans-serif"] = [_name]
        break
    except Exception:
        continue
plt.rcParams["axes.unicode_minus"] = False

from . import config

RUN = config.ROOT / "可运行"
sys.path.insert(0, str(RUN))

from fish_model import UnsteadyFishModel  # noqa: E402
from source_panel import UnsteadyPanelSolver  # noqa: E402

_CACHE: dict[tuple, dict] = {}


def _grid(panel_state):
    verts = panel_state["vertices"][:-1, 0, :2]
    x0, x1 = float(verts[:, 0].min()), float(verts[:, 0].max())
    y0, y1 = float(verts[:, 1].min()), float(verts[:, 1].max())
    pad_x, pad_y = 0.35, 0.28
    xs = np.linspace(x0 - pad_x, x1 + pad_x, 170)
    ys = np.linspace(y0 - pad_y, y1 + pad_y, 120)
    gx, gy = np.meshgrid(xs, ys)
    return gx, gy, verts


def compute(t_target: float = 0.2, freq: float = 2.0, u_inf: float = 1.0,
            length: float = 1.0, dt: float = 0.001, n_side: int = 202) -> dict:
    key = (round(t_target, 5), freq, u_inf, length, dt, n_side)
    if key in _CACHE:
        return _CACHE[key]

    model = UnsteadyFishModel(length=length, n_side=n_side)
    solver = UnsteadyPanelSolver(rho=1000.0, u_inf=u_inf, pressure_unit="kinematic")
    warm = model.generate_surface_state(-dt, u_inf=u_inf, freq=freq)
    solver.step(-dt, warm)

    state = None
    flow = None
    nsteps = int(round(t_target / dt))
    for k in range(1, nsteps + 1):
        t = k * dt
        state = model.generate_surface_state(t, u_inf=u_inf, freq=freq)
        flow = solver.step(t, state)
    if state is None or flow is None:
        raise ValueError("t_target 太小")

    verts = state["vertices"][:-1, 0, :2]
    nxt = state["vertices"][1:, 0, :2]
    verts3 = np.column_stack([verts, np.zeros(len(verts))])
    nxt3 = np.column_stack([nxt, np.zeros(len(nxt))])
    sigma = flow["sigma"]
    gamma = float(flow["gamma"])
    gx, gy, _ = _grid(state)
    pts = np.column_stack([gx.ravel(), gy.ravel(), np.zeros(gx.size)])

    ux = np.empty(gx.size)
    uy = np.empty(gx.size)
    chunk = 1500
    for i in range(0, gx.size, chunk):
        p = pts[i:i + chunk]
        ind_v, _, ind_w, _, _ = solver._kernels(p, verts3, nxt3)
        v = np.einsum("ijk,j->ik", ind_v, sigma)
        v += gamma * ind_w.sum(axis=1)
        ux[i:i + chunk] = u_inf + v[:, 0]
        uy[i:i + chunk] = v[:, 1]
    ux = ux.reshape(gx.shape)
    uy = uy.reshape(gx.shape)

    dx = float(gx[0, 1] - gx[0, 0])
    dy = float(gy[1, 0] - gy[0, 0])
    omega = np.gradient(uy, dx, axis=1) - np.gradient(ux, dy, axis=0)

    tree = cKDTree(verts)
    dist, _ = tree.query(np.column_stack([gx.ravel(), gy.ravel()]))
    near = dist.reshape(gx.shape) < 0.018
    omega_plot = np.where(near, np.nan, omega)

    vmax = float(np.nanpercentile(np.abs(omega_plot), 99)) if np.isfinite(omega_plot).any() else 1.0
    speed = np.hypot(ux, uy)
    out = config.OUTPUTS / f"physical_vorticity_{str(t_target).replace('.', 'p')}.png"
    fig, axes = plt.subplots(1, 2, figsize=(11.5, 4.2), gridspec_kw={"width_ratios": [1, 1]})
    ax = axes[0]
    sc = ax.pcolormesh(gx, gy, speed, cmap="viridis", shading="gouraud")
    ax.quiver(gx[::10, ::10], gy[::10, ::10], ux[::10, ::10], uy[::10, ::10],
              color="w", alpha=0.55, scale=14, width=0.0015)
    ax.plot(verts[:, 0], verts[:, 1], color="k", lw=1.0)
    ax.set_aspect("equal")
    ax.set_title(f"物理模型速度场 |u|，t≈{t_target:.3f}s")
    ax.set_xlabel("x [m]"); ax.set_ylabel("y [m]")
    fig.colorbar(sc, ax=ax, fraction=0.035, pad=0.02, label="|u| [m/s]")

    ax = axes[1]
    vv = max(vmax, 1e-9)
    im = ax.pcolormesh(gx, gy, omega_plot, cmap="RdBu_r", vmin=-vv, vmax=vv, shading="gouraud")
    ax.plot(verts[:, 0], verts[:, 1], color="k", lw=1.0)
    ax.set_aspect("equal")
    ax.set_title("真涡量场 ω_z = ∂u_y/∂x − ∂u_x/∂y")
    ax.set_xlabel("x [m]"); ax.set_ylabel("y [m]")
    fig.colorbar(im, ax=ax, fraction=0.035, pad=0.02, label="ω_z [1/s]")
    fig.tight_layout(); fig.savefig(out, dpi=170); plt.close(fig)

    result = {
        "figure": out.name,
        "gamma": gamma,
        "max_omega": float(np.nanmax(np.abs(omega_plot))) if np.isfinite(omega_plot).any() else 0.0,
        "median_omega": float(np.nanmedian(np.abs(omega_plot))) if np.isfinite(omega_plot).any() else 0.0,
        "t": t_target,
        "grid": [int(gx.shape[1]), int(gx.shape[0])],
        "elapsed": None,
    }
    _CACHE[key] = result
    return result


def make(t_target: float = 0.2):
    t0 = time.time()
    r = compute(t_target)
    r = dict(r)
    r["elapsed"] = round(time.time() - t0, 1)
    return r

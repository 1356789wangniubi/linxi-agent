"""Image -> fish silhouette -> guided lateral-line simulation.

No deep learning: alpha channel or Otsu threshold + largest connected component.
The user supplies the real body length; the image supplies the height/length
ratio and outline.  It is a fast MVP, not a trained segmenter.
"""

from __future__ import annotations

import base64
import io
import time
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image
from scipy import ndimage

from . import config, sim_agent

OUT = config.OUTPUTS


def _decode(data_url: str) -> Image.Image:
    if "," in data_url:
        data_url = data_url.split(",", 1)[1]
    raw = base64.b64decode(data_url)
    img = Image.open(io.BytesIO(raw))
    if img.width * img.height > 4_000_000:
        raise ValueError("图片最多400万像素，请先缩小图片")
    return img.convert("RGBA")


def _otsu(gray: np.ndarray) -> int:
    hist, _ = np.histogram(gray, bins=256, range=(0, 256))
    total = gray.size
    sum_all = np.dot(np.arange(256), hist)
    sum_b = 0.0
    w_b = 0.0
    best = 0
    best_var = -1.0
    for i in range(256):
        w_b += hist[i]
        if w_b == 0:
            continue
        w_f = total - w_b
        if w_f == 0:
            break
        sum_b += i * hist[i]
        m_b = sum_b / w_b
        m_f = (sum_all - sum_b) / w_f
        var = w_b * w_f * (m_b - m_f) ** 2
        if var > best_var:
            best_var = var
            best = i
    return best


def segment(img: Image.Image) -> tuple[np.ndarray, np.ndarray]:
    arr = np.asarray(img)
    rgba = arr.astype(float)
    alpha = rgba[..., 3]
    if np.any(alpha < 250):
        mask = alpha > 30
    else:
        gray = np.asarray(img.convert("L"))
        border = np.concatenate([gray[:8].ravel(), gray[-8:].ravel(),
                                 gray[:, :8].ravel(), gray[:, -8:].ravel()])
        bm = float(np.median(border))
        if bm > 128:
            mask = gray < min(240.0, bm * 0.8)
        else:
            mask = gray > max(15.0, bm * 1.2)
        mask = ndimage.binary_opening(mask, iterations=2)
        mask = ndimage.binary_closing(mask, iterations=3)
        mask = ndimage.binary_fill_holes(mask)
    lab, n = ndimage.label(mask)
    if n == 0:
        raise ValueError("没有分割出鱼体；换一张背景更干净的图，或用 PNG 透明背景")
    sizes = ndimage.sum(mask, lab, range(1, n + 1))
    k = int(np.argmax(sizes)) + 1
    mask = lab == k
    if mask.sum() < 0.01 * mask.size:
        raise ValueError("鱼体太小；请裁到鱼占画面主要部分")
    ys, xs = np.where(mask)
    return mask, np.array([xs.min(), xs.max(), ys.min(), ys.max()])


def _contour_figure(img: Image.Image, mask: np.ndarray, bbox, aspect: float) -> str:
    out = OUT / "fish_contour.png"
    fig, ax = plt.subplots(figsize=(8.5, 3.4))
    ax.imshow(img.convert("RGB"))
    ax.contour(mask.astype(float), levels=[0.5], colors="#dc2626", linewidths=1.4)
    x0, x1, y0, y1 = bbox
    ax.plot([x0, x1, x1, x0, x0], [y0, y0, y1, y1, y0], "--", color="#2563eb", lw=1)
    ax.set_title(f"提取轮廓：H/L≈{aspect:.2f}（虚线为包围盒）")
    ax.axis("off")
    fig.tight_layout(); fig.savefig(out, dpi=160); plt.close(fig)
    return out.name


def simulate_from_image(data_url: str, length: float = 0.15, n_sensors: int = 16,
                        speed: float = 0.2, source_x: float = 0.6,
                        source_y: float = 0.3, freq: float = 2.0,
                        noise: float = 0.05) -> dict:
    img = _decode(data_url)
    mask, bbox = segment(img)
    x0, x1, y0, y1 = bbox
    w, h = max(1, x1 - x0 + 1), max(1, y1 - y0 + 1)
    aspect = float(np.clip(h / w, 0.08, 0.55))
    L = max(0.01, float(length))
    H = L * aspect
    shape = "eel" if aspect < 0.16 else ("spindle" if aspect < 0.28 else "ellipse")
    contour = _contour_figure(img, mask, bbox, aspect)
    r = sim_agent.simulate({
        "preset": "custom", "length": L, "height": H, "speed": speed,
        "n_sensors": n_sensors, "source_x": source_x, "source_y": source_y,
        "freq": freq, "noise": noise, "shape": shape,
    })
    reply = (
        f"图片分割完成：包围盒 **{w}×{h} px**，估出 **H/L≈{aspect:.2f}**，"
        f"取体长 **{L:.3f} m** → 体高 **{H:.3f} m**，体形 `{shape}`。\n\n"
        + r["reply"]
        + "\n\n图片只用于估比例/轮廓；绝对尺寸来自你输入的体长。"
    )
    return {
        "status": "ok",
        "reply": reply,
        "metrics": {**r["metrics"], "aspect": round(aspect, 3), "bbox": [int(w), int(h)]},
        "figure": r["figure"],
        "contour": contour,
        "json": r["json"],
        "id": r["id"],
    }


def make_sample() -> str:
    """Create a simple fish silhouette for testing / demo."""
    w, h = 900, 380
    img = Image.new("RGB", (w, h), "white")
    from PIL import ImageDraw
    d = ImageDraw.Draw(img)
    d.ellipse((120, 90, 700, 300), fill=(45, 55, 72))
    d.polygon([(680, 120), (850, 70), (850, 310), (680, 270)], fill=(45, 55, 72))
    d.ellipse((610, 150, 630, 170), fill="white")
    d.ellipse((615, 155, 625, 165), fill=(15, 23, 42))
    out = OUT / "sample_fish.png"
    img.save(out)
    return out.name

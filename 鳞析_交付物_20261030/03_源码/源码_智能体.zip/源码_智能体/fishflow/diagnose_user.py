"""Differential diagnosis for a user's simulation data.

The goal is not to declare one cause.  It is to rank several plausible causes,
show the evidence, and give the user a concrete self-check for each.
"""

from __future__ import annotations

import numpy as np

from . import store

CONF = {"高": 3, "中": 2, "低": 1}


def _corr(a, b) -> float:
    a = np.asarray(a, dtype=float).ravel()
    b = np.asarray(b, dtype=float).ravel()
    ok = np.isfinite(a) & np.isfinite(b)
    a, b = a[ok], b[ok]
    if len(a) < 3 or a.std() < 1e-12 or b.std() < 1e-12:
        return 0.0
    return float(np.corrcoef(a, b)[0, 1])


def _pair(ref, user):
    ref = np.asarray(ref, dtype=float).ravel()
    user = np.asarray(user, dtype=float).ravel()
    ok = np.isfinite(ref) & np.isfinite(user)
    return ref[ok], user[ok]


def _lag(ref, user, times) -> tuple[int, float]:
    a = np.nanmean(ref, axis=1)
    b = np.nanmean(user, axis=1)
    ok = np.isfinite(a) & np.isfinite(b)
    a, b = a[ok], b[ok]
    if len(a) < 8 or a.std() < 1e-12 or b.std() < 1e-12:
        return 0, 0.0
    a = (a - a.mean()) / a.std()
    b = (b - b.mean()) / b.std()
    c = np.correlate(a, b, mode="full")
    lags = np.arange(-len(a) + 1, len(a))
    k = int(np.argmax(c))
    return int(lags[k]), float(c[k] / len(a))


def _hyp(title, confidence, evidence, check, fix, answer):
    return {"title": title, "confidence": confidence, "evidence": evidence,
            "check": check, "fix": fix, "answer": answer,
            "score": CONF[confidence]}


def diagnose(df, scores, mats, mode, geom) -> list[dict]:
    out: list[dict] = []
    man = store.manifest()

    # zero / placeholder columns
    for q in ("p", "ux", "uy"):
        if q in df.columns:
            v = df[q].dropna()
            if len(v) >= 3 and float(v.std()) < 1e-10:
                out.append(_hyp(
                    f"{q} 列几乎是常数",
                    "高",
                    f"{q} 的标准差≈0，可能是没填、全置零或占位列。",
                    f"看 {q} 的 min/max 是否相同；看原始导出是否选错列。",
                    f"重新导出 {q}，或在 CSV 里补上真实值。",
                    f"你问“为什么 {q} 完全对不上”：先排除这列根本没写。",
                ))

    # time start / window
    t0 = float(df["time"].min()); t1 = float(df["time"].max())
    if t0 > man["time_start"] + 0.05:
        out.append(_hyp(
            "缺少启动段或时间窗偏后",
            "中",
            f"你的数据从 t={t0:.3f}s 开始，参考从 {man['time_start']:.3f}s 开始。",
            "看最前面 0.05–0.1s 是否被截掉；看老师数据是否含启动瞬态。",
            "把参考也截到同一时间窗，或补上启动段后再比。",
            "你问“为什么前期差很多”：很可能你只截了稳态段，而参考含启动。",
        ))
    if (t1 - t0) < 0.05 and (man["time_end"] - man["time_start"]) > 0.5:
        out.append(_hyp(
            "时间窗太短或时间单位不对",
            "中",
            f"你的时间跨度只有 {t1 - t0:.3f}，参考跨度约 {man['time_end'] - man['time_start']:.3f}。",
            "确认 time 是秒还是毫秒；确认是否只导了几帧。",
            "统一成秒，并至少覆盖一个完整周期。",
            "你问“为什么曲线对不上”：先查时间单位和窗口长度。",
        ))

    # geometry
    if geom and geom.get("source") == "user":
        ref_l, ref_h = 1.0, 0.145
        if abs(geom["length"] - ref_l) / ref_l > 0.2 or abs(geom["height"] - ref_h) / ref_h > 0.3:
            out.append(_hyp(
                "坐标尺度/几何不一致",
                "中",
                f"你的 L≈{geom['length']:.3f}m、H≈{geom['height']:.3f}m；参考约 L=1.0m、H=0.145m。",
                "查 x/y 是米还是厘米/毫米；查 x/y 是否互换；查是否用了不同鱼体。",
                "统一单位；若 x/y 互换，交换两列；若鱼不同，换参考几何。",
                "你问“为什么形状像但数值差”：先查坐标单位和长高比。",
            ))

    # per-quantity scale / sign
    for q, s in scores.items():
        A, B, scale = s["A"], s["B"], s["scale"]
        if abs(scale) > 2 or (0 < abs(scale) < 0.5):
            out.append(_hyp(
                f"{q} 的量级/归一化不一致",
                "高" if abs(scale) > 5 or abs(scale) < 0.2 else "中",
                f"{q} 的均值比 user/reference≈{scale:.2f}，A={A:.3f}，B={B:.3f}。",
                f"看 {q} 的量纲：Pa vs p/(ρU²)、m/s vs 归一化速度、峰峰值 vs 幅值。",
                f"把 {q} 换成和参考同一归一化，或把参考乘回同一量纲。",
                f"你问“为什么 {q} 的 A 高 B 低”：形状对、幅值不对，优先查单位和归一化。",
            ))
        if A > 0.5 and B < 0.2:
            out.append(_hyp(
                f"{q} 有整体偏移/缩放",
                "中",
                f"A={A:.3f} 但 B={B:.3f}，bias={s['bias']:.3f}。",
                "画 user vs reference 的 parity 图，看是否整体偏离 1:1 线。",
                "先减均值/乘比例，再判断剩余误差。",
                f"你问“为什么 {q} 形状像但绝对值错”：先做去均值/归一化对照。",
            ))

    # sign / swap / lag from matrices
    if mats:
        for q in ("p", "ux", "uy"):
            if q not in mats:
                continue
            ref, user, times, probes = mats[q]
            r = _corr(ref, user)
            r_neg = _corr(ref, -user)
            if r_neg > max(0.35, r + 0.2):
                out.append(_hyp(
                    f"{q} 的符号约定可能反了",
                    "高",
                    f"原相关 {r:.3f}，取反后 {r_neg:.3f}，取反明显更吻合。",
                    f"看 {q} 的正方向定义、表压/绝压、上下游方向。",
                    f"确认后统一符号，或在对比时对 {q} 取反。",
                    f"你问“为什么 {q} 完全反着”：先查符号约定，不一定是算错。",
                ))

        if "ux" in mats and "uy" in mats:
            ux_r, ux_u, _, _ = mats["ux"]
            uy_r, uy_u, _, _ = mats["uy"]
            own = (_corr(ux_r, ux_u) + _corr(uy_r, uy_u)) / 2
            swp = (_corr(ux_r, uy_u) + _corr(uy_r, ux_u)) / 2
            if swp > own + 0.2:
                out.append(_hyp(
                    "ux / uy 两列可能接反",
                    "高",
                    f"按原列相关≈{own:.3f}；交换后≈{swp:.3f}。",
                    "看导出表头/列顺序，确认 ux 是 x 方向、uy 是 y 方向。",
                    "交换两列后重新检验。",
                    "你问“为什么两个速度都怪”：先查 ux/uy 是否互换。",
                ))

        # time lag on p
        if "p" in mats:
            ref, user, times, probes = mats["p"]
            lag, peak = _lag(ref, user, times)
            if abs(lag) >= 1 and peak > 0.3:
                dt = float(np.median(np.diff(times))) if len(times) > 1 else 0.0
                out.append(_hyp(
                    "时间起点/相位有偏移",
                    "中",
                    f"互相关峰在 lag={lag} 帧（约 {lag * dt:.4f}s），相关≈{peak:.3f}。",
                    "把两条曲线画在同一时间轴，看峰/谷是否错位。",
                    "对齐时间起点，或检查采样时刻是否差半帧。",
                    "你问“为什么形状像但峰谷错位”：先查时间对齐/相位。",
                ))

        # probe order / one-based shift
        if "p" in mats and len(mats["p"][3]) >= 8:
            ref, user, times, probes = mats["p"]
            base = np.nanmean(np.abs(ref - user))
            best = (0, base)
            for s in (-2, -1, 1, 2):
                if s < 0:
                    err = np.nanmean(np.abs(ref[:, :s] - user[:, -s:]))
                else:
                    err = np.nanmean(np.abs(ref[:, s:] - user[:, :-s]))
                if np.isfinite(err) and err < best[1]:
                    best = (s, err)
            if best[0] and best[1] < 0.8 * base:
                out.append(_hyp(
                    "探针编号/顺序可能整体错位",
                    "中",
                    f"整体错位 {best[0]:+d} 个位置后，平均绝对误差从 {base:.4f} 降到 {best[1]:.4f}。",
                    "查 probe 是 0 开始还是 1 开始；查上下表面/左右侧顺序是否反了。",
                    "把 probe 编号对齐（±1），或按几何重新匹配。",
                    "你问“为什么每个点都差一点”：先查 probe 编号偏移。",
                ))

    # dedupe by title, sort by confidence
    seen = set(); uniq = []
    for h in out:
        if h["title"] in seen:
            continue
        seen.add(h["title"]); uniq.append(h)
    uniq.sort(key=lambda h: h["score"], reverse=True)
    return uniq[:6]


def profile_hypotheses(df) -> list[dict]:
    out = [
        _hyp(
            "时间窗完全落在参考范围外",
            "高",
            "没有重叠帧，无法计算 A/B。",
            "看 time 的最小/最大值是否在 0–50s；看单位是秒还是毫秒。",
            "截到 0–50s，或统一时间单位。",
            "你问“为什么完全没法比”：先看时间范围。",
        ),
        _hyp(
            "probe 编号体系不一致",
            "中",
            "如果时间没问题，下一步最常见的是 probe 0/1 起始或编号重排。",
            "查你的 probe 最小/最大值；查是否从 1 开始。",
            "按几何坐标重新匹配，而不是只按编号。",
            "你问“为什么 probe 对不上”：先查编号起点。",
        ),
        _hyp(
            "列名/单位不对",
            "中",
            "列名不是 time/probe/p/ux/uy 时，解析会失败或错列。",
            "看表头；看 p 是否 Pa、速度是否 m/s。",
            "改成标准列名并统一单位。",
            "你问“为什么导入就错”：先看表头和单位。",
        ),
    ]
    return out

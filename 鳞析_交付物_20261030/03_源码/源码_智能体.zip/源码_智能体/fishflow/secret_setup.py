"""Set/rotate the Zhipu API key using Windows DPAPI.

Run:
    python -m fishflow.secret_setup

The key is read with hidden input and stored encrypted for the current Windows
user.  It is never written to source, .bat files, or logs.
"""

from __future__ import annotations

import getpass
import sys

from .secret_store import has, save


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    print("Zhipu API key setup (input is hidden).")
    key = getpass.getpass("Paste key: ").strip()
    if not key:
        print("empty; cancelled")
        return 1
    path = save("zhipu", key)
    print(f"saved DPAPI secret: {path}")
    print("plaintext was not written to disk")
    if has("zhipu"):
        print("verify: OK (decryptable by current Windows user)")
        return 0
    print("verify: FAILED")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())

"""Build a self-contained evidence report (HTML + Markdown)."""

from __future__ import annotations

import base64
import html
import time
from pathlib import Path

from . import config, diagnose, metrics, plots, provenance, store

GOLDEN_QUESTIONS = [
    "DMD 能不能外推到 25 秒之后？",
    "p 的 R² 都 0.99 了，为什么还说压强不准？",
    "u_x 为什么卡在 0.83？",
]


def _data_uri(path: Path) -> str:
    """Embed an image so the HTML report is a single portable file."""
    mime = "image/gif" if path.suffix.lower() == ".gif" else "image/png"
    data = base64.b64encode(path.read_bytes()).decode("ascii")
    return f"data:{mime};base64,{data}"


def _qa_cards() -> list[dict]:
    cards = []
    for q in GOLDEN_QUESTIONS:
        r = diagnose.answer(q)
        if r.get("status") == "ok":
            provenance.append(r["title"], r["evidence"], "diagnose", {"question": q})
        cards.append({"question": q, "result": r})
    return cards


def _metrics_rows() -> list[dict]:
    return metrics.table()


def _html_table(rows: list[dict]) -> str:
    head = "<tr><th>dataset</th><th>quantity</th><th>A (shape)</th><th>B (absolute)</th><th>RMSE</th><th>frames</th></tr>"
    body = []
    for r in rows:
        body.append(
            f"<tr><td>{html.escape(r['dataset'])}</td><td>{html.escape(r['quantity'])}</td>"
            f"<td>{r['A']:.4f}</td><td>{r['B']:.4f}</td><td>{r['RMSE']:.4f}</td>"
            f"<td>{r['frames']:,}</td></tr>"
        )
    return f"<table>{head}{''.join(body)}</table>"


def build(out_html: str | Path | None = None, out_md: str | Path | None = None) -> dict:
    config.ensure_dirs()
    fig_dir = config.OUTPUTS / "figs"
    fig_dir.mkdir(parents=True, exist_ok=True)

    overview = plots.overview(fig_dir / "overview.png", t=0.2)
    metrics_fig = plots.metrics_plot(fig_dir / "metrics.png")
    series = plots.series_plot(17, "p", 0.1, 2.0, fig_dir / "series.png")

    overview_uri = _data_uri(overview)
    metrics_uri = _data_uri(metrics_fig)
    series_uri = _data_uri(series)

    cards = _qa_cards()
    from .eval import CASES
    hits = sum(1 for q, expected in CASES if diagnose.answer(q).get("matched") == expected)
    rows = _metrics_rows()
    man = store.manifest()
    ev = provenance.last(12)
    gif = config.OUTPUTS / "field_animation.gif"
    gif_uri = _data_uri(gif) if gif.exists() else ""
    gif_html = (
        f'<div style="margin-top:14px"><img src="{gif_uri}" alt="animation">'
        '<div class="sub">表面压强动画（0.1–0.46 s，12 fps）</div></div>'
        if gif_uri else ""
    )
    links = []
    if (config.OUTPUTS / "flow_dashboard.html").exists():
        links.append('<a href="flow_dashboard.html">交互式流场看板（3D/探针/动画）</a>')
    if (config.OUTPUTS / "flow_calculator.html").exists():
        links.append('<a href="flow_calculator.html">坐标→流场计算器</a>')
    interactive_html = (
        f'<div class="banner"><b>可交互：</b>{" · ".join(links)}</div>' if links else ""
    )

    now = time.strftime("%Y-%m-%d %H:%M")
    html_path = Path(out_html) if out_html else config.OUTPUTS / "guard_report.html"
    md_path = Path(out_md) if out_md else config.OUTPUTS / "guard_report.md"

    qa_html = []
    for c in cards:
        r = c["result"]
        if r.get("status") != "ok":
            qa_html.append(f"<div class='card'><h3>{html.escape(c['question'])}</h3><p>{html.escape(r.get('message',''))}</p></div>")
            continue
        evs = "".join(f"<li>{html.escape(e)}</li>" for e in r["evidence"])
        qa_html.append(
            f"<div class='card'>"
            f"<div class='q'>Q · {html.escape(c['question'])}</div>"
            f"<div class='tag'>{html.escape(r['title'])} · confidence {r['confidence']:.2f}</div>"
            f"<p>{html.escape(r['answer'])}</p>"
            f"<details><summary>证据</summary><ul>{evs}</ul></details>"
            f"<div class='guard'>护栏：{html.escape(r['guardrail'])}</div>"
            f"</div>"
        )

    ev_html = "".join(
        f"<tr><td>{html.escape(e['id'])}</td><td>{html.escape(e['claim'])}</td>"
        f"<td>{html.escape(e['tool'])}</td><td>{html.escape(e['ts'])}</td></tr>"
        for e in ev
    )

    from .research import log as research_log
    recs = research_log(1)
    rec = recs[-1] if recs else None
    research_html = ""
    if rec:
        steps = "".join(
            f"<li><b>{html.escape(s['action'])}</b> — "
            f"{html.escape(str(s.get('observation', '')))[:200]}</li>"
            for s in rec.get("steps", [])
        )
        checks = "".join(
            f"<li><b>[{c['level']}] {c['code']}</b> — {html.escape(c['message'])}</li>"
            for c in rec.get("critic", [])
        )
        color = {"BLOCK": "#c53030", "WARN": "#b7791f", "PASS": "#2f855a"}.get(rec.get("verdict"), "#4a5568")
        research_html = (
            "<h2>2b. 闭环研究（最近一次）</h2>"
            "<div class='card'>"
            f"<div class='q'>{html.escape(rec.get('hypothesis', ''))}</div>"
            f"<div class='tag' style='color:{color};font-weight:700'>verdict: {html.escape(rec.get('verdict', ''))}</div>"
            f"<ol>{steps}</ol>"
            f"<details><summary>critic</summary><ul>{checks}</ul></details>"
            f"<div class='guard'>{html.escape(rec.get('conclusion', ''))}</div>"
            f"<div class='sub'>record: {html.escape(rec.get('artifacts', {}).get('record_md', ''))}</div>"
            "</div>"
        )

    doc = f"""<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8">
<title>鳞析 · 仿生鱼流场方法学护栏报告</title>
<style>
:root {{ --ink:#1a202c; --muted:#4a5568; --line:#e2e8f0; --blue:#2b6cb0; --red:#c53030; --bg:#f7fafc; }}
* {{ box-sizing:border-box; }}
body {{ margin:0; background:var(--bg); color:var(--ink); font-family:"Microsoft YaHei","Segoe UI",sans-serif; line-height:1.65; }}
.wrap {{ max-width:1080px; margin:0 auto; padding:36px 24px 60px; }}
h1 {{ font-size:28px; margin:0 0 6px; }}
h2 {{ font-size:19px; margin:34px 0 12px; border-left:4px solid var(--blue); padding-left:10px; }}
.sub {{ color:var(--muted); font-size:13px; }}
.banner {{ background:#fff5f5; border:1px solid #fed7d7; color:#742a2a; padding:12px 14px; border-radius:8px; margin:18px 0; font-size:14px; }}
.grid {{ display:grid; grid-template-columns:repeat(4,1fr); gap:10px; margin:14px 0; }}
.kpi {{ background:white; border:1px solid var(--line); border-radius:8px; padding:12px; }}
.kpi .v {{ font-size:20px; font-weight:700; color:var(--blue); }}
.kpi .l {{ font-size:12px; color:var(--muted); }}
table {{ width:100%; border-collapse:collapse; background:white; font-size:13px; }}
th,td {{ border:1px solid var(--line); padding:6px 8px; text-align:left; }}
th {{ background:#edf2f7; }}
.card {{ background:white; border:1px solid var(--line); border-radius:10px; padding:14px 16px; margin:12px 0; }}
.card .q {{ font-weight:700; color:var(--blue); }}
.card .tag {{ display:inline-block; font-size:12px; color:var(--muted); background:#edf2f7; border-radius:999px; padding:1px 8px; margin:6px 0; }}
.card .guard {{ font-size:13px; color:#742a2a; background:#fff5f5; border-left:3px solid var(--red); padding:6px 10px; margin-top:8px; }}
img {{ max-width:100%; border:1px solid var(--line); border-radius:8px; background:white; }}
.two {{ display:grid; grid-template-columns:1fr 1fr; gap:14px; }}
.foot {{ color:var(--muted); font-size:12px; margin-top:30px; border-top:1px solid var(--line); padding-top:12px; }}
code {{ background:#edf2f7; padding:1px 4px; border-radius:4px; }}
</style></head><body><div class="wrap">
<h1>鳞析 · 仿生鱼流场方法学护栏</h1>
<div class="sub">证据化报告 · {now} · 本地数据，不涉及老师原始仿真数据</div>

<div class="banner">
<b>三条硬规则：</b>① R² 必须说明 A（形状）还是 B（绝对）；② DMD 只能复现，不能外推；
③ 拟合窗必须剔除启动瞬态与复位帧。
</div>
{interactive_html}

<div class="grid">
  <div class="kpi"><div class="v">{man['n_frames']:,}</div><div class="l">帧数（dt={man['dt']} s）</div></div>
  <div class="kpi"><div class="v">{man['n_probes']}</div><div class="l">表面探针（202 上 + 202 下）</div></div>
  <div class="kpi"><div class="v">{man['n_rows']:,}</div><div class="l">索引行数</div></div>
  <div class="kpi"><div class="v">-7.11</div><div class="l">DMD 留出测试 R²（不可外推）</div></div>
</div>

<h2>1. 权威指标：两个口径</h2>
{_html_table(rows)}
<p class="sub">
A = 逐帧空间相关²（形状，尺度不变）；B = 1−SSE/SST（绝对，敏感于幅值）。
p 的 A/B 差距最大，是“形状对、幅值不对”的典型。
</p>
<div class="banner">
<b>物理模型接入：</b><code>可运行/</code> 跑出的 1,001 帧表与 <code>交付包/03</code> 的物理模型表
<b>逐位相同</b>（最大差 0.0）。与 DMD v2 在 [0.1, 1.0] 对比：
全 404 探针 A=0.1763 / B=0.0016；剔除鼻尖尾缘各 24（308 探针）A=0.4427 / B=0.0075。
这与文档的 0.177 / 0.416 一致——低 R² 是<b>无黏 + 尖点奇异</b>的已知边界，不是 bug。
</div>

<h2>2. 三个护栏问答</h2>
{''.join(qa_html)}
{research_html}

<h2>3. 路由评测</h2>
<div class="banner">15 题方法学路由：<b>{hits}/{len(CASES)}</b> 命中。
评测脚本 <code>python -m fishflow.eval</code>，题目覆盖口径、外推、调参、瞬态、尖点、方法选择、数据源、边界。
<br><b>开发者自测：</b>6/6 任务通过（<code>validation/SELFTEST.md</code>）；
用户试用待进行（<code>validation/TRIAL_KIT.md</code>），本报告不含任何 AI 生成的用户日志。</div>

<h2>4. 图</h2>
<div class="two">
  <div><img src="{overview_uri}" alt="overview"><div class="sub">表面压强 + 沿弦分布 + 两口径指标</div></div>
  <div><img src="{metrics_uri}" alt="metrics"><div class="sub">dmd_v2 vs dmd_old 的 A/B 指标</div></div>
</div>
<div style="margin-top:14px"><img src="{series_uri}" alt="series"><div class="sub">探针 17 的压强时序（0.1–2.0 s）</div></div>
{gif_html}

<h2>5. 证据链（最近 12 条）</h2>
<table><tr><th>id</th><th>结论</th><th>工具</th><th>时间</th></tr>{ev_html}</table>

<div class="foot">
数据：<code>交付包/02_主数据表/probe_table_DMD_v2_trimmed.tsv</code> ·
指标：<code>交付包/06_指标/*.json</code> ·
索引：<code>data/index/</code> ·
生成：<code>python -m fishflow.report</code>
</div>
</div></body></html>"""

    html_path.write_text(doc, encoding="utf-8")

    md = [
        "# 鳞析 · 仿生鱼流场方法学护栏",
        "",
        f"- 生成时间：{now}",
        f"- 数据：{man['n_frames']:,} 帧 × {man['n_probes']} 探针，dt={man['dt']} s",
        "- 三条硬规则：A/B 口径；DMD 不可外推；剔除瞬态/复位帧。",
        ("- 交互式：[流场看板](flow_dashboard.html) · [坐标→流场计算器](flow_calculator.html)"
         if links else ""),
        "",
        "## 权威指标",
        "",
        "| dataset | quantity | A (shape) | B (absolute) | RMSE |",
        "|---|---|---|---|---|",
    ]
    for r in rows:
        md.append(f"| {r['dataset']} | {r['quantity']} | {r['A']:.4f} | {r['B']:.4f} | {r['RMSE']:.4f} |")
    md += ["", "物理模型接入：可运行包与交付包物理模型表逐位相同；与 DMD v2 在 [0.1,1.0] 上，"
               "全 404 A=0.1763 / B=0.0016，trim24（308）A=0.4427 / B=0.0075；"
               "与文档 0.177/0.416 一致，低 R² 是无黏+尖点，不是 bug。", ""]
    md += ["", "## 护栏问答", ""]
    for c in cards:
        r = c["result"]
        if r.get("status") == "ok":
            md += [f"### {c['question']}", "", r["answer"], "", "依据：", ""]
            md += [f"- {e}" for e in r["evidence"]]
            md += ["", f"> 护栏：{r['guardrail']}", ""]
    if rec:
        md += ["## 闭环研究（最近一次）", "", f"- 假设：{rec.get('hypothesis','')}",
               f"- verdict：**{rec.get('verdict','')}**", "- 步骤："]
        md += [f"  {s['n']}. {s['action']} — {str(s.get('observation',''))[:200]}"
               for s in rec.get("steps", [])]
        md += ["", f"- 结论：{rec.get('conclusion','')}", ""]
    md += ["## 图", "", f"![overview]({overview})", "", f"![metrics]({metrics_fig})", "", f"![series]({series})", ""]
    if gif.exists():
        md += [f"![animation]({gif})", ""]
    md_path.write_text("\n".join(md), encoding="utf-8")

    return {
        "html": str(html_path),
        "md": str(md_path),
        "figures": [str(overview), str(metrics_fig), str(series)],
        "metrics": rows,
        "qa": cards,
    }


if __name__ == "__main__":
    print(build())

"""Guided lateral-line simulation for one fish.

This is a transparent 2-D analytical demo, not CFD:
uniform flow + oscillating dipole + sensors on an elliptical body.
It is meant to show the *workflow* (geometry -> sensors -> signals -> decode),
not to claim biological accuracy.
"""

from __future__ import annotations

import json
import time
import uuid
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib import font_manager
from matplotlib.patches import Ellipse

for _name in ("Microsoft YaHei", "SimHei", "DejaVu Sans"):
    try:
        font_manager.findfont(_name, fallback_to_default=False)
        plt.rcParams["font.sans-serif"] = [_name]
        break
    except Exception:
        continue
plt.rcParams["axes.unicode_minus"] = False

from . import config

OUT = config.OUTPUTS

PRESETS = {
    "zebrafish": {"label": "斑马鱼", "length": 0.030, "height": 0.008, "speed": 0.05},
    "carp": {"label": "鲤鱼", "length": 0.300, "height": 0.080, "speed": 0.30},
    "tuna": {"label": "金枪鱼", "length": 0.500, "height": 0.120, "speed": 1.00},
    "custom": {"label": "自定义", "length": 0.150, "height": 0.040, "speed": 0.20},
}

DEFAULTS = {
    "preset": "custom",
    "length": 0.150,
    "height": 0.040,
    "speed": 0.20,
    "n_sensors": 16,
    "source_x": 0.60,   # in body lengths from center
    "source_y": 0.30,
    "freq": 2.0,
    "noise": 0.05,      # fraction of signal std
    "shape": "ellipse",
}


def _half_height(x, L, H, shape="ellipse"):
    u = np.clip(1.0 - (2.0 * x / L) ** 2, 0.0, 1.0)
    if shape == "spindle":
        return 0.5 * H * u ** 0.65
    if shape == "eel":
        return 0.5 * H * (0.25 + 0.75 * u ** 0.5)
    return 0.5 * H * np.sqrt(u)


def _field(x, y, xs, ys, m, mdot, U, rho=1.0):
    dx, dy = x - xs, y - ys
    r2 = dx * dx + dy * dy
    r2 = np.maximum(r2, 1e-12)
    ux = U + (m / (2 * np.pi)) * (1 / r2 - 2 * dx * dx / (r2 * r2))
    uy = (m / (2 * np.pi)) * (-2 * dx * dy / (r2 * r2))
    dphi_dt = (mdot / (2 * np.pi)) * dx / r2
    p = -rho * dphi_dt - 0.5 * rho * ((ux - U) ** 2 + uy ** 2)
    return ux, uy, p


def form() -> dict:
    return {
        "presets": [{"id": k, **v} for k, v in PRESETS.items()],
        "defaults": DEFAULTS,
    }


def simulate(params: dict) -> dict:
    p = dict(DEFAULTS)
    p.update({k: v for k, v in (params or {}).items() if v is not None})
    src = params or {}
    if src.get("preset") in PRESETS and "length" not in src:
        p.update({k: v for k, v in PRESETS[src["preset"]].items() if k != "label"})
    L = max(0.005, float(p["length"]))
    H = max(0.001, float(p["height"]))
    U = max(0.001, float(p["speed"]))
    N = max(4, min(64, int(p["n_sensors"])))
    sx, sy = float(p["source_x"]) * L, float(p["source_y"]) * L
    f = max(0.1, float(p["freq"]))
    noise = max(0.0, min(0.5, float(p["noise"])))
    shape = str(p.get("shape", "ellipse"))

    # sensors on both sides of the body (lateral line is bilateral)
    n_up = max(2, N // 2)
    n_lo = max(2, N - n_up)
    xu = np.linspace(-0.42 * L, 0.42 * L, n_up)
    xl = np.linspace(-0.42 * L, 0.42 * L, n_lo)
    xs = np.concatenate([xu, xl])
    ys = np.concatenate([0.85 * _half_height(xu, L, H, shape),
                         -0.85 * _half_height(xl, L, H, shape)])
    N = len(xs)

    # time: two periods
    T = 2.0 / f
    t = np.linspace(0.0, T, 401)
    m = 1.0 * np.sin(2 * np.pi * f * t)
    mdot = 1.0 * 2 * np.pi * f * np.cos(2 * np.pi * f * t)

    sig = np.zeros((len(t), N))
    for k in range(len(t)):
        _, _, pk = _field(xs, ys, sx, sy, m[k], mdot[k], U)
        sig[k] = pk
    sig -= sig.mean(axis=0, keepdims=True)

    rng = np.random.default_rng(7)
    noise_arr = rng.normal(0.0, noise * (np.std(sig) + 1e-12), size=sig.shape)
    obs = sig + noise_arr

    amp = np.abs(obs).max(axis=0)
    amp_n = amp / (amp.max() + 1e-12)

    # decode: grid-search source from normalized 1/r amplitude pattern (baseline)
    gx = np.linspace(-0.2 * L, 1.1 * L, 42)
    gy = np.linspace(0.04 * L, 0.55 * L, 34)
    best = (1e9, sx, sy)
    for cx in gx:
        for cy in gy:
            r = np.hypot(xs - cx, ys - cy)
            pred = 1.0 / (r + 0.02 * L)
            pred = pred / (pred.max() + 1e-12)
            mse = float(np.mean((pred - amp_n) ** 2))
            if mse < best[0]:
                best = (mse, cx, cy)
    _, ex, ey = best
    loc_err = float(np.hypot(ex - sx, ey - sy) / L)

    r = np.hypot(xs - sx, ys - sy)
    coef = np.polyfit(r, amp, 1)
    pred_amp = np.polyval(coef, r)
    ss_res = float(np.sum((amp - pred_amp) ** 2))
    ss_tot = float(np.sum((amp - amp.mean()) ** 2) + 1e-12)
    decay_r2 = 1.0 - ss_res / ss_tot
    sig_rms = float(np.sqrt(np.mean(sig ** 2)) + 1e-12)
    noise_rms = float(np.sqrt(np.mean(noise_arr ** 2)) + 1e-12)
    snr_db = 20 * np.log10(sig_rms / noise_rms)

    # field snapshot at peak
    k0 = int(np.argmax(np.abs(obs).max(axis=1)))
    gxx, gyy = np.meshgrid(np.linspace(-0.6 * L, 1.0 * L, 180),
                           np.linspace(-0.4 * L, 0.6 * L, 140))
    _, _, pf = _field(gxx, gyy, sx, sy, m[k0], mdot[k0], U)
    pf = np.where(np.hypot(gxx - sx, gyy - sy) < 0.08 * L, np.nan, pf)

    fig, axes = plt.subplots(2, 2, figsize=(11.5, 7.2))
    ax = axes[0, 0]
    vmax = np.nanpercentile(np.abs(pf), 96)
    im = ax.pcolormesh(gxx, gyy, pf, cmap="RdBu_r", vmin=-vmax, vmax=vmax, shading="auto")
    ax.add_patch(Ellipse((0, 0), L, H, fill=False, lw=1.6, ec="#0f172a"))
    ax.plot(xs, ys, "o", ms=3.2, color="#0f172a", label=f"{N} 传感器")
    ax.plot([sx], [sy], "*", ms=16, color="#f59e0b", label="真实源")
    ax.plot([ex], [ey], "x", ms=12, color="#16a34a", label="估计源")
    ax.set_aspect("equal")
    ax.set_xlim(-0.6 * L, 1.0 * L); ax.set_ylim(-0.4 * L, 0.6 * L)
    ax.set_title("侧线阵列 + 偶极子源（归一化压力）")
    ax.set_xlabel("x [m]"); ax.set_ylabel("y [m]")
    ax.legend(fontsize=7, loc="upper left")
    fig.colorbar(im, ax=ax, fraction=0.035, pad=0.02)

    ax = axes[0, 1]
    im = ax.pcolormesh(t, np.arange(N), obs.T, cmap="RdBu_r", shading="auto")
    ax.set_xlabel("t [s]"); ax.set_ylabel("sensor id")
    ax.set_title("阵列信号（含噪声）")
    fig.colorbar(im, ax=ax, fraction=0.035, pad=0.02)

    ax = axes[1, 0]
    for idx, color in [(0, "#94a3b8"), (N // 3, "#2563eb"),
                       (2 * N // 3, "#dc2626"), (N - 1, "#16a34a")]:
        ax.plot(t, obs[:, idx], lw=1.0, color=color, label=f"sensor {idx}")
    ax.set_xlabel("t [s]"); ax.set_ylabel("p (norm.)")
    ax.set_title("代表点时序")
    ax.grid(alpha=0.25); ax.legend(fontsize=7)

    ax = axes[1, 1]
    ax.plot(xs / L, ys / L, "o", ms=4, color="#0f172a", label="传感器")
    ax.plot([sx / L], [sy / L], "*", ms=16, color="#f59e0b", label="真实源")
    ax.plot([ex / L], [ey / L], "x", ms=12, color="#16a34a", label="估计源")
    ax.set_aspect("equal")
    ax.set_xlim(-0.6, 1.1); ax.set_ylim(-0.1, 0.6)
    ax.set_xlabel("x/L"); ax.set_ylabel("y/L")
    ax.set_title(f"源定位误差 = {loc_err:.2f} L")
    ax.legend(fontsize=7, loc="upper left")
    ax.grid(alpha=0.2)

    fig.tight_layout()
    sid = "sim-" + uuid.uuid4().hex[:8]
    png = OUT / f"{sid}.png"
    fig.savefig(png, dpi=165)
    plt.close(fig)

    metrics = {
        "snr_db": round(snr_db, 2),
        "peak": round(float(amp.max()), 3),
        "decay_r2": round(float(decay_r2), 3),
        "loc_error_L": round(loc_err, 3),
        "estimated_source": [round(ex / L, 3), round(ey / L, 3)],
        "sensors": N,
    }
    payload = {
        "id": sid,
        "params": {"length": L, "height": H, "speed": U, "n_sensors": N,
                   "source_x": sx / L, "source_y": sy / L, "freq": f,
                   "noise": noise, "shape": shape},
        "metrics": metrics,
        "figure": png.name,
        "ts": time.strftime("%Y-%m-%dT%H:%M:%S"),
    }
    (OUT / f"{sid}.json").write_text(json.dumps(payload, ensure_ascii=False, indent=1), encoding="utf-8")

    reply = (
        f"仿真完成：**体长 {L:.3f} m**、**{N} 个传感器**、源在 "
        f"({sx/L:.2f} L, {sy/L:.2f} L)、{f:g} Hz。\n\n"
        f"- 信噪比：**{metrics['snr_db']:.1f} dB**\n"
        f"- 幅值-距离拟合 R²：**{metrics['decay_r2']:.2f}**\n"
        f"- 源定位误差：**{metrics['loc_error_L']:.2f} L**（幅值基线；加相位/多阵列可降低）\n"
        f"  估计位置（{metrics['estimated_source'][0]:.2f}, {metrics['estimated_source'][1]:.2f}）\n\n"
        "这是二维解析模型（均匀流 + 偶极子），不是 CFD；用来跑通“几何→阵列→信号→解码”闭环。"
    )
    return {"status": "ok", "reply": reply, "metrics": metrics,
            "figure": png.name, "json": f"{sid}.json", "id": sid}

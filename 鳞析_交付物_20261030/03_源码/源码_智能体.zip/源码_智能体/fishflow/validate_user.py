"""Validate a user's simulation CSV against the reference index.

Two accepted layouts:
  long: time, probe, [x, y], p, ux, uy
  xyz : time, x, y, p, ux, uy   (nearest reference probe per row)

Returns a verdict, per-quantity metrics, a table, and a 4-panel PNG.
This is a local comparison, not a certification of physical truth.
"""

from __future__ import annotations

import io
import json
import time
import uuid
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib import font_manager

for _name in ("Microsoft YaHei", "SimHei", "DejaVu Sans"):
    try:
        font_manager.findfont(_name, fallback_to_default=False)
        plt.rcParams["font.sans-serif"] = [_name]
        break
    except Exception:
        continue
plt.rcParams["axes.unicode_minus"] = False

from . import config, diagnose_user, metrics, store

OUT = config.OUTPUTS
MAX_ROWS = 200_000
ALIASES = {
    "t": "time", "time_s": "time", "时间": "time", "时刻": "time",
    "probe_id": "probe", "point_id": "probe", "探针": "probe", "探针号": "probe",
    "pressure": "p", "pressure_p": "p", "压强": "p", "压力": "p",
    "u_x": "ux", "xvelocity": "ux", "x_velocity": "ux", "vx": "ux", "x速度": "ux",
    "u_y": "uy", "yvelocity": "uy", "y_velocity": "uy", "vy": "uy", "y速度": "uy",
    "xcoord": "x", "x_coord": "x", "坐标x": "x",
    "ycoord": "y", "y_coord": "y", "坐标y": "y",
}


def _norm(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = [str(c).strip().lower().replace(" ", "_") for c in df.columns]
    rename = {}
    for c in df.columns:
        target = ALIASES.get(c, c)
        if target not in rename.values():
            rename[c] = target
    return df.rename(columns=rename)


def _load(csv_text: str) -> pd.DataFrame:
    if not csv_text or len(csv_text) > 12 * 1024 * 1024:
        raise ValueError("CSV 为空或超过 12 MB")
    df = pd.read_csv(io.StringIO(csv_text))
    if len(df) == 0:
        raise ValueError("CSV 没有数据行")
    if len(df) > MAX_ROWS:
        raise ValueError(f"行数 {len(df)} 超过 {MAX_ROWS}，请先降采样")
    df = _norm(df)
    if "time" not in df.columns:
        raise ValueError("缺少 time 列；可用列：time, probe, x, y, p, ux, uy")
    for c in ("time", "probe", "x", "y", "p", "ux", "uy"):
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df[np.isfinite(df["time"])].copy()
    if df.empty:
        raise ValueError("time 列没有有效数值")
    return df


def _corr2(ref: np.ndarray, user: np.ndarray) -> float:
    ref = np.asarray(ref, dtype=float).ravel()
    user = np.asarray(user, dtype=float).ravel()
    if len(ref) < 2 or ref.std() < 1e-12 or user.std() < 1e-12:
        return 0.0
    return float(np.corrcoef(ref, user)[0, 1] ** 2)


def _metrics(ref: np.ndarray, user: np.ndarray, spatial: bool) -> dict:
    ref = np.asarray(ref, dtype=float)
    user = np.asarray(user, dtype=float)
    if spatial and ref.ndim == 2 and ref.shape[1] >= 2:
        try:
            A = metrics.r2_a(ref, user)
        except Exception:
            A = _corr2(ref, user)
    else:
        A = _corr2(ref, user)
    try:
        B = metrics.r2_b(ref, user)
    except Exception:
        B = 0.0
    if not np.isfinite(B):
        B = 0.0
    rmse = float(np.sqrt(np.mean((ref - user) ** 2)))
    bias = float(np.mean(user - ref))
    scale = float(np.mean(user) / (np.mean(ref) + 1e-12))
    return {"A": round(float(A), 4), "B": round(float(B), 4),
            "RMSE": round(rmse, 4), "bias": round(bias, 4),
            "scale": round(scale, 3), "n": int(ref.size)}


def _long_compare(df: pd.DataFrame, quantities: list[str]):
    man = store.manifest()
    df = df[(df["time"] >= man["time_start"]) & (df["time"] <= man["time_end"])]
    if df.empty:
        raise ValueError("所有时间都落在参考数据范围之外")
    if "probe" not in df.columns:
        raise ValueError("长表模式需要 probe 列")
    df["probe"] = df["probe"].astype(int)
    times = np.array(sorted(df["time"].unique()))
    probes = sorted(df["probe"].unique())
    if len(probes) > 404:
        raise ValueError("probe 数量超过 404")
    out, mats = {}, {}
    for q in quantities:
        if q not in df.columns:
            continue
        pivot = df.pivot_table(index="time", columns="probe", values=q, aggfunc="mean")
        pivot = pivot.reindex(index=times, columns=probes)
        ref = np.full(pivot.shape, np.nan)
        for j, p in enumerate(probes):
            d = store.query(int(p), float(times[0]), float(times[-1]), q)
            ref[:, j] = np.interp(times, d["time"], d["value"])
        user = pivot.to_numpy(dtype=float)
        mask = np.isfinite(ref) & np.isfinite(user)
        if mask.sum() < 3:
            continue
        out[q] = _metrics(ref[mask], user[mask], spatial=True)
        mats[q] = (ref, user, times, probes)
    return out, mats, "long"


def _xyz_compare(df: pd.DataFrame, quantities: list[str]):
    man = store.manifest()
    df = df[(df["time"] >= man["time_start"]) & (df["time"] <= man["time_end"])]
    if df.empty:
        raise ValueError("所有时间都落在参考数据范围之外")
    if not {"x", "y"}.issubset(df.columns):
        raise ValueError("坐标模式需要 x、y 列")
    times = np.array(sorted(df["time"].unique()))
    if len(times) > 50:
        raise ValueError("坐标模式最多 50 个不同时刻，请降采样")
    ref_rows, user_rows = {}, {q: [] for q in quantities}
    xs, ys = [], []
    for t in times:
        fr = store.frame_at(float(t))
        sub = df[np.isclose(df["time"], t)]
        for _, row in sub.iterrows():
            d = np.hypot(fr["x"] - row["x"], fr["y"] - row["y"])
            i = int(np.argmin(d))
            for q in quantities:
                if q in df.columns and np.isfinite(row[q]):
                    ref_rows.setdefault(q, []).append(float(fr[q][i]))
                    user_rows[q].append(float(row[q]))
            xs.append(float(row["x"])); ys.append(float(row["y"]))
    out = {}
    for q in quantities:
        if q in ref_rows and len(ref_rows[q]) >= 3:
            out[q] = _metrics(np.array(ref_rows[q]), np.array(user_rows[q]), spatial=False)
    return out, {"x": np.array(xs), "y": np.array(ys)}, "xyz"


def _reference_compare(df: pd.DataFrame, ref: pd.DataFrame, quantities: list[str]):
    """Compare against a user-supplied 'correct' CSV, not the built-in index."""
    if "probe" in df.columns and "probe" in ref.columns:
        a = df.copy(); b = ref.copy()
        a["probe"] = a["probe"].astype(int); b["probe"] = b["probe"].astype(int)
        m = pd.merge(a, b, on=["time", "probe"], suffixes=("_u", "_r"), how="inner")
        if len(m) < 3:
            m = pd.merge_asof(
                a.sort_values("time"), b.sort_values("time"),
                on="time", by="probe", suffixes=("_u", "_r"),
                direction="nearest", tolerance=1e-3,
            )
        out, mats = {}, {}
        for q in quantities:
            cu, cr = q + "_u", q + "_r"
            if cu not in m.columns or cr not in m.columns:
                continue
            ok = np.isfinite(m[cu]) & np.isfinite(m[cr])
            if ok.sum() < 3:
                continue
            out[q] = _metrics(m.loc[ok, cr].to_numpy(), m.loc[ok, cu].to_numpy(), spatial=False)
            pv_r = m.loc[ok].pivot_table(index="time", columns="probe", values=cr, aggfunc="mean")
            pv_u = m.loc[ok].pivot_table(index="time", columns="probe", values=cu, aggfunc="mean")
            mats[q] = (pv_r.to_numpy(), pv_u.to_numpy(),
                       pv_r.index.to_numpy(), list(pv_r.columns))
        return out, mats, "uploaded"

    if {"x", "y"}.issubset(df.columns) and {"x", "y"}.issubset(ref.columns):
        a = df.copy(); b = ref.copy()
        for d in (a, b):
            d["_x"] = d["x"].round(4); d["_y"] = d["y"].round(4)
        m = pd.merge(a, b, on=["time", "_x", "_y"], suffixes=("_u", "_r"), how="inner")
        out = {}
        for q in quantities:
            cu, cr = q + "_u", q + "_r"
            if cu in m.columns and cr in m.columns:
                ok = np.isfinite(m[cu]) & np.isfinite(m[cr])
                if ok.sum() >= 3:
                    out[q] = _metrics(m.loc[ok, cr].to_numpy(), m.loc[ok, cu].to_numpy(), spatial=False)
        return out, {}, "uploaded"

    raise ValueError("上传的正确数据必须和你的数据同表型：都有 probe，或都有 x/y")


def validate(csv_text: str, reference_csv: str | None = None) -> dict:
    df = _load(csv_text)
    quantities = [q for q in ("p", "ux", "uy") if q in df.columns]
    if not quantities:
        raise ValueError("至少需要 p / ux / uy 中的一列")
    mode = "long" if "probe" in df.columns else "xyz"
    mats = {}
    try:
        if reference_csv:
            ref = _load(reference_csv)
            scores, mats, mode = _reference_compare(df, ref, quantities)
        elif mode == "long":
            scores, mats, mode = _long_compare(df, quantities)
        else:
            scores, pts, mode = _xyz_compare(df, quantities)
    except ValueError:
        return _profile(df, quantities)
    if not scores:
        return _profile(df, quantities)



    # geometry: prefer the user's own x/y; otherwise borrow reference geometry
    if {"x", "y"}.issubset(df.columns):
        gx = df["x"].to_numpy(dtype=float)
        gy = df["y"].to_numpy(dtype=float)
        ok = np.isfinite(gx) & np.isfinite(gy)
        if ok.sum() >= 3:
            gx, gy = gx[ok], gy[ok]
            geom = {"source": "user", "length": float(np.ptp(gx)),
                    "height": float(np.ptp(gy)),
                    "aspect": float(np.ptp(gy) / (np.ptp(gx) + 1e-12))}
        else:
            geom = None
    else:
        geom = None
    if geom is None:
        fr = store.frame_at(0.2)
        geom = {"source": "reference", "length": float(np.ptp(fr["x"])),
                "height": float(np.ptp(fr["y"])),
                "aspect": float(np.ptp(fr["y"]) / (np.ptp(fr["x"]) + 1e-12))}

    main = "p" if "p" in scores else next(iter(scores))
    s = scores[main]
    min_a = min(v["A"] for v in scores.values())
    min_b = min(v["B"] for v in scores.values())
    if min_a >= 0.9 and min_b >= 0.8:
        verdict, color = "一致", "#16a34a"
    elif min_a >= 0.7:
        verdict, color = "部分量形状接近；有量需要检查", "#d97706"
    else:
        verdict, color = "明显不一致", "#dc2626"

    issues = []
    if abs(s["scale"]) > 2 or (abs(s["scale"]) < 0.5 and abs(s["scale"]) > 1e-9):
        issues.append(f"{main} 的均值比 user/reference≈{s['scale']:.2f}，先查单位/归一化/缩放。")
    if s["B"] < 0:
        issues.append("B<0：绝对误差大于参考方差；不要只报 A。")
    bad = [q for q, v in scores.items() if v["A"] < 0.5 or v["B"] < 0]
    if bad:
        issues.append("这些量的指标明显异常：" + "、".join(bad) + "；先查单位/列映射/时间对齐。")
    if "p" not in scores:
        issues.append("没有 p，无法核对压强；只能核对速度。")
    if mode == "xyz":
        issues.append("坐标模式把每个点映射到最近探针，只适合抽查，不等同于全表面比较。")

    hyps = diagnose_user.diagnose(df, scores, mats, mode, geom)
    if verdict == "一致":
        hyps = []

    # figure
    fig, axes = plt.subplots(2, 2, figsize=(10.5, 7.0))
    ax = axes[0, 0]
    if mode in ("long", "uploaded") and main in mats:
        ref, user, times, probes = mats[main]
        r = ref[np.isfinite(ref) & np.isfinite(user)]
        u = user[np.isfinite(ref) & np.isfinite(user)]
    else:
        r = np.array([x for x in []])  # placeholder, filled below
        u = np.array([])
    if mode == "xyz":
        r = np.array([], dtype=float); u = np.array([], dtype=float)
        # reuse scores only; scatter of x/y error instead
        ax.text(0.5, 0.5, f"{main}: A={s['A']:.3f}\nB={s['B']:.3f}\nRMSE={s['RMSE']:.3f}",
                ha="center", va="center", fontsize=12, transform=ax.transAxes)
        ax.set_axis_off()
        ax.set_title(f"{main} 指标")
    else:
        ax.scatter(r, u, s=4, alpha=0.35, color="#2563eb", label="user vs ref")
        lo, hi = float(np.nanmin([r.min(), u.min()])), float(np.nanmax([r.max(), u.max()]))
        ax.plot([lo, hi], [lo, hi], "k--", lw=1)
        ax.set_xlabel("reference"); ax.set_ylabel("user")
        ax.set_title(f"{main}: A={s['A']:.3f}, B={s['B']:.3f}")
        ax.grid(alpha=0.25)

    ax = axes[0, 1]
    if mode in ("long", "uploaded") and len(scores) > 0:
        q2 = "ux" if "ux" in scores else ("uy" if "uy" in scores else main)
        s2 = scores[q2]
        ax.bar(["A", "B"], [s2["A"], s2["B"]], color=["#2563eb", "#0ea5e9"])
        ax.axhline(0.8, color="#16a34a", ls="--", lw=1)
        ax.set_ylim(min(-0.2, s2["B"] - 0.1), 1.05)
        ax.set_title(f"{q2}: A/B（B 以参考为分母）")
        ax.grid(axis="y", alpha=0.25)
    else:
        ax.bar(list(scores), [v["A"] for v in scores.values()], color="#2563eb")
        ax.set_ylim(0, 1.05); ax.set_title("各物理量 A")

    ax = axes[1, 0]
    if mode in ("long", "uploaded") and main in mats:
        ref, user, times, probes = mats[main]
        idx = [0, len(probes) // 2, len(probes) - 1]
        for j in idx:
            ax.plot(times, ref[:, j], lw=1.1, label=f"ref probe {probes[j]}")
            ax.plot(times, user[:, j], "--", lw=0.9, label=f"user {probes[j]}")
        ax.set_xlabel("t [s]"); ax.set_ylabel(main)
        ax.set_title("三个代表探针：实线参考 / 虚线用户")
        ax.grid(alpha=0.25); ax.legend(fontsize=6, ncol=2)
    else:
        ax.axis("off")
        ax.text(0.5, 0.5, "坐标模式：无法画完整探针时序\n请看左上指标或右侧几何",
                ha="center", va="center", transform=ax.transAxes, fontsize=10)

    ax = axes[1, 1]
    if geom["source"] == "user":
        color = df[main] if main in df.columns else None
        ax.scatter(df["x"], df["y"], c=color, cmap="RdBu_r", s=12)
        ax.set_aspect("equal")
        ax.set_title(f"用户几何：L≈{geom['length']:.3f} m, H≈{geom['height']:.3f} m")
    else:
        fr = store.frame_at(0.2)
        ax.scatter(fr["x"], fr["y"], c=fr[main], cmap="RdBu_r", s=10)
        ax.set_aspect(4.0)
        ax.set_title("参考表面场（未提供用户 x/y）")
    ax.set_xlabel("x [m]"); ax.set_ylabel("y [m]")

    fig.tight_layout()
    vid = "validation-" + uuid.uuid4().hex[:8]
    png = OUT / f"{vid}.png"
    fig.savefig(png, dpi=165); plt.close(fig)

    rows = [{"quantity": q, **v} for q, v in scores.items()]
    payload = {"id": vid, "mode": mode, "verdict": verdict, "metrics": scores,
               "rows": rows, "issues": issues, "hypotheses": hyps, "figure": png.name,
               "geometry": geom, "ts": time.strftime("%Y-%m-%dT%H:%M:%S")}
    (OUT / f"{vid}.json").write_text(json.dumps(payload, ensure_ascii=False, indent=1), encoding="utf-8")

    lines = [f"**判定：{verdict}**", ""]
    for q, v in scores.items():
        lines.append(f"- {q}: A={v['A']:.3f}, B={v['B']:.3f}, RMSE={v['RMSE']:.3f}, "
                     f"bias={v['bias']:.3f}, 均值比={v['scale']:.2f}")
    if issues:
        lines += ["", "**需要先查**"] + [f"- {x}" for x in issues]
    if hyps:
        lines += ["", "**可能哪里错了（按可能性排序，逐条自查）**"]
        for h in hyps[:4]:
            lines.append(f"- 【{h['confidence']}】{h['title']}")
            lines.append(f"  证据：{h['evidence']}")
            lines.append(f"  自查：{h['check']}")
            lines.append(f"  修：{h['fix']}")
            lines.append(f"  怎么理解：{h['answer']}")
    lines += ["", f"几何：{geom['source']}，L≈{geom['length']:.3f} m，H≈{geom['height']:.3f} m，H/L≈{geom['aspect']:.3f}"]
    lines += ["", "这是与参考索引的数值对比；参考不是独立真值，单位/探针映射/时间窗都要一起看。"]
    return {"status": "ok", "verdict": verdict, "reply": "\n".join(lines), "metrics": scores,
            "rows": rows, "issues": issues, "hypotheses": hyps, "figure": png.name,
            "geometry": geom, "id": vid}

def _profile(df: pd.DataFrame, quantities: list[str]) -> dict:
    """User-only profile when no reference overlap is possible."""
    rows = []
    for q in quantities:
        v = pd.to_numeric(df[q], errors="coerce").dropna()
        if len(v):
            rows.append({"quantity": q, "n": int(len(v)),
                         "min": round(float(v.min()), 4),
                         "max": round(float(v.max()), 4),
                         "mean": round(float(v.mean()), 4)})
    if {"x", "y"}.issubset(df.columns):
        gx = df["x"].to_numpy(dtype=float); gy = df["y"].to_numpy(dtype=float)
        ok = np.isfinite(gx) & np.isfinite(gy)
        geom = {"source": "user", "length": float(np.ptp(gx[ok])),
                "height": float(np.ptp(gy[ok])),
                "aspect": float(np.ptp(gy[ok]) / (np.ptp(gx[ok]) + 1e-12))} if ok.sum() >= 3 else {"source": "none", "length": 0, "height": 0, "aspect": 0}
    else:
        geom = {"source": "none", "length": 0, "height": 0, "aspect": 0}

    fig, axes = plt.subplots(2, 2, figsize=(10.5, 7.0))
    ax = axes[0, 0]
    q0 = quantities[0]
    ax.scatter(df["time"], df[q0], s=5, alpha=0.5, color="#2563eb")
    ax.set_xlabel("t [s]"); ax.set_ylabel(q0); ax.set_title("用户数据：时间序列")
    ax.grid(alpha=0.25)
    ax = axes[0, 1]
    for q in quantities[1:]:
        ax.plot(df["time"], df[q], ".", ms=2, alpha=0.5, label=q)
    ax.set_xlabel("t [s]"); ax.set_title("其他物理量")
    if quantities[1:]:
        ax.legend(fontsize=7)
    ax.grid(alpha=0.25)
    ax = axes[1, 0]
    v = pd.to_numeric(df[q0], errors="coerce").dropna()
    ax.hist(v, bins=30, color="#0ea5e9", alpha=0.8)
    ax.set_xlabel(q0); ax.set_title("分布"); ax.grid(alpha=0.25)
    ax = axes[1, 1]
    if geom["source"] == "user":
        ax.scatter(df["x"], df["y"], c=df[q0] if q0 in df.columns else None,
                   cmap="RdBu_r", s=8)
        ax.set_aspect("equal")
        ax.set_title(f"用户几何：L≈{geom['length']:.3f} m")
    else:
        ax.axis("off")
        ax.text(0.5, 0.5, "没有可用的 x/y，无法画几何", ha="center",
                va="center", transform=ax.transAxes)
    fig.tight_layout()
    vid = "validation-" + uuid.uuid4().hex[:8]
    png = OUT / f"{vid}.png"; fig.savefig(png, dpi=165); plt.close(fig)

    payload = {"id": vid, "mode": "profile", "verdict": "无法对比（参考范围/列不足）",
               "rows": rows, "geometry": geom, "figure": png.name,
               "ts": time.strftime("%Y-%m-%dT%H:%M:%S")}
    (OUT / f"{vid}.json").write_text(json.dumps(payload, ensure_ascii=False, indent=1), encoding="utf-8")
    lines = ["**无法和参考数据对齐**，但我先把你的数据画像列出来：", ""]
    for r in rows:
        lines.append(f"- {r['quantity']}: n={r['n']}, min={r['min']}, max={r['max']}, mean={r['mean']}")
    if geom["source"] == "user":
        lines.append(f"- 几何：L≈{geom['length']:.3f} m, H≈{geom['height']:.3f} m, H/L≈{geom['aspect']:.3f}")
    lines += ["", "常见原因：时间窗超出参考范围、probe 编号不匹配、列名/单位不对、坐标不在鱼体附近。"]
    hyps = diagnose_user.profile_hypotheses(df)
    lines += ["", "**可能哪里错了（逐条自查）**"]
    for h in hyps:
        lines.append(f"- 【{h['confidence']}】{h['title']}")
        lines.append(f"  自查：{h['check']}")
        lines.append(f"  修：{h['fix']}")
    return {"status": "ok", "verdict": payload["verdict"], "reply": "\n".join(lines),
            "rows": rows, "metrics": {}, "issues": ["没有重叠点，未做 A/B 对比"],
            "hypotheses": hyps, "figure": png.name, "geometry": geom, "id": vid}

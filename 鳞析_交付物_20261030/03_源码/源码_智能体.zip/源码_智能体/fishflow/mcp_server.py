"""Minimal MCP server (stdio, JSON-RPC 2.0) for the fish-flow guard tools.

This is intentionally dependency-free: it speaks the small subset of MCP that
DSH / OpenClaw / Hermes need (initialize, tools/list, tools/call, ping).

Run:  python -m fishflow.mcp_server
Logs go to stderr; stdout is reserved for JSON-RPC frames.
"""

from __future__ import annotations

import json
import sys
import traceback

from . import diagnose, metrics, plots, report, store

PROTOCOL = "2024-11-05"

TOOLS = [
    {
        "name": "diagnose",
        "description": "Answer a methodology question with a curated guardrail and citations "
                       "(R² A/B, DMD extrapolation, Hankel pitfalls, trim rules, cusp probes, ...).",
        "inputSchema": {
            "type": "object",
            "properties": {"question": {"type": "string"}},
            "required": ["question"],
        },
    },
    {
        "name": "query",
        "description": "Query one probe's time series for p/ux/uy in a time window.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "probe": {"type": "integer", "minimum": 0, "maximum": 403},
                "t0": {"type": "number"},
                "t1": {"type": "number"},
                "quantity": {"type": "string", "enum": ["p", "ux", "uy"]},
            },
            "required": ["probe", "t0", "t1"],
        },
    },
    {
        "name": "compare",
        "description": "Authoritative A/B/RMSE for dmd_v2 vs dmd_old, or DMD v2 vs the runnable physical output.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "mode": {"type": "string", "enum": ["authoritative", "physical"]},
                "quantity": {"type": "string", "enum": ["p", "ux", "uy"]},
                "trim": {"type": "integer", "minimum": 0, "maximum": 100},
            },
        },
    },
    {
        "name": "manifest",
        "description": "Return index metadata (frames, probes, rows, dt).",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "field",
        "description": "Render a surface-field figure at a time and return its path.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "t": {"type": "number"},
                "quantity": {"type": "string", "enum": ["p", "ux", "uy"]},
                "out": {"type": "string"},
            },
            "required": ["t"],
        },
    },
    {
        "name": "report",
        "description": "Build the HTML/Markdown evidence report and return the paths.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "run_physical",
        "description": "Run the isolated physical model (1 s ≈ 105 s), build its index, and compare with DMD.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "freq": {"type": "number", "minimum": 0.3, "maximum": 6.0},
                "t_end": {"type": "number", "minimum": 0.005, "maximum": 5.0},
                "dt": {"type": "number", "minimum": 0.0005, "maximum": 0.01},
                "quantity": {"type": "string", "enum": ["p", "ux", "uy"]},
                "trim": {"type": "integer", "minimum": 0, "maximum": 100},
                "do_compare": {"type": "boolean"},
                "background": {"type": "boolean"},
            },
        },
    },
    {
        "name": "run_status",
        "description": "Check a physical run (latest if run_id omitted): status, stage, percent, result.",
        "inputSchema": {
            "type": "object",
            "properties": {"run_id": {"type": "string"}},
        },
    },
    {
        "name": "research",
        "description": "Closed loop: locate a run, compare with DMD, apply guardrails, write a research record.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "freq": {"type": "number", "minimum": 0.3, "maximum": 6.0},
                "t_end": {"type": "number", "minimum": 0.005, "maximum": 5.0},
                "dt": {"type": "number", "minimum": 0.0005, "maximum": 0.01},
                "trim": {"type": "integer", "minimum": 0, "maximum": 100},
                "quantity": {"type": "string", "enum": ["p", "ux", "uy"]},
                "execute": {"type": "boolean"},
                "run_dir": {"type": "string"},
            },
        },
    },
    {
        "name": "research_log",
        "description": "Return the latest research records (hypothesis, steps, metrics, verdict, conclusion).",
        "inputSchema": {
            "type": "object",
            "properties": {"n": {"type": "integer", "minimum": 1, "maximum": 50}},
        },
    },
]


def _text(s: str) -> dict:
    return {"content": [{"type": "text", "text": s}], "isError": False}


def _call(name: str, args: dict) -> dict:
    if name == "diagnose":
        r = diagnose.answer(args.get("question", ""))
        return _text(json.dumps(r, ensure_ascii=False, indent=1))
    if name == "query":
        r = store.query(
            int(args["probe"]), float(args["t0"]), float(args["t1"]),
            args.get("quantity", "p"),
        )
        return _text(json.dumps(r, ensure_ascii=False))
    if name == "compare":
        if args.get("mode") == "physical":
            from .compare import compare_physical
            return _text(json.dumps(
                compare_physical(args.get("quantity", "p"), int(args.get("trim", 0))),
                ensure_ascii=False, indent=1))
        return _text(json.dumps(
            {"rows": metrics.table(), "mean": metrics.mean_scores(),
             "definitions": {"A": "per-frame spatial corr² (shape)",
                             "B": "1 - SSE/SST (absolute)"}},
            ensure_ascii=False, indent=1))
    if name == "manifest":
        m = dict(store.manifest())
        m.pop("files", None)
        return _text(json.dumps(m, ensure_ascii=False, indent=1))
    if name == "field":
        out = plots.field_plot(float(args["t"]), args.get("quantity", "p"),
                               args.get("out", "outputs/field.png"))
        return _text(json.dumps({"figure": str(out)}, ensure_ascii=False))
    if name == "report":
        return _text(json.dumps(report.build(), ensure_ascii=False, indent=1))
    if name == "run_physical":
        from .runner import run_physical, start_background
        if args.get("background"):
            return _text(json.dumps(start_background(
                freq=float(args.get("freq", 2.0)),
                t_end=float(args.get("t_end", 1.0)),
                dt=float(args.get("dt", 0.001)),
                do_compare=bool(args.get("do_compare", True)),
                quantity=args.get("quantity", "p"),
                trim=int(args.get("trim", 24)),
            ), ensure_ascii=False, indent=1))
        return _text(json.dumps(run_physical(
            freq=float(args.get("freq", 2.0)),
            t_end=float(args.get("t_end", 1.0)),
            dt=float(args.get("dt", 0.001)),
            do_compare=bool(args.get("do_compare", True)),
            quantity=args.get("quantity", "p"),
            trim=int(args.get("trim", 24)),
        ), ensure_ascii=False, indent=1))
    if name == "run_status":
        from .runner import status
        return _text(json.dumps(status(args.get("run_id")), ensure_ascii=False, indent=1))
    if name == "research":
        from .research import research
        return _text(json.dumps(research(
            goal=args.get("goal", "extrapolation"),
            freq=float(args.get("freq", 3.0)),
            t_end=float(args.get("t_end", 1.0)),
            dt=float(args.get("dt", 0.001)),
            trim=int(args.get("trim", 24)),
            quantity=args.get("quantity", "p"),
            execute=bool(args.get("execute", False)),
            run_dir=args.get("run_dir"),
        ), ensure_ascii=False, indent=1))
    if name == "research_log":
        from .research import log
        return _text(json.dumps({"records": log(int(args.get("n", 10)))},
                                ensure_ascii=False, indent=1))
    raise ValueError(f"unknown tool: {name}")


def _handle(req: dict) -> dict | None:
    method = req.get("method")
    rid = req.get("id")
    params = req.get("params") or {}

    if method == "initialize":
        return {
            "protocolVersion": params.get("protocolVersion", PROTOCOL),
            "capabilities": {"tools": {"listChanged": False}},
            "serverInfo": {"name": "fishflow", "version": "0.1.0"},
        }
    if method == "ping":
        return {}
    if method == "tools/list":
        return {"tools": TOOLS}
    if method == "tools/call":
        name = params.get("name")
        try:
            return _call(name, params.get("arguments") or {})
        except Exception as exc:
            traceback.print_exc(file=sys.stderr)
            return {"content": [{"type": "text", "text": f"{type(exc).__name__}: {exc}"}],
                    "isError": True}
    if method in ("notifications/initialized", "notifications/cancelled"):
        return None
    if rid is None:
        return None
    raise KeyError(method)


def main() -> int:
    if hasattr(sys.stdin, "reconfigure"):
        sys.stdin.reconfigure(encoding="utf-8", errors="replace")
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")

    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
        except json.JSONDecodeError:
            continue
        rid = req.get("id")
        try:
            result = _handle(req)
        except KeyError as exc:
            if rid is None:
                continue
            err = {"jsonrpc": "2.0", "id": rid,
                   "error": {"code": -32601, "message": f"method not found: {exc}"}}
            sys.stdout.write(json.dumps(err, ensure_ascii=False) + "\n")
            sys.stdout.flush()
            continue

        if result is None and rid is None:
            continue
        resp = {"jsonrpc": "2.0", "id": rid, "result": result}
        sys.stdout.write(json.dumps(resp, ensure_ascii=False) + "\n")
        sys.stdout.flush()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

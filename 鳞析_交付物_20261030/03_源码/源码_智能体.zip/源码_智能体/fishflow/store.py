"""Parquet-backed access to a 404-probe field table.

The default index is `data/index` (DMD v2).  Pass `index_dir` to read another
index built with `build_index.py --out` (e.g. the physical model).
"""

from __future__ import annotations

import json
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import numpy as np
import pyarrow.parquet as pq

from . import config


class IndexNotReady(RuntimeError):
    pass


_MANIFEST_CACHE: dict[str, dict] = {}


def _dir(index_dir: str | Path | None) -> Path:
    return Path(index_dir) if index_dir is not None else config.INDEX


def manifest(index_dir: str | Path | None = None) -> dict:
    p = _dir(index_dir) / "manifest.json"
    key = str(p)
    if key in _MANIFEST_CACHE:
        return _MANIFEST_CACHE[key]
    if not p.exists():
        raise IndexNotReady(
            f"index not found at {p}; run `python -m fishflow.build_index` first"
        )
    m = json.loads(p.read_text(encoding="utf-8"))
    _MANIFEST_CACHE[key] = m
    return m


def _probe_file(probe: int, index_dir: str | Path | None = None) -> Path:
    return _dir(index_dir) / f"probe_{probe:04d}.parquet"


def nearest_time(t: float, index_dir: str | Path | None = None) -> float:
    m = manifest(index_dir)
    k = round((float(t) - m["time_start"]) / m["dt"])
    k = max(0, min(int(m["n_frames"]) - 1, k))
    return round(m["time_start"] + k * m["dt"], 9)


def query(probe: int, t0: float, t1: float, quantity: str = "p",
          index_dir: str | Path | None = None) -> dict:
    """Return one probe's time series in [t0, t1] for a quantity."""
    if not 0 <= int(probe) < config.N_PROBES:
        raise ValueError(f"probe must be 0..{config.N_PROBES - 1}")
    if quantity not in ("p", "ux", "uy", "x", "y"):
        raise ValueError("quantity must be p/ux/uy/x/y")
    m = manifest(index_dir)
    t0, t1 = sorted((float(t0), float(t1)))
    t0 = max(t0, float(m["time_start"]))
    t1 = min(t1, float(m["time_end"]))
    if t1 < t0:
        return {"probe": int(probe), "quantity": quantity, "time": [], "value": [], "n": 0}

    col = config.COLUMNS[quantity]
    table = pq.read_table(
        str(_probe_file(int(probe), index_dir)),
        columns=[config.COLUMNS["time"], col],
        filters=[
            (config.COLUMNS["time"], ">=", t0 - 1e-9),
            (config.COLUMNS["time"], "<=", t1 + 1e-9),
        ],
    )
    t = table.column(config.COLUMNS["time"]).to_numpy()
    v = table.column(col).to_numpy()
    order = np.argsort(t)
    return {
        "probe": int(probe),
        "quantity": quantity,
        "time": np.round(t[order], 9).tolist(),
        "value": np.round(v[order], 10).tolist(),
        "n": int(len(t)),
    }


def _read_frame_row(probe: int, t: float, index_dir: str | Path | None) -> dict | None:
    path = _probe_file(probe, index_dir)
    if not path.exists():
        return None
    table = pq.read_table(
        str(path),
        columns=[config.COLUMNS["time"], config.COLUMNS["x"], config.COLUMNS["y"],
                 config.COLUMNS["p"], config.COLUMNS["ux"], config.COLUMNS["uy"]],
        filters=[
            (config.COLUMNS["time"], ">=", t - 1e-9),
            (config.COLUMNS["time"], "<=", t + 1e-9),
        ],
    )
    if table.num_rows == 0:
        return None
    row = {k: table.column(config.COLUMNS[k])[0].as_py() for k in ("time", "x", "y", "p", "ux", "uy")}
    row["probe"] = probe
    return row


def frame_at(t: float, index_dir: str | Path | None = None, max_workers: int = 24) -> dict:
    """Load all 404 probes at the nearest stored frame."""
    if not _probe_file(0, index_dir).exists():
        raise IndexNotReady(f"per-probe index not built at {_dir(index_dir)}")
    t = nearest_time(t, index_dir)
    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        rows = list(ex.map(lambda p: _read_frame_row(p, t, index_dir), range(config.N_PROBES)))
    rows = [r for r in rows if r is not None]
    if not rows:
        raise LookupError(f"no rows at t={t}")
    rows.sort(key=lambda r: r["probe"])
    return {
        "time": t,
        "probe": np.array([r["probe"] for r in rows], dtype=int),
        "x": np.array([r["x"] for r in rows], dtype=float),
        "y": np.array([r["y"] for r in rows], dtype=float),
        "p": np.array([r["p"] for r in rows], dtype=float),
        "ux": np.array([r["ux"] for r in rows], dtype=float),
        "uy": np.array([r["uy"] for r in rows], dtype=float),
    }


def split_surfaces(frame: dict) -> dict:
    """Upper 0..201 (nose->tail), lower 202..403 (nose->tail)."""
    up = slice(0, config.N_SIDE)
    lo = slice(config.N_SIDE, 2 * config.N_SIDE)
    return {
        "time": frame["time"],
        "upper": {k: frame[k][up] for k in ("x", "y", "p", "ux", "uy", "probe")},
        "lower": {k: frame[k][lo] for k in ("x", "y", "p", "ux", "uy", "probe")},
    }


def probe_geometry(index_dir: str | Path | None = None) -> dict:
    """Static x/y positions (from one frame) for plotting."""
    m = manifest(index_dir)
    f = frame_at(float(m["time_start"]), index_dir)
    return {"probe": f["probe"], "x": f["x"], "y": f["y"]}


def stats(quantity: str = "p", index_dir: str | Path | None = None) -> dict:
    """Global min/max/mean over the indexed table, chunked."""
    if quantity not in ("p", "ux", "uy"):
        raise ValueError("quantity must be p/ux/uy")
    col = config.COLUMNS[quantity]
    vals = []
    for p in range(config.N_PROBES):
        arr = pq.read_table(str(_probe_file(p, index_dir)), columns=[col]).column(col).to_numpy()
        vals.append((float(np.min(arr)), float(np.max(arr)), float(np.mean(arr))))
    mins, maxs, means = zip(*vals)
    return {
        "quantity": quantity,
        "min": min(mins),
        "max": max(maxs),
        "mean": float(np.mean(means)),
        "probes": config.N_PROBES,
    }

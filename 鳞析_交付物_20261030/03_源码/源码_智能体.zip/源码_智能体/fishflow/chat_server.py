"""Local HTTP server for the chat UI: `python -m fishflow.chat_server`.

Routes:
  GET  /                 chat.html
  POST /api/chat         {"message": "...", "history": [...]} -> {"reply": ...}
  GET  /outputs/<path>   report / gif / dashboard / figures
  GET  /api/health       {"ok": true}
"""

from __future__ import annotations

import argparse
import base64
import hmac
import json
import mimetypes
import os
import socket
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse

from . import chat, config, image_tool, point_lookup, probe_view, sim_agent, store, user_csv, validate_user

HERE = Path(__file__).resolve().parent
CHAT_HTML = HERE / "chat.html"
POINT_HTML = HERE / "point.html"
OUT = config.OUTPUTS.resolve()
MAX_REQUEST_BYTES = 12 * 1024 * 1024


class Handler(BaseHTTPRequestHandler):
    server_version = "LinXiChat/1.0"
    access_code = ""

    def log_message(self, fmt, *args):
        pass

    def _authorized(self) -> bool:
        if not self.access_code:
            return True
        auth = self.headers.get("Authorization", "")
        if not auth.startswith("Basic "):
            return False
        try:
            raw = base64.b64decode(auth[6:]).decode("utf-8")
            _user, password = raw.split(":", 1)
            return hmac.compare_digest(password, self.access_code)
        except Exception:
            return False

    def _unauth(self):
        body = ("需要访问码。浏览器弹窗里：用户名随便填，密码填访问码。"
                "<br>Access code required.").encode("utf-8")
        self.send_response(401)
        self.send_header("WWW-Authenticate", 'Basic realm="LinXi public"')
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send(self, code: int, data: bytes, ctype: str):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _json(self, code: int, obj):
        self._send(code, json.dumps(obj, ensure_ascii=False).encode("utf-8"),
                   "application/json; charset=utf-8")

    def _file(self, path: Path, ctype: str | None = None):
        if not path.exists() or not path.is_file():
            self._json(404, {"error": "not_found"})
            return
        ctype = ctype or mimetypes.guess_type(str(path))[0] or "application/octet-stream"
        self._send(200, path.read_bytes(), ctype)

    def do_GET(self):
        p = urlparse(self.path).path
        if p != "/api/health" and not self._authorized():
            self._unauth()
            return
        if p in ("/", "/index.html"):
            self._file(CHAT_HTML, "text/html; charset=utf-8")
            return
        if p == "/api/health":
            self._json(200, {"ok": True, "service": "linxi-chat"})
            return
        if p == "/point":
            self._file(POINT_HTML, "text/html; charset=utf-8")
            return
        if p == "/api/point":
            from urllib.parse import parse_qs
            qs = parse_qs(urlparse(self.path).query)
            try:
                res = point_lookup.lookup(
                    float(qs.get("x", ["2.5"])[0]),
                    float(qs.get("y", ["0.0"])[0]),
                    float(qs.get("t", ["0.2"])[0]),
                )
                self._json(200, res)
            except Exception as exc:
                self._json(400, {"error": str(exc)})
            return
        if p == "/api/range":
            self._json(200, store.manifest())
            return
        if p == "/api/frame":
            from urllib.parse import parse_qs
            qs = parse_qs(urlparse(self.path).query)
            try:
                self._json(200, probe_view.frame(float(qs.get("t", ["0.2"])[0])))
            except Exception as exc:
                self._json(400, {"error": str(exc)})
            return
        if p == "/api/probe":
            from urllib.parse import parse_qs
            qs = parse_qs(urlparse(self.path).query)
            try:
                self._json(200, probe_view.probe_data(
                    int(qs.get("probe", ["0"])[0]),
                    float(qs.get("t", ["0.2"])[0]),
                ))
            except Exception as exc:
                self._json(400, {"error": str(exc)})
            return
        if p.startswith("/outputs/"):
            rel = unquote(p[len("/outputs/"):]).replace("\\", "/")
            target = (OUT / rel).resolve()
            if not str(target).startswith(str(OUT) + "\\") and not str(target).startswith(str(OUT) + "/"):
                self._json(403, {"error": "forbidden"})
                return
            self._file(target)
            return
        self._json(404, {"error": "not_found"})

    def do_POST(self):
        p = urlparse(self.path).path
        if not self._authorized():
            self._unauth()
            return
        if p not in ("/api/chat", "/api/simulate", "/api/simulate_image", "/api/validate"):
            self._json(404, {"error": "not_found"})
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length < 0 or length > MAX_REQUEST_BYTES:
                self._json(413, {"error": "request_too_large", "max_bytes": MAX_REQUEST_BYTES})
                return
            raw = self.rfile.read(length).decode("utf-8")
            data = json.loads(raw) if raw else {}
            if not isinstance(data, dict):
                raise ValueError("请求体必须是 JSON 对象")
            if p == "/api/validate":
                csv_text = str(data.get("csv", "") or "")
                generated = None
                if not csv_text and data.get("pasted"):
                    built = user_csv.parse_to_csv(str(data["pasted"]))
                    csv_text = built["csv"]
                    generated = built["file"]
                result = validate_user.validate(csv_text, data.get("reference_csv") or None)
                if generated:
                    result["csv_file"] = generated
            elif p == "/api/simulate_image":
                result = image_tool.simulate_from_image(
                    data.get("image", ""),
                    length=float(data.get("length", 0.15)),
                    n_sensors=int(data.get("n_sensors", 16)),
                    speed=float(data.get("speed", 0.2)),
                    source_x=float(data.get("source_x", 0.6)),
                    source_y=float(data.get("source_y", 0.3)),
                    freq=float(data.get("freq", 2.0)),
                    noise=float(data.get("noise", 0.05)),
                )
            elif p == "/api/simulate":
                result = sim_agent.simulate(data.get("params") or {})
            else:
                result = chat.answer(str(data.get("message", "")), data.get("history") or [])
            self._json(200, result)
        except (ValueError, UnicodeDecodeError) as exc:
            self._json(400, {"reply": f"请求无效：{exc}", "sources": [], "kind": "error"})
        except Exception as exc:
            self._json(500, {"reply": f"服务出错：{type(exc).__name__}: {exc}", "sources": [], "kind": "error"})


def _lan_ip() -> str:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--host", default="127.0.0.1",
                    help="127.0.0.1 = only this PC; 0.0.0.0 = LAN")
    ap.add_argument("--no-open", action="store_true")
    ap.add_argument("--access-code", default=os.environ.get("FISHFLOW_ACCESS_CODE", ""),
                    help="公共访问码；留空则仅本机/局域网无认证")
    args = ap.parse_args()
    Handler.access_code = args.access_code

    srv = ThreadingHTTPServer((args.host, args.port), Handler)
    local = f"http://127.0.0.1:{args.port}/"
    print(f"[鳞析] local: {local}")
    if args.host == "0.0.0.0":
        print(f"[鳞析] LAN  : http://{_lan_ip()}:{args.port}/")
        print("        同 Wi-Fi/校园网的设备可以打开；首次可能需要在防火墙允许 Python。")
    print("        Ctrl+C 停止")
    if args.access_code:
        print("[鳞析] public access: 需要访问码（用户名任意，密码=访问码）")
    if not args.no_open:
        threading.Timer(0.8, lambda: webbrowser.open(local)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        srv.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

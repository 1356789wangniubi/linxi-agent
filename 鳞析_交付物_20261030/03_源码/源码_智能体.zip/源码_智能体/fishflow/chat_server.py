"""Local HTTP server for the chat UI: `python -m fishflow.chat_server`.

Routes:
  GET  /                 chat.html
  POST /api/chat         {"message": "...", "history": [...]} -> {"reply": ...}
  GET  /outputs/<path>   report / gif / dashboard / figures
  GET  /api/health       {"ok": true}
"""

from __future__ import annotations

import argparse
import base64
import hmac
import json
import mimetypes
import os
import socket
import threading
import time
from collections import deque
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse

from . import chat, config, image_tool, point_lookup, probe_view, sim_agent, store, user_csv, validate_user

HERE = Path(__file__).resolve().parent
CHAT_HTML = HERE / "chat.html"
POINT_HTML = HERE / "point.html"
OUT = config.OUTPUTS.resolve()
MAX_REQUEST_BYTES = 12 * 1024 * 1024
# Shared limits apply to all clients, including clients behind a tunnel.
_REQUEST_TIMES = deque()
_LIMIT_LOCK = threading.Lock()
_WORKERS = threading.BoundedSemaphore(1)  # matplotlib state is process-global


def _allow_work() -> bool:
    now = time.monotonic()
    with _LIMIT_LOCK:
        while _REQUEST_TIMES and now - _REQUEST_TIMES[0] >= 86400:
            _REQUEST_TIMES.popleft()
        if (len(_REQUEST_TIMES) >= 200
                or sum(now - t < 3600 for t in _REQUEST_TIMES) >= 60
                or sum(now - t < 60 for t in _REQUEST_TIMES) >= 6):
            return False
        _REQUEST_TIMES.append(now)
        return True


class Handler(BaseHTTPRequestHandler):
    server_version = "LinXiChat/1.0"
    access_code = ""

    def setup(self):
        super().setup()
        self.connection.settimeout(20)

    def log_message(self, fmt, *args):
        pass

    def _authorized(self) -> bool:
        if not self.access_code:
            return True
        auth = self.headers.get("Authorization", "")
        if not auth.startswith("Basic "):
            return False
        try:
            raw = base64.b64decode(auth[6:]).decode("utf-8")
            _user, password = raw.split(":", 1)
            return hmac.compare_digest(password, self.access_code)
        except Exception:
            return False

    def _unauth(self):
        body = ("需要访问码。浏览器弹窗里：用户名随便填，密码填访问码。"
                "<br>Access code required.").encode("utf-8")
        self.send_response(401)
        self.send_header("WWW-Authenticate", 'Basic realm="LinXi public"')
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send(self, code: int, data: bytes, ctype: str):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        if code == 429:
            self.send_header("Retry-After", "60")
        self.end_headers()
        self.wfile.write(data)

    def _json(self, code: int, obj):
        self._send(code, json.dumps(obj, ensure_ascii=False).encode("utf-8"),
                   "application/json; charset=utf-8")

    def _file(self, path: Path, ctype: str | None = None):
        if not path.exists() or not path.is_file():
            self._json(404, {"error": "not_found"})
            return
        ctype = ctype or mimetypes.guess_type(str(path))[0] or "application/octet-stream"
        self._send(200, path.read_bytes(), ctype)

    def do_GET(self):
        try:
            self._handle_get()
        except Exception:
            self._json(500, {"error": "service_unavailable"})

    def _handle_get(self):
        p = urlparse(self.path).path
        if p != "/api/health" and not self._authorized():
            self._unauth()
            return
        if p in ("/", "/index.html"):
            self._file(CHAT_HTML, "text/html; charset=utf-8")
            return
        if p == "/api/health":
            self._json(200, {"ok": True, "service": "linxi-chat"})
            return
        if p == "/point":
            self._file(POINT_HTML, "text/html; charset=utf-8")
            return
        if p == "/api/point":
            from urllib.parse import parse_qs
            qs = parse_qs(urlparse(self.path).query)
            try:
                res = point_lookup.lookup(
                    float(qs.get("x", ["2.5"])[0]),
                    float(qs.get("y", ["0.0"])[0]),
                    float(qs.get("t", ["0.2"])[0]),
                )
                self._json(200, res)
            except Exception as exc:
                self._json(400, {"error": "invalid_query"})
            return
        if p == "/api/range":
            manifest = store.manifest()
            self._json(200, {k: manifest[k] for k in (
                "n_probes", "n_frames", "n_rows", "time_start", "time_end", "dt"
            ) if k in manifest})
            return
        if p == "/api/frame":
            from urllib.parse import parse_qs
            qs = parse_qs(urlparse(self.path).query)
            try:
                self._json(200, probe_view.frame(float(qs.get("t", ["0.2"])[0])))
            except Exception as exc:
                self._json(400, {"error": "invalid_query"})
            return
        if p == "/api/probe":
            from urllib.parse import parse_qs
            qs = parse_qs(urlparse(self.path).query)
            try:
                self._json(200, probe_view.probe_data(
                    int(qs.get("probe", ["0"])[0]),
                    float(qs.get("t", ["0.2"])[0]),
                ))
            except Exception as exc:
                self._json(400, {"error": "invalid_query"})
            return
        if p.startswith("/outputs/"):
            rel = unquote(p[len("/outputs/"):]).replace("\\", "/")
            target = (OUT / rel).resolve()
            if not target.is_relative_to(OUT):
                self._json(403, {"error": "forbidden"})
                return
            if (target.suffix.lower() not in {".png", ".jpg", ".jpeg", ".gif", ".svg", ".csv", ".json", ".html", ".mp4", ".webm"}
                    or any(part.startswith(".") for part in Path(rel).parts)
                    or any(word in target.name.lower() for word in ("secret", "token", "credential", "tunnel", "cloudflared"))):
                self._json(403, {"error": "forbidden"})
                return
            self._file(target)
            return
        self._json(404, {"error": "not_found"})

    def do_POST(self):
        if not self._authorized():
            self._unauth()
            return
        origin = self.headers.get("Origin")
        if origin and urlparse(origin).netloc != self.headers.get("Host", ""):
            self._json(403, {"error": "origin_not_allowed"})
            return
        if not _allow_work():
            self._json(429, {"error": "rate_limited", "reply": "演示调用额度已用完，请稍后再试。"})
            return
        if not _WORKERS.acquire(blocking=False):
            self._json(503, {"error": "busy", "reply": "服务繁忙，请稍后再试。"})
            return
        try:
            self._handle_post()
        finally:
            _WORKERS.release()

    def _handle_post(self):
        p = urlparse(self.path).path
        if not self._authorized():
            self._unauth()
            return
        if p not in ("/api/chat", "/api/simulate", "/api/simulate_image", "/api/validate"):
            self._json(404, {"error": "not_found"})
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length < 0 or length > MAX_REQUEST_BYTES:
                self._json(413, {"error": "request_too_large", "max_bytes": MAX_REQUEST_BYTES})
                return
            raw = self.rfile.read(length).decode("utf-8")
            data = json.loads(raw) if raw else {}
            if not isinstance(data, dict):
                raise ValueError("请求体必须是 JSON 对象")
            if p == "/api/validate":
                csv_text = str(data.get("csv", "") or "")
                generated = None
                if not csv_text and data.get("pasted"):
                    built = user_csv.parse_to_csv(str(data["pasted"]))
                    csv_text = built["csv"]
                    generated = built["file"]
                # This argument is CSV text, parsed with io.StringIO, not a path.
                reference_csv = data.get("reference_csv") or None
                if reference_csv is not None and not isinstance(reference_csv, str):
                    raise ValueError("参考表必须是 CSV 文本")
                result = validate_user.validate(csv_text, reference_csv)
                if generated:
                    result["csv_file"] = generated
            elif p == "/api/simulate_image":
                result = image_tool.simulate_from_image(
                    data.get("image", ""),
                    length=float(data.get("length", 0.15)),
                    n_sensors=int(data.get("n_sensors", 16)),
                    speed=float(data.get("speed", 0.2)),
                    source_x=float(data.get("source_x", 0.6)),
                    source_y=float(data.get("source_y", 0.3)),
                    freq=float(data.get("freq", 2.0)),
                    noise=float(data.get("noise", 0.05)),
                )
            elif p == "/api/simulate":
                result = sim_agent.simulate(data.get("params") or {})
            else:
                message = data.get("message", "")
                history = data.get("history") or []
                if not isinstance(message, str) or len(message) > 4000:
                    raise ValueError("消息过长或格式无效")
                if not isinstance(history, list):
                    raise ValueError("历史消息格式无效")
                history = history[-6:]
                for item in history:
                    if (not isinstance(item, dict)
                            or item.get("role") not in ("user", "assistant")
                            or not isinstance(item.get("content"), str)
                            or len(item["content"]) > 4000):
                        raise ValueError("历史消息格式无效")
                result = chat.answer(message, history)
            self._json(200, result)
        except (ValueError, UnicodeDecodeError) as exc:
            self._json(400, {"reply": "请求无效，请检查输入格式和大小。", "sources": [], "kind": "error"})
        except Exception as exc:
            self._json(500, {"reply": "服务暂时不可用，请联系维护者检查服务端日志。", "sources": [], "kind": "error"})


class BoundedHTTPServer(ThreadingHTTPServer):
    """Bound connection threads as well as the expensive task queue."""

    daemon_threads = True

    def __init__(self, *args, **kwargs):
        self._connections = threading.BoundedSemaphore(8)
        super().__init__(*args, **kwargs)

    def process_request(self, request, client_address):
        if not self._connections.acquire(blocking=False):
            self.shutdown_request(request)
            return
        try:
            super().process_request(request, client_address)
        except BaseException:
            self._connections.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self._connections.release()


def _lan_ip() -> str:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--host", default="127.0.0.1",
                    help="127.0.0.1 = only this PC; 0.0.0.0 = LAN")
    ap.add_argument("--no-open", action="store_true")
    ap.add_argument("--access-code", default=os.environ.get("FISHFLOW_ACCESS_CODE", ""),
                    help="独立随机访问码；留空只允许本机监听")
    args = ap.parse_args()
    if args.host not in ("127.0.0.1", "localhost", "::1") and len(args.access_code) < 16:
        ap.error("非本机访问必须设置至少16字符的独立随机访问码")
    if args.access_code and len(args.access_code) < 16:
        ap.error("访问码至少需要16字符，请更换后重新启动")
    Handler.access_code = args.access_code

    config.ensure_dirs()
    srv = BoundedHTTPServer((args.host, args.port), Handler)
    local = f"http://127.0.0.1:{args.port}/"
    print(f"[鳞析] local: {local}")
    if args.host == "0.0.0.0":
        print(f"[鳞析] LAN  : http://{_lan_ip()}:{args.port}/")
        print("        同 Wi-Fi/校园网的设备可以打开；首次可能需要在防火墙允许 Python。")
    print("        Ctrl+C 停止")
    if args.access_code:
        print("[鳞析] public access: 需要访问码（用户名任意，密码=访问码）")
    if not args.no_open:
        threading.Timer(0.8, lambda: webbrowser.open(local)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        srv.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

"""Detached worker for `fishflow run --background`.

Invoked as: python -m fishflow.runner_worker <run_dir> <payload-json>
Writes status.json around the stages; run_one.py writes progress.json per step.
"""

from __future__ import annotations

import json
import sys
import traceback
from pathlib import Path

from . import runner


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    run_dir = Path(sys.argv[1])
    payload = json.loads(sys.argv[2])
    params = payload["params"]
    status_path = run_dir / "status.json"
    base = {
        "run_id": run_dir.name,
        "params": params,
        "started_at": runner._now(),
    }

    def write(**kw):
        d = dict(base)
        d.update(kw)
        d["updated_at"] = runner._now()
        runner._write_json(status_path, d)

    def cb(stage: str, percent: float):
        write(status="running", stage=stage, percent=percent)

    try:
        write(status="running", stage="starting", percent=0)
        res = runner.run_physical(
            freq=params["freq"], t_end=params["t_end"], dt=params["dt"],
            u_inf=params.get("u_inf", 1.0), length=params.get("length", 1.0),
            do_compare=bool(payload.get("do_compare", True)),
            quantity=payload.get("quantity", "p"),
            trim=int(payload.get("trim", 24)),
            run_dir=run_dir,
            progress_path=run_dir / "progress.json",
            status_cb=cb,
        )
        ok = res.get("status") == "ok"
        write(status=res.get("status", "error"),
              stage="done" if ok else "error",
              percent=100 if ok else 0,
              result=res)
    except Exception as exc:
        write(status="error", stage="error", percent=0,
              error=f"{type(exc).__name__}: {exc}",
              traceback=traceback.format_exc()[-4000:])
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

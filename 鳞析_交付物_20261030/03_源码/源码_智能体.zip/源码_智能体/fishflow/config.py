"""Shared paths, dataset registry and constants for the fish-flow guard agent."""

from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DELIVERY = ROOT / "交付包"
INDEX = ROOT / "data" / "index"
INDEX_PHYSICAL = ROOT / "data" / "index_physical"
OUTPUTS = ROOT / "outputs"
PROVENANCE = ROOT / "data" / "provenance.jsonl"

# canonical dataset keys used by tools and the skill
DATASETS = {
    "dmd_v2": {
        "label": "DMD v2 (POD300 + Hankel12 + DMD1200)",
        "path": DELIVERY / "02_主数据表" / "probe_table_DMD_v2_trimmed.tsv",
        "indexed": True,
        "can_extrapolate": False,
        "note": "主交付表；49,800 帧 × 404 探针；只可复现，不可外推。",
    },
    "dmd_old": {
        "label": "旧 DMD (直接 Hankel-DMD，无 POD)",
        "path": DELIVERY / "03_对照数据表" / "probe_table_DMD_旧方法_trimmed.tsv",
        "indexed": False,
        "can_extrapolate": False,
        "note": "形状更准 (A 0.9928)，绝对更差 (B 0.9419)。",
    },
    "physical": {
        "label": "物理模型（二维非定常面元法）",
        "path": DELIVERY / "03_对照数据表" / "probe_table_物理模型_老师格式.tsv",
        "indexed": False,
        "can_extrapolate": True,
        "note": "可换频率/摆幅/几何重算；平均 R² 0.61。",
    },
    "physical_run": {
        "label": "可运行包 · 本次物理模型输出",
        "path": ROOT / "可运行" / "probe_table.tsv",
        "index_dir": "data/index_physical",
        "indexed": True,
        "can_extrapolate": True,
        "note": "由 可运行/run.py 生成；1,001 帧 × 404 探针，dt=0.001；可外推。",
    },
    "surface_csv": {
        "label": "物理模型 4D 时序 (14 列，含法向/cp)",
        "path": DELIVERY / "03_对照数据表" / "surface_flow_timeseries.csv",
        "indexed": False,
        "can_extrapolate": True,
        "note": "老师格式探针表之外的另一种导出。",
    },
}

METRICS_JSON = DELIVERY / "06_指标" / "两口径指标_权威.json"
HOLDOUT_JSON = DELIVERY / "06_指标" / "留出验证_不可外推.json"
SEGMENTS_JSON = DELIVERY / "06_指标" / "新方法_25段精度.json"
POD_JSON = DELIVERY / "06_指标" / "POD-DMD对比.json"

N_PROBES = 404
N_SIDE = 202
DT = 0.0005
T0 = 0.1
T1 = 24.9995
N_FRAMES = 49800

COLUMNS = {
    "probe": "No of probe",
    "time": "Time",
    "x": "X-coord of probe",
    "y": "Y-coord of probe",
    "p": "pressure",
    "ux": "X velocity",
    "uy": "Y velocity",
}

QUANTITY_LABEL = {
    "p": "pressure p/(ρU²)",
    "ux": "X velocity u_x [m/s]",
    "uy": "Y velocity u_y [m/s]",
}


def ensure_dirs() -> None:
    INDEX.mkdir(parents=True, exist_ok=True)
    OUTPUTS.mkdir(parents=True, exist_ok=True)


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))

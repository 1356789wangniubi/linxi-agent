"""鳞析: a methodological-guardrail agent for bionic-fish flow data."""

__version__ = "0.1.0"

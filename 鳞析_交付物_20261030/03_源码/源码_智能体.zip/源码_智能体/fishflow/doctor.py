"""One-shot environment/artifact check (`python -m fishflow.cli doctor`)."""

from __future__ import annotations

import glob
import importlib.util
import sys
from pathlib import Path

from . import config, store

FFMPEG = [
    r"C:\Program Files\Tencent\QQBrowser\22.1.7007.400\ffmpeg\ffmpeg.exe",
    r"C:\Program Files\Tencent\QQBrowser\22.0.7003.400\ffmpeg\ffmpeg.exe",
    r"C:\Program Files\Tencent\QQBrowser\21.5.9239.400\ffmpeg\ffmpeg.exe",
]


def _find_ffmpeg() -> str | None:
    for p in FFMPEG:
        if Path(p).exists():
            return p
    hits = glob.glob(r"C:\Program Files\Tencent\QQBrowser\*\ffmpeg\ffmpeg.exe")
    return hits[0] if hits else None


def _add(rows, name, ok, detail):
    rows.append((name, "OK" if ok else "FAIL", detail))


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    rows = []

    _add(rows, "python", sys.version_info >= (3, 10), sys.version.split()[0])
    for mod in ("numpy", "pandas", "pyarrow", "matplotlib", "scipy", "PIL"):
        _add(rows, mod, importlib.util.find_spec(mod) is not None, "importable")

    try:
        m = store.manifest()
        _add(rows, "DMD index", m.get("n_rows") == 20119200,
             f"{m.get('n_rows'):,} rows / {m.get('n_frames'):,} frames")
    except Exception as exc:
        _add(rows, "DMD index", False, str(exc))

    try:
        m = store.manifest(config.INDEX_PHYSICAL)
        _add(rows, "physical index", m.get("n_frames") == 1001,
             f"{m.get('n_frames'):,} frames / dt={m.get('dt'):g}")
    except Exception as exc:
        _add(rows, "physical index", False, str(exc))

    _add(rows, "metrics JSON", config.METRICS_JSON.exists(), str(config.METRICS_JSON.name))
    _add(rows, "report", (config.OUTPUTS / "guard_report.html").exists(),
         "outputs/guard_report.html")
    _add(rows, "skill", (config.ROOT / ".dsh" / "skills" / "fishflow-guard" / "SKILL.md").exists(),
         ".dsh/skills/fishflow-guard")
    try:
        from .mcp_server import TOOLS
        _add(rows, "MCP tools", True, f"{len(TOOLS)} tools")
    except Exception as exc:
        _add(rows, "MCP tools", False, str(exc))

    ff = _find_ffmpeg()
    _add(rows, "ffmpeg", ff is not None, ff or "not found (video: use AVI/GIF)")

    from . import runner
    runs = runner.list_runs()
    _add(rows, "runs", True, f"{len(runs)} run(s); latest={runs[0]['run_id'] if runs else '-'}")

    width = max(len(n) for n, _, _ in rows)
    for name, status, detail in rows:
        print(f"{status:4s}  {name:<{width}}  {detail}")
    return 0 if all(s != "FAIL" for _, s, _ in rows) else 1


if __name__ == "__main__":
    raise SystemExit(main())

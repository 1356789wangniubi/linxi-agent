"""Keyword-routed guardrail answers.

A small local model does not need to *know* the physics; it needs to route the
question to the right curated rule and then quote the evidence.  This module is
that router.  It is deliberately deterministic: the same question gives the same
answer, which is what makes a live demo safe.
"""

from __future__ import annotations

from . import knowledge


def _score(question: str, entry: dict) -> float:
    q = question.lower().replace(" ", "")
    score = 0.0
    for kw in entry["keywords"]:
        k = kw.lower().replace(" ", "")
        if k and k in q:
            score += 1.0 + 0.15 * len(k)
    title = entry["title"].lower().replace(" ", "")
    for token in title.replace("，", " ").replace("：", " ").split():
        if len(token) >= 2 and token in q:
            score += 1.5
    return score


def answer(question: str, top_k: int = 3) -> dict:
    q = (question or "").strip()
    if not q:
        return {
            "status": "need_more_info",
            "question": q,
            "message": "请把问题说得更具体一点，例如“DMD 能不能外推到 25 秒之后？”",
            "topics": knowledge.topics(),
        }

    scored = sorted(
        ((_score(q, e), e) for e in knowledge.ENTRIES),
        key=lambda x: x[0],
        reverse=True,
    )
    best_score, best = scored[0]
    if best_score <= 0:
        return {
            "status": "need_more_info",
            "question": q,
            "message": "这个问题不在当前护栏知识库里。可以换一种问法，或从下面的主题里选一个。",
            "topics": knowledge.topics(),
        }

    related = [
        {"id": e["id"], "title": e["title"]}
        for s, e in scored[1:top_k] if s > 0
    ]
    return {
        "status": "ok",
        "question": q,
        "matched": best["id"],
        "title": best["title"],
        "answer": best["answer"],
        "evidence": best["evidence"],
        "guardrail": best["guardrail"],
        "confidence": round(min(1.0, best_score / 5.0), 2),
        "related": related,
    }


def format_text(result: dict) -> str:
    if result.get("status") != "ok":
        return result.get("message", "无法回答。")
    lines = [
        f"[{result['title']}]",
        result["answer"],
        "",
        "依据：",
    ]
    lines += [f"  - {e}" for e in result["evidence"]]
    lines += ["", f"护栏：{result['guardrail']}"]
    return "\n".join(lines)

"""Run the self-contained physical model in an isolated copy.

A run copies only the Python sources into `data/runs/<id>/pkg`, executes
`run_continuous_simulation` there, builds a per-probe index, and (optionally)
compares it with the DMD v2 index.  The original `可运行/` folder is never
overwritten.

Two modes:
  * run_physical(...)     blocking (used by CLI without --background)
  * start_background(...) detached worker writing status.json / progress.json
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

from . import config

PKG = config.ROOT / "可运行"
RUNS = config.ROOT / "data" / "runs"

SOURCES = ["fish_model.py", "source_panel.py", "run_unsteady_pipeline.py",
           "verify_package.py", "import_probe_data.py"]

RUN_ONE = r'''
import json, os, sys, time
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
from run_unsteady_pipeline import run_continuous_simulation
from source_panel import UnsteadyPanelSolver

params = json.loads(sys.argv[1])
progress_path = sys.argv[2] if len(sys.argv) > 2 else None
total = int(round(params["t_end"] / params["dt"])) + 2
count = 0
t0 = time.time()
orig = UnsteadyPanelSolver.step

def _step(self, *a, **k):
    global count
    r = orig(self, *a, **k)
    count += 1
    if progress_path and (count % 10 == 0 or count >= total):
        tmp = progress_path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"step": count, "total": total,
                       "percent": round(min(100.0, 100.0 * count / max(1, total)), 1),
                       "elapsed_s": round(time.time() - t0, 1)}, f)
        os.replace(tmp, progress_path)
    return r

UnsteadyPanelSolver.step = _step
df, summary = run_continuous_simulation(**params)
print("RUN_SUMMARY " + json.dumps(summary, ensure_ascii=False))
'''


def _validate(freq: float, t_end: float, dt: float) -> None:
    if not 0.3 <= freq <= 6.0:
        raise ValueError("freq must be 0.3..6.0 Hz")
    if not 0.005 <= t_end <= 5.0:
        raise ValueError("t_end must be 0.005..5.0 s")
    if not 0.0005 <= dt <= 0.01:
        raise ValueError("dt must be 0.0005..0.01 s")


def _now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")


def _write_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(tmp, path)


def _read_json(path: Path) -> dict | None:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def _new_run_dir(freq: float) -> Path:
    RUNS.mkdir(parents=True, exist_ok=True)
    run_id = time.strftime("%Y%m%d_%H%M%S") + f"_f{freq:g}"
    d = RUNS / run_id
    i = 1
    while d.exists():
        d = RUNS / f"{run_id}_{i}"
        i += 1
    d.mkdir(parents=True)
    return d


def run_physical(freq: float = 2.0, t_end: float = 1.0, dt: float = 0.001,
                 u_inf: float = 1.0, length: float = 1.0,
                 do_compare: bool = True, quantity: str = "p", trim: int = 24,
                 timeout: float = 900.0, run_dir: str | Path | None = None,
                 progress_path: str | Path | None = None,
                 status_cb=None) -> dict:
    _validate(freq, t_end, dt)
    run_dir = Path(run_dir) if run_dir else _new_run_dir(freq)
    run_id = run_dir.name
    pkg = run_dir / "pkg"
    pkg.mkdir(parents=True, exist_ok=True)

    for name in SOURCES:
        src = PKG / name
        if src.exists():
            shutil.copy2(src, pkg / name)
    (pkg / "run_one.py").write_text(RUN_ONE, encoding="utf-8")

    params = {"t_end": float(t_end), "dt": float(dt), "freq": float(freq),
              "u_inf": float(u_inf), "length": float(length)}
    progress_path = Path(progress_path) if progress_path else run_dir / "progress.json"

    if status_cb:
        status_cb(stage="simulating", percent=0)
    t0 = time.time()
    proc = subprocess.run(
        [sys.executable, "run_one.py", json.dumps(params), str(progress_path)],
        cwd=str(pkg), capture_output=True, text=True,
        encoding="utf-8", errors="replace", timeout=timeout,
    )
    elapsed = round(time.time() - t0, 1)
    if proc.returncode != 0:
        return {
            "status": "error",
            "run_id": run_id,
            "returncode": proc.returncode,
            "stderr": (proc.stderr or "")[-2000:],
            "stdout": (proc.stdout or "")[-2000:],
            "run_dir": str(run_dir),
        }

    table = pkg / "probe_table.tsv"
    if not table.exists():
        return {"status": "error", "run_id": run_id,
                "message": "probe_table.tsv not produced",
                "stdout": (proc.stdout or "")[-2000:], "run_dir": str(run_dir)}

    if status_cb:
        status_cb(stage="indexing", percent=95)
    from .build_index import main as build_main
    index_dir = run_dir / "index"
    build_main(table, index_dir, verbose=False)

    out = {
        "status": "ok",
        "run_id": run_id,
        "run_dir": str(run_dir),
        "seconds": elapsed,
        "params": params,
        "table_mb": round(table.stat().st_size / 1e6, 1),
        "index": str(index_dir),
        "stdout_tail": (proc.stdout or "")[-800:],
    }

    if do_compare:
        if status_cb:
            status_cb(stage="comparing", percent=98)
        from . import compare as compare_mod
        try:
            out["compare"] = compare_mod.compare(config.INDEX, index_dir, quantity, trim=trim)
            out["compare"]["note"] = (
                "DMD is fitted at 2.0 Hz. A different freq only tests extrapolation failure, "
                "not model accuracy." if abs(freq - 2.0) > 1e-9 else
                "same frequency as the DMD fit"
            )
        except Exception as exc:
            out["compare"] = {"skipped": True, "reason": f"{type(exc).__name__}: {exc}"}

    if status_cb:
        status_cb(stage="done", percent=100)
    return out


def start_background(freq: float = 2.0, t_end: float = 1.0, dt: float = 0.001,
                     u_inf: float = 1.0, length: float = 1.0,
                     do_compare: bool = True, quantity: str = "p", trim: int = 24) -> dict:
    _validate(freq, t_end, dt)
    run_dir = _new_run_dir(freq)
    params = {"t_end": float(t_end), "dt": float(dt), "freq": float(freq),
              "u_inf": float(u_inf), "length": float(length)}
    payload = {
        "run_id": run_dir.name,
        "status": "queued",
        "stage": "queued",
        "percent": 0,
        "params": params,
        "started_at": _now(),
        "updated_at": _now(),
    }
    _write_json(run_dir / "status.json", payload)

    log_path = run_dir / "worker.log"
    creationflags = 0
    if os.name == "nt":
        creationflags = (getattr(subprocess, "DETACHED_PROCESS", 0) |
                         getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0) |
                         getattr(subprocess, "CREATE_BREAKAWAY_FROM_JOB", 0))
    with log_path.open("w", encoding="utf-8") as log:
        cmd = [sys.executable, "-m", "fishflow.runner_worker",
               str(run_dir), json.dumps({"params": params, "do_compare": do_compare,
                                         "quantity": quantity, "trim": trim})]
        try:
            proc = subprocess.Popen(
                cmd, cwd=str(config.ROOT), stdout=log, stderr=subprocess.STDOUT,
                creationflags=creationflags, close_fds=True,
            )
        except PermissionError:
            # Some sandboxes/job objects forbid breakaway; retry without it.
            creationflags &= ~getattr(subprocess, "CREATE_BREAKAWAY_FROM_JOB", 0)
            proc = subprocess.Popen(
                cmd, cwd=str(config.ROOT), stdout=log, stderr=subprocess.STDOUT,
                creationflags=creationflags, close_fds=True,
            )

    # Keep the parent alive briefly so the detached worker escapes the job
    # object and writes its first status (Windows kills child jobs otherwise).
    for _ in range(40):
        st = _read_json(run_dir / "status.json") or {}
        if st.get("status") in ("running", "ok", "error"):
            break
        time.sleep(0.1)

    return {
        "status": "started",
        "run_id": run_dir.name,
        "pid": proc.pid,
        "run_dir": str(run_dir),
        "status_path": str(run_dir / "status.json"),
        "log_path": str(log_path),
    }


def _latest_run_dir() -> Path | None:
    if not RUNS.exists():
        return None
    dirs = [d for d in RUNS.iterdir() if d.is_dir()]
    return max(dirs, key=lambda d: d.stat().st_mtime) if dirs else None


def status(run_id: str | None = None) -> dict:
    d = RUNS / run_id if run_id else _latest_run_dir()
    if d is None or not d.exists():
        return {"status": "not_found", "run_id": run_id}
    st = _read_json(d / "status.json")
    if not st:
        if (d / "index" / "manifest.json").exists():
            st = {"run_id": d.name, "status": "ok", "stage": "done",
                  "percent": 100, "inferred": True}
        else:
            st = {"run_id": d.name, "status": "unknown", "stage": "unknown", "percent": 0}
    prog = _read_json(d / "progress.json")
    if prog:
        st.setdefault("progress", prog)
        if st.get("status") == "running":
            st["percent"] = prog.get("percent", st.get("percent", 0))
            st["step"] = prog.get("step")
            st["total_steps"] = prog.get("total")
            st["elapsed_s"] = prog.get("elapsed_s")

    if st.get("status") in ("running", "queued") and st.get("updated_at"):
        try:
            age = (datetime.now() - datetime.fromisoformat(st["updated_at"])).total_seconds()
            if age > 120:
                st["status"] = "stale"
                st["hint"] = ("worker may have been killed by the environment; "
                              "use `run --progress` inside a background job")
        except ValueError:
            pass
    return st


def logs(run_id: str, tail: int = 60) -> str:
    d = RUNS / run_id
    p = d / "worker.log"
    if not p.exists():
        return ""
    lines = p.read_text(encoding="utf-8", errors="replace").splitlines()
    return "\n".join(lines[-tail:])


def list_runs() -> list[dict]:
    if not RUNS.exists():
        return []
    out = []
    for d in sorted(RUNS.iterdir(), reverse=True):
        if not d.is_dir():
            continue
        st = _read_json(d / "status.json") or {}
        has_index = (d / "index" / "manifest.json").exists()
        out.append({
            "run_id": d.name,
            "path": str(d),
            "status": st.get("status", "ok" if has_index else "unknown"),
            "stage": st.get("stage", "done" if has_index else "unknown"),
            "percent": st.get("percent", 100 if has_index else 0),
            "has_index": has_index,
        })
    return out

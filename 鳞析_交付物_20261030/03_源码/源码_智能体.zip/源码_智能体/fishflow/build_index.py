"""
Build a per-probe Parquet index from the delivered DMD table.

Input : 交付包/02_主数据表/probe_table_DMD_v2_trimmed.tsv  (20,119,200 rows)
Output: data/index/probe_0000.parquet ... probe_0403.parquet
        data/index/manifest.json

The table is time-major (for each frame, 404 probes in order), so each chunk is
sorted by probe before writing.  Querying one probe then reads one small file.
"""

from __future__ import annotations

import json
import os
import time
from pathlib import Path

import numpy as np
import pyarrow as pa
import pyarrow.csv as pc
import pyarrow.parquet as pq

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "交付包" / "02_主数据表" / "probe_table_DMD_v2_trimmed.tsv"
OUT = ROOT / "data" / "index"
N_PROBES = 404
CHUNK_ROWS = N_PROBES * 2000  # 2000 frames per chunk

COLUMNS = [
    "No of probe", "Time", "X-coord of probe", "Y-coord of probe",
    "pressure", "X velocity", "Y velocity",
]


def main(src: str | Path = SRC, out: str | Path = OUT, verbose: bool = True) -> None:
    src = Path(src)
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    t_start = time.time()

    parse = pc.ParseOptions(delimiter="\t")
    convert = pc.ConvertOptions(column_types={
        "No of probe": pa.int32(),
        "Time": pa.float64(),
        "X-coord of probe": pa.float64(),
        "Y-coord of probe": pa.float64(),
        "pressure": pa.float64(),
        "X velocity": pa.float64(),
        "Y velocity": pa.float64(),
    })
    reader = pc.open_csv(
        str(src),
        read_options=pc.ReadOptions(block_size=64 << 20),
        parse_options=parse,
        convert_options=convert,
    )

    writers: dict[int, pq.ParquetWriter] = {}
    schema = None
    total_rows = 0
    total_frames = 0
    buffer: list[pa.RecordBatch] = []
    buf_rows = 0

    def flush() -> None:
        nonlocal buffer, buf_rows, schema, total_rows, total_frames
        if not buffer:
            return
        all_rows = pa.Table.from_batches(buffer)
        n_use = (all_rows.num_rows // N_PROBES) * N_PROBES
        if n_use == 0:
            return
        tbl = all_rows.slice(0, n_use)
        remainder = all_rows.slice(n_use)
        n_frames = tbl.num_rows // N_PROBES
        tbl = tbl.sort_by([("No of probe", "ascending"), ("Time", "ascending")])
        if schema is None:
            schema = tbl.schema
        probes = tbl.column("No of probe").to_numpy()
        starts = np.searchsorted(probes, np.arange(N_PROBES), side="left")
        ends = np.searchsorted(probes, np.arange(1, N_PROBES + 1), side="left")
        for p in range(N_PROBES):
            sub = tbl.slice(int(starts[p]), int(ends[p] - starts[p]))
            if sub.num_rows == 0:
                continue
            if p not in writers:
                writers[p] = pq.ParquetWriter(
                    str(out / f"probe_{p:04d}.parquet"),
                    schema,
                    compression="zstd",
                )
            writers[p].write_table(sub, row_group_size=50_000)
        total_rows += tbl.num_rows
        total_frames += n_frames
        buffer = remainder.to_batches() if remainder.num_rows else []
        buf_rows = remainder.num_rows
        if verbose:
            print(f"  flushed {total_rows:,} rows / {total_frames:,} frames "
                  f"({time.time() - t_start:.0f}s)", flush=True)

    while True:
        try:
            batch = reader.read_next_batch()
        except StopIteration:
            break
        buffer.append(batch)
        buf_rows += batch.num_rows
        if buf_rows >= CHUNK_ROWS:
            flush()
    flush()

    for w in writers.values():
        w.close()

    counts = []
    for p in range(N_PROBES):
        f = out / f"probe_{p:04d}.parquet"
        md = pq.ParquetFile(str(f)).metadata
        counts.append(md.num_rows)

    tarr = pq.read_table(str(out / "probe_0000.parquet"), columns=["Time"]).column("Time").to_numpy()
    time_start = float(tarr[0])
    time_end = float(tarr[-1])
    dt = float(np.median(np.diff(tarr))) if len(tarr) > 1 else 0.0

    manifest = {
        "source": str(src),
        "n_probes": N_PROBES,
        "n_frames": total_frames,
        "n_rows": total_rows,
        "columns": COLUMNS,
        "time_start": time_start,
        "time_end": time_end,
        "dt": dt,
        "rows_per_probe": int(min(counts)),
        "max_rows_per_probe": int(max(counts)),
        "files": [f"probe_{p:04d}.parquet" for p in range(N_PROBES)],
        "built_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "build_seconds": round(time.time() - t_start, 1),
    }
    (out / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=1), encoding="utf-8")
    if verbose:
        print(json.dumps(manifest, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    import argparse

    ap = argparse.ArgumentParser(description="Build per-probe Parquet index from a 7-column TSV.")
    ap.add_argument("--src", default=str(SRC), help="source TSV (tab-separated, 7 columns)")
    ap.add_argument("--out", default=str(OUT), help="output directory")
    args = ap.parse_args()
    main(args.src, args.out)

"""Payloads for the interactive 404-probe fish explorer."""

from __future__ import annotations

import numpy as np

from . import store

MAX_SERIES = 320


def frame(t: float = 0.2) -> dict:
    fr = store.frame_at(float(t))
    return {
        "time": float(fr["time"]),
        "probe": [int(v) for v in fr["probe"]],
        "x": [round(float(v), 6) for v in fr["x"]],
        "y": [round(float(v), 6) for v in fr["y"]],
        "p": [round(float(v), 6) for v in fr["p"]],
        "ux": [round(float(v), 6) for v in fr["ux"]],
        "uy": [round(float(v), 6) for v in fr["uy"]],
    }


def probe_data(probe: int, t: float = 0.2) -> dict:
    probe = int(probe)
    if not 0 <= probe <= 403:
        raise ValueError("probe 必须在 0–403")
    fr = store.frame_at(float(t))
    lo = max(float(store.manifest()["time_start"]), float(t) - 0.5)
    hi = min(float(store.manifest()["time_end"]), float(t) + 0.5)
    series = {}
    for q in ("p", "ux", "uy"):
        d = store.query(probe, lo, hi, q)
        n = len(d["time"])
        step = max(1, n // MAX_SERIES)
        series[q] = {
            "time": [round(float(v), 6) for v in d["time"][::step]],
            "value": [round(float(v), 6) for v in d["value"][::step]],
        }
    i = int(np.argmin(np.abs(fr["probe"] - probe)))
    return {
        "probe": probe,
        "time": float(fr["time"]),
        "x": float(fr["x"][i]), "y": float(fr["y"][i]),
        "p": float(fr["p"][i]), "ux": float(fr["ux"][i]), "uy": float(fr["uy"][i]),
        "series": series,
        "range": [lo, hi],
    }

"""Append-only evidence log.

Every answer the agent gives should be reconstructable from a record here:
claim -> evidence -> tool -> timestamp.  The file is JSONL so it can be read by
humans, by the report generator, and by the DSH session later.
"""

from __future__ import annotations

import json
import time
import uuid
from pathlib import Path

from . import config


def append(claim: str, evidence: list[str] | str, tool: str, meta: dict | None = None) -> dict:
    config.ensure_dirs()
    if isinstance(evidence, str):
        evidence = [evidence]
    rec = {
        "id": "ev-" + uuid.uuid4().hex[:10],
        "ts": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "claim": claim,
        "evidence": evidence,
        "tool": tool,
        "meta": meta or {},
    }
    with config.PROVENANCE.open("a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    return rec


def load() -> list[dict]:
    if not config.PROVENANCE.exists():
        return []
    out = []
    for line in config.PROVENANCE.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            out.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return out


def last(n: int = 10) -> list[dict]:
    return load()[-n:]

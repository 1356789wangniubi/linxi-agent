"""LLM-planned tool router for the lateral-line / flow agent.

Branches
  query    : meta / data origin / peak explanation
  compute  : pressure cloud, vortex proxy, Lighthill-type traveling-wave fit
  simulate : forward model -> sensor signals

The LLM only plans and narrates.  All numbers/figures come from Python tools.
If no LLM endpoint is configured, a deterministic rule planner is used.
"""

from __future__ import annotations

import json
import os
import re
import time
import urllib.request
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter

from . import config, metrics, plots, sim_agent, store


def _llm_url() -> str | None:
    return os.environ.get("FISHFLOW_LLM_URL")


def _llm(messages: list[dict], timeout: int = 60) -> str | None:
    url = _llm_url()
    if not url:
        return None
    model = os.environ.get("FISHFLOW_LLM_MODEL")
    if not model:
        model = "glm-5.3-flash" if "bigmodel.cn" in url else "qwen2.5:7b-instruct"
    key = os.environ.get("FISHFLOW_LLM_KEY") or os.environ.get("ZHIPU_API_KEY")
    if not key and "bigmodel.cn" in url:
        try:
            from .secret_store import load as _load_secret
            key = _load_secret("zhipu")
        except Exception:
            key = None
    if not key and ("11434" in url or "localhost" in url or "127.0.0.1" in url):
        key = "ollama"
    if not key:
        return None
    body = json.dumps({"model": model, "messages": messages, "temperature": 0.1,
                       "max_tokens": 1024}).encode("utf-8")
    req = urllib.request.Request(
        url, data=body,
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {key}"},
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        return data["choices"][0]["message"]["content"].strip()
    except Exception:
        return None


# ---------------------------------------------------------------- tools

def tool_meta() -> dict:
    m = store.manifest()
    pm = store.manifest(config.INDEX_PHYSICAL)
    mean = metrics.mean_scores()
    lines = [
        f"**数据规模**：{m['n_frames']:,} 帧 × {m['n_probes']} 探针 = {m['n_rows']:,} 行，"
        f"dt={m['dt']} s，时间 {m['time_start']}–{m['time_end']} s。",
        f"**物理模型索引**：{pm['n_frames']:,} 帧，dt={pm['dt']} s。",
        "**权威指标**：" + "；".join(
            f"{k} A={v['A']:.4f} / B={v['B']:.4f}" for k, v in mean.items()
        ),
        "**索引**：404 个 `probe_xxxx.parquet` 分片，热查询 3–5 ms。",
    ]
    return {"summary": "\n".join(lines), "sources": ["data/index/manifest.json", "交付包/06_指标"]}


def tool_origin() -> dict:
    return {
        "summary": (
            "这份数据来自课题组已有的仿生鱼流场仿真输出：\n\n"
            "- 原始主表约 2 GB，7 列（time, probe, x, y, p, ux, uy）；\n"
            "- 我把它按 404 个探针拆成 Parquet 分片（`data/index`），不再全表扫描；\n"
            "- 指标不重算，直接引用 `交付包/06_指标` 的权威 JSON；\n"
            "- 物理模型来自 `可运行/` 的二维面元法，输出与交付包物理表逐位一致；\n"
            "- 老师原始仿真数据不读、不外传。"
        ),
        "sources": ["交付包/02_主数据表", "交付包/06_指标", "RUN_INTEGRATION.md"],
    }


def tool_peak(t: float | None = None, probe: int | None = None, quantity: str = "p") -> dict:
    t = 0.2 if t is None else float(t)
    fr = store.frame_at(t)
    vals = fr[quantity]
    if probe is not None:
        d = store.query(int(probe), 0.1, 2.0, quantity)
        arr = np.asarray(d["value"])
        i = int(np.argmax(np.abs(arr)))
        return {
            "summary": (
                f"探针 **{probe}** 在 0.1–2.0 s 的 {quantity} 峰值出现在 "
                f"t={d['time'][i]:.3f} s，值={arr[i]:.4f}（|峰值|={abs(arr[i]):.4f}）。"
            ),
            "metrics": {"probe": int(probe), "time": float(d["time"][i]), "value": float(arr[i])},
            "sources": ["data/index"],
        }
    i = int(np.argmax(np.abs(vals)))
    p = float(vals[i])
    return {
        "summary": (
            f"在 t≈{fr['time']:.3f} s，全场 |{quantity}| 最大的探针是 **{int(fr['probe'][i])}**，"
            f"位置 x={fr['x'][i]:.4f}, y={fr['y'][i]:.4f}，p={p:.4f}。\n\n"
            "如果它落在鼻尖/尾缘（探针 0/202 或 201/403 附近），那更可能是几何尖点的奇异，"
            "不一定是物理峰值；要结合邻域探针一起看。"
        ),
        "metrics": {"probe": int(fr["probe"][i]), "t": float(fr["time"]),
                    "x": float(fr["x"][i]), "y": float(fr["y"][i]), "value": p},
        "sources": ["data/index"],
    }


def tool_vorticity(t: float = 0.2) -> dict:
    """Near-wall vorticity proxy from upper/lower surface velocities.

    omega_z ~ d(u_y)/dx - d(u_x)/dy, with d(u_x)/dy approximated by the
    upper-lower surface difference.  This is a surface proxy, not a
    volumetric CFD vorticity field.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    t = float(t)
    fr = store.frame_at(t)
    parts = store.split_surfaces(fr)
    up, lo = parts["upper"], parts["lower"]
    xq = np.linspace(max(up["x"].min(), lo["x"].min()),
                     min(up["x"].max(), lo["x"].max()), 220)
    yu = np.interp(xq, up["x"], up["y"])
    yl = np.interp(xq, lo["x"], lo["y"])
    uxu = np.interp(xq, up["x"], up["ux"])
    uxl = np.interp(xq, lo["x"], lo["ux"])
    uyu = np.interp(xq, up["x"], up["uy"])
    uyl = np.interp(xq, lo["x"], lo["uy"])
    dux_dy = (uxu - uxl) / np.maximum(yu - yl, 1e-9)
    omega_u = np.gradient(uyu, xq) - dux_dy
    omega_l = np.gradient(uyl, xq) - dux_dy

    s = np.linspace(0.0, 1.0, 30)
    X = np.repeat(xq[:, None], len(s), axis=1)
    Y = yu[:, None] * (1 - s)[None, :] + yl[:, None] * s[None, :]
    W = omega_u[:, None] * (1 - s)[None, :] + omega_l[:, None] * s[None, :]
    omega_u = gaussian_filter(omega_u, 1.2)
    omega_l = gaussian_filter(omega_l, 1.2)
    W = gaussian_filter(W, 1.0)

    pu = np.interp(xq, up["x"], up["p"])
    pl = np.interp(xq, lo["x"], lo["p"])
    P = pu[:, None] * (1 - s)[None, :] + pl[:, None] * s[None, :]

    i = int(np.argmax(np.abs(omega_u[10:-10]))) + 10
    out = config.OUTPUTS / f"vorticity_{str(t).replace('.', 'p')}.png"
    fig, axes = plt.subplots(1, 3, figsize=(12.2, 3.7), gridspec_kw={"width_ratios": [1, 1.15, 1]})
    ax = axes[0]
    vp = float(np.percentile(np.abs(P), 96)) + 1e-12
    f0 = ax.pcolormesh(X, Y, P, cmap="RdBu_r", vmin=-vp, vmax=vp, shading="gouraud")
    ax.set_aspect(4.0); ax.set_xlabel("x [m]"); ax.set_ylabel("y [m]")
    ax.set_title("压力 p")
    fig.colorbar(f0, ax=ax, fraction=0.04, pad=0.02)

    ax = axes[1]
    vmax = float(np.percentile(np.abs(W), 80)) + 1e-12
    fill = ax.pcolormesh(X, Y, W, cmap="RdBu_r", vmin=-vmax, vmax=vmax, shading="gouraud")
    ax.quiver(xq[::14], yu[::14], uxu[::14], uyu[::14], color="k", alpha=0.25,
              scale=12, width=0.0015)
    ax.quiver(xq[::14], yl[::14], uxl[::14], uyl[::14], color="k", alpha=0.25,
              scale=12, width=0.0015)
    ax.set_aspect(4.0); ax.set_xlabel("x [m]"); ax.set_ylabel("y [m]")
    ax.set_title(f"近壁涡量代理 + 速度 t≈{fr['time']:.3f}s")
    fig.colorbar(fill, ax=ax, fraction=0.04, pad=0.02, label="ω_z [1/s]")

    ax = axes[2]
    ax.plot(xq, omega_u, color="#c53030", lw=1.2, label="上表面")
    ax.plot(xq, omega_l, color="#2b6cb0", lw=1.2, label="下表面")
    ax.set_xlabel("x [m]"); ax.set_ylabel("ω_z [1/s]")
    lim = max(5.0, float(np.percentile(np.abs(np.r_[omega_u, omega_l]), 90)))
    ax.set_ylim(-lim, lim)
    ax.set_title("上/下表面涡量代理（端部尖点裁到视图外）")
    ax.grid(alpha=0.25); ax.legend(fontsize=7)
    fig.tight_layout(); fig.savefig(out, dpi=170); plt.close(fig)

    return {
        "summary": (
            f"用上下表面速度差估算了一张 **近壁涡量代理**（t≈{fr['time']:.3f}s）：\n\n"
            f"- ω_z 范围：{float(np.nanmin(W)):.2f} – {float(np.nanmax(W)):.2f} 1/s\n"
            f"- 上表面 |ω| 最大：x={xq[i]:.4f}, y={yu[i]:.4f}, ω={omega_u[i]:.2f}\n"
            f"- 速度箭头：上/下表面 (u_x,u_y)\n\n"
            "这是 `ω_z = ∂u_y/∂x − ∂u_x/∂y` 的**近壁代理**："
            "∂u_x/∂y 用上下表面速度差近似，不是体网格涡量，也不是 CFD。"
        ),
        "figure": out.name,
        "metrics": {"min": float(np.nanmin(W)), "max": float(np.nanmax(W)),
                    "peak_x": float(xq[i]), "peak_y": float(yu[i])},
        "sources": ["data/index (p, ux, uy)", "近壁涡量代理"],
    }


def tool_physical_vorticity(t: float = 0.2) -> dict:
    """True 2-D grid vorticity from the panel-method velocity field."""
    from . import physical_field

    r = physical_field.make(float(t))
    return {
        "summary": (
            f"把物理模型的速度场接到 **{r['grid'][0]}×{r['grid'][1]} 的 2D 网格**，"
            f"用 `ω_z = ∂u_y/∂x − ∂u_x/∂y` 算了一张**真涡量场**（t≈{r['t']:.3f}s）：\n\n"
            f"- 网格分辨率：{r['grid'][0]}×{r['grid'][1]}\n"
            f"- 全网格 |ω| 中位数：**{r['median_omega']:.5f} 1/s**\n"
            f"- 近壁/尾缘最大 |ω|：{r['max_omega']:.2f} 1/s\n"
            f"- 物面涡片强度 γ：{r['gamma']:.4f}\n"
            f"- 计算耗时：约 {r['elapsed']:.1f} s（已缓存）\n\n"
            "关键结论：**外场中位数几乎为 0**——这个物理模型是势流 + 物面涡片，"
            "涡量集中在物面/尾缘，不是 CFD 尾涡云。图里的近壁亮斑是物面涡片和数值奇异，"
            "不是“涡街”。要尾涡云，需要加自由尾涡模型或黏性 CFD。"
        ),
        "figure": r["figure"],
        "metrics": {"median_omega": r["median_omega"], "max_omega": r["max_omega"],
                    "gamma": r["gamma"], "grid": r["grid"]},
        "sources": ["可运行/source_panel.py", "2D 网格有限差分"],
    }


def tool_pressure_cloud(t: float = 0.2, quantity: str = "p") -> dict:
    t = float(t)
    out = config.OUTPUTS / f"cloud_{quantity}_{str(t).replace('.', 'p')}.png"
    plots.field_plot(t, quantity, out)
    fr = store.frame_at(t)
    vals = fr[quantity]
    i = int(np.argmax(np.abs(vals)))
    return {
        "summary": (
            f"已画 **t≈{fr['time']:.3f} s** 的 {quantity} 场图。\n\n"
            f"- 范围：{vals.min():.3f} – {vals.max():.3f}\n"
            f"- |峰值| 在探针 {int(fr['probe'][i])}（x={fr['x'][i]:.3f}, y={fr['y'][i]:.3f}）\n\n"
            "注意：这是把表面探针插值到鱼体轮廓的**示意**，不是二维/三维体场；"
            "尖点附近可能有非物理奇异。"
        ),
        "figure": out.name,
        "metrics": {"t": float(fr["time"]), "min": float(vals.min()), "max": float(vals.max())},
        "sources": ["data/index", "plots.field_plot"],
    }


def tool_vortex(t: float = 0.2) -> dict:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    t = float(t)
    fr = store.frame_at(t)
    parts = store.split_surfaces(fr)
    cores = []
    for side in ("upper", "lower"):
        d = parts[side]
        p = d["p"]
        y = d["y"]
        for i in range(20, len(p) - 20):
            if abs(y[i]) < 0.015:
                continue
            if p[i] < p[i - 1] and p[i] < p[i + 1]:
                cores.append({"side": side, "probe": int(d["probe"][i]),
                              "x": float(d["x"][i]), "y": float(y[i]), "p": float(p[i])})
    cores.sort(key=lambda c: c["p"])
    cores = cores[:3]

    out = config.OUTPUTS / f"vortex_{str(t).replace('.', 'p')}.png"
    fig, ax = plt.subplots(figsize=(8.5, 3.4))
    sc = ax.scatter(fr["x"], fr["y"], c=fr["p"], cmap="RdBu_r", s=14)
    for c in cores:
        ax.plot(c["x"], c["y"], "o", ms=12, mfc="none", mec="#16a34a", mew=1.8)
        ax.annotate(f"p={c['p']:.2f}", (c["x"], c["y"]), fontsize=7,
                    xytext=(4, 6), textcoords="offset points")
    ax.set_aspect("equal")
    ax.set_title(f"低压核心（侧线可感知的涡代理） t≈{fr['time']:.3f}s")
    ax.set_xlabel("x [m]"); ax.set_ylabel("y [m]")
    fig.colorbar(sc, ax=ax, fraction=0.03, pad=0.02, label="p")
    fig.tight_layout(); fig.savefig(out, dpi=170); plt.close(fig)

    if cores:
        txt = "在 t≈{:.3f} s 找到 {} 个低压核心：\n\n".format(fr["time"], len(cores))
        txt += "\n".join(
            f"- {c['side']} 探针 {c['probe']}：x={c['x']:.4f}, y={c['y']:.4f}, p={c['p']:.3f}"
            for c in cores
        )
        txt += ("\n\n这是**低压核心代理**，不是严格涡量；侧线感受的是压力/速度，"
                "真正的涡量需要二维/三维速度场。")
    else:
        txt = "这个时刻没有找到明显低压核心；可以换一个 t 或看压力云图。"
    return {"summary": txt, "figure": out.name, "metrics": {"cores": cores},
            "sources": ["data/index", "plots.field_plot"]}


def tool_lighthill(t0: float = 0.2, t1: float = 1.0, n_probes: int = 202) -> dict:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    t0, t1 = float(t0), float(t1)
    probes = np.arange(0, min(n_probes, config.N_SIDE))
    geom = store.frame_at(t0)
    ts = None
    rows = []
    for p in probes:
        d = store.query(int(p), t0, t1, "p")
        if ts is None:
            ts = np.asarray(d["time"])
        rows.append(np.asarray(d["value"]))
    P = np.stack(rows, axis=1)
    P = P - P.mean(axis=0, keepdims=True)
    x = np.asarray(geom["x"][:len(probes)], dtype=float)
    dt = float(ts[1] - ts[0])
    freqs = np.fft.rfftfreq(len(ts), dt)
    amp = np.abs(np.fft.rfft(P, axis=0)).mean(axis=1)
    amp[freqs < 0.3] = 0
    f0 = float(freqs[int(np.argmax(amp))])
    omega = 2 * np.pi * f0

    # per-probe fundamental: p_i(t) = a_i cos(wt) + b_i sin(wt)
    # = A_i cos(wt - phi_i)
    cos_t = np.cos(omega * ts)
    sin_t = np.sin(omega * ts)
    M = np.column_stack([cos_t, sin_t])
    coef, *_ = np.linalg.lstsq(M, P, rcond=None)
    a, b = coef[0], coef[1]
    amp_i = np.hypot(a, b)
    phase_i = np.arctan2(b, a)
    pred = a[None, :] * cos_t[:, None] + b[None, :] * sin_t[:, None]

    order = np.argsort(x)
    xu = x[order]
    amp_s = amp_i[order]
    Pc = (a - 1j * b)[order]
    keep = amp_s > 0.05 * (amp_s.max() + 1e-12)
    idx = np.where(keep)[0]
    if len(idx) >= 3:
        dphi = np.angle(Pc[idx[1:]] * np.conj(Pc[idx[:-1]]))
        dxs = xu[idx[1:]] - xu[idx[:-1]]
        k_i = dphi / np.maximum(dxs, 1e-12)
        k = abs(float(np.median(k_i)))
        coherence = float(np.abs(np.mean(np.exp(1j * dphi))))
        xmid = 0.5 * (xu[idx[1:]] + xu[idx[:-1]])
    else:
        k, coherence, xmid, k_i = 0.0, 0.0, np.array([]), np.array([])
    c = omega / k if k > 1e-9 else float("inf")
    wave_r2 = 1 - float(np.sum((P - pred) ** 2)) / (float(np.sum(P ** 2)) + 1e-12)
    Lb = float(np.max(x) - np.min(x))
    kmin = 2 * np.pi / max(4 * Lb, 1e-9)
    long_wave = k < 1.5 * kmin
    speed_line = (f"- 相速度：{c:.2f} m/s" if not long_wave
                  else "- 相速度：长波/驻波极限，数值不可靠（不报具体值）")

    out = config.OUTPUTS / "lighthill_fit.png"
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 3.6), gridspec_kw={"width_ratios": [1, 1.2]})
    ax = axes[0]
    ax.plot(xmid, k_i, "o", ms=3, color="#2563eb", label="相邻探针 k")
    ax.axhline(k, color="#dc2626", lw=1.2, label=f"中位 k={k:.2f}")
    ax.set_xlabel("x [m]"); ax.set_ylabel("local k [rad/m]")
    ax.set_title(f"相位差一致性 coherence={coherence:.2f}")
    ax.grid(alpha=0.25); ax.legend(fontsize=7)

    ax = axes[1]
    for j, color in [(5, "#94a3b8"), (60, "#2563eb"), (140, "#dc2626")]:
        ax.plot(ts, P[:, j], lw=0.7, color=color, alpha=0.5)
        ax.plot(ts, pred[:, j], lw=1.1, color=color, label=f"probe {j}")
    ax.set_xlabel("t [s]"); ax.set_ylabel("p (centered)")
    ax.set_title("三个代表点：实线重构 / 淡线数据")
    ax.grid(alpha=0.25); ax.legend(fontsize=7)
    fig.tight_layout(); fig.savefig(out, dpi=170); plt.close(fig)

    return {
        "summary": (
            f"用 0–201 上表面探针做了 **Lighthill 型行波相位拟合**：\n\n"
            f"- 主频：{f0:.3f} Hz\n"
            f"- 波数 k：{k:.2f} rad/m\n"
            f"{speed_line}\n"
            f"- 相位差一致性：**{coherence:.3f}**\n"
            f"- 波形重构 R²：{wave_r2:.3f}\n\n"
            "这是“相位/行波拟合”，用于估计频率、波数、相速度；"
            "**不是完整的 Lighthill 推力/功率模型**，也不能替代体波运动学。"
            + ("\n\n注意：k 接近下限，数据更像长波/驻波，不宜强行解释为行波。" if long_wave else "")
            + (f"\n\n⚠️ coherence={coherence:.2f} < 0.6：相邻探针相位差不一致，k/相速度只能当量级参考。"
               if coherence < 0.6 else "")
        ),
        "figure": out.name,
        "metrics": {"f": f0, "k": k, "phase_speed": c,
                    "coherence": coherence, "wave_r2": wave_r2},
        "sources": ["data/index", "plots.field_plot"],
    }


def tool_forward(length: float | None = None, height: float | None = None,
                 speed: float | None = None, n_sensors: int | None = None,
                 source_x: float | None = None, source_y: float | None = None,
                 freq: float | None = None, noise: float | None = None,
                 shape: str = "ellipse") -> dict:
    if speed is None:
        return {
            "summary": "可以。先告诉我**来流速度**（m/s）和**体长**（m），我再用正向模型预测侧线输出。",
            "need": ["speed", "length"],
            "sources": [],
        }
    params = {"preset": "custom", "shape": shape, "speed": float(speed)}
    if length is not None:
        params["length"] = float(length)
    if height is not None:
        params["height"] = float(height)
    if n_sensors is not None:
        params["n_sensors"] = int(n_sensors)
    if source_x is not None:
        params["source_x"] = float(source_x)
    if source_y is not None:
        params["source_y"] = float(source_y)
    if freq is not None:
        params["freq"] = float(freq)
    if noise is not None:
        params["noise"] = float(noise)
    r = sim_agent.simulate(params)
    follow = None
    if length is None:
        follow = "这次先用默认体长 0.15 m / 体高 0.04 m；要改就告诉我“体长 0.3 m、体高 0.08 m”。"
    return {
        "summary": r["reply"],
        "figure": r["figure"],
        "metrics": r["metrics"],
        "followup": follow,
        "sources": ["sim_agent.simulate"],
    }


TOOLS = {
    "meta": tool_meta,
    "origin": tool_origin,
    "peak": tool_peak,
    "pressure_cloud": tool_pressure_cloud,
    "vortex": tool_vortex,
    "vorticity": tool_vorticity,
    "physical_vorticity": tool_physical_vorticity,
    "lighthill": tool_lighthill,
    "forward": tool_forward,
}

TOOL_SPECS = """可用工具：
- meta {} 数据规模/指标
- origin {} 数据来源
- peak {t?, probe?, quantity?} 峰值解释
- pressure_cloud {t, quantity?} 压力云图
- vortex {t?} 侧线可感知的低压核心（涡代理）
- vorticity {t?} 近壁涡量代理（压力/速度/涡量多模态）
- physical_vorticity {t?} 物理模型速度场 → 2D 网格真涡量
- lighthill {t0?, t1?} Lighthill 型行波拟合
- forward {length?, height?, speed, n_sensors?, source_x?, source_y?, freq?, noise?} 正向侧线仿真
"""


def _extract_json(s: str) -> dict | None:
    try:
        return json.loads(s)
    except Exception:
        pass
    m = re.search(r"\{.*\}", s, re.S)
    if m:
        try:
            return json.loads(m.group(0))
        except Exception:
            return None
    return None


def plan_llm(q: str) -> dict | None:
    if not _llm_url():
        return None
    sys = (
        "你是意图规划器。只输出 JSON，不要解释。branch 只能是 query/compute/simulate 之一。格式："
        '{"branch":"query","tool":"meta|origin|peak|pressure_cloud|vortex|vorticity|physical_vorticity|lighthill|forward","args":{}}'
        + "\n" + TOOL_SPECS
        + "\n规则：解释数据来源用 origin；问规模/指标用 meta；问峰值用 peak；"
          "画云图用 pressure_cloud；问涡位置用 vortex；问涡量/多模态用 vorticity；"
          "问物理模型真涡量用 physical_vorticity；拟合 Lighthill 用 lighthill；"
          "给速度预测传感器用 forward。参数从问题里抽取，缺省用 {}。"
    )
    txt = _llm([{"role": "system", "content": sys}, {"role": "user", "content": q}])
    if not txt:
        return None
    obj = _extract_json(txt)
    if not obj or obj.get("tool") not in TOOLS:
        return None
    tool = obj["tool"]
    branch = obj.get("branch")
    if tool in ("meta", "origin", "peak"):
        branch = "query"
    elif tool == "forward":
        branch = "simulate"
    else:
        branch = "compute"
    return {"branch": branch, "tool": tool, "args": obj.get("args") or {}}


def _t(q: str, default: float = 0.2) -> float:
    m = re.search(r"t\s*=\s*([0-9.]+)", q) or re.search(r"([0-9.]+)\s*(?:s|秒)", q)
    return float(m.group(1)) if m else default


def _speed(q: str) -> float | None:
    m = (re.search(r"([0-9.]+)\s*m/s", q)
         or re.search(r"(?:来流|速度|流速)\s*(?:是|为|=)?\s*([0-9.]+)", q))
    return float(m.group(1)) if m else None


def plan_rules(q: str) -> dict | None:
    low = q.lower()
    if any(k in q for k in ("数据怎么来", "数据来源", "怎么采集", "哪来的", "原始数据")):
        return {"branch": "query", "tool": "origin", "args": {}}
    if any(k in q for k in ("多少探针", "数据量", "多少行", "时间步", "索引多大", "多少帧")):
        return {"branch": "query", "tool": "meta", "args": {}}
    if any(k in q for k in ("压力云图", "云图", "场图", "压力场")):
        return {"branch": "compute", "tool": "pressure_cloud", "args": {"t": _t(q, 0.2)}}
    if ("真涡量" in q or "网格涡量" in q or "2D 网格" in q or "2d 网格" in q
            or ("物理模型" in q and "涡量" in q)):
        return {"branch": "compute", "tool": "physical_vorticity", "args": {"t": _t(q, 0.2)}}
    if any(k in q for k in ("涡量", "涡度", "vorticity", "多模态")):
        return {"branch": "compute", "tool": "vorticity", "args": {"t": _t(q, 0.2)}}
    if any(k in q for k in ("涡位置", "涡核", "涡心", "涡在哪", "侧线感知的涡")):
        return {"branch": "compute", "tool": "vortex", "args": {"t": _t(q, 0.2)}}
    if any(k in low for k in ("lighthill", "行波", "相速度", "波数")):
        return {"branch": "compute", "tool": "lighthill", "args": {}}
    if any(k in q for k in ("来流速度", "预测", "正向模型", "传感器输出")) and "侧线" in q:
        u = _speed(q)
        args = {"speed": u} if u is not None else {}
        return {"branch": "simulate", "tool": "forward", "args": args}
    if any(k in q for k in ("峰值", "最大", "最小", "这个峰")):
        m = re.search(r"探针\s*(\d+)", q)
        return {"branch": "query", "tool": "peak",
                "args": {"t": _t(q, 0.2), "probe": int(m.group(1)) if m else None}}
    return None


def summarize_llm(q: str, result: dict, plan: dict) -> str:
    # Tool values and caveats must stay verbatim; the LLM may route, but must
    # not silently rewrite a scientific result.
    return result.get("summary", "")


def _looks_like_tool(q: str) -> bool:
    """Only let the planner take questions that ask for a tool.

    Concept questions (侧线是什么/怎么仿真/能感知涡吗) must go to the
    knowledge base, not be forced into origin/peak by an LLM.
    """
    low = q.lower()
    direct = (
        "数据怎么来", "数据来源", "怎么采集", "哪来的", "原始数据",
        "多少探针", "数据量", "多少行", "时间步", "索引多大", "多少帧",
        "峰值", "最大", "最小",
        "压力云图", "云图", "场图", "压力场",
        "涡位置", "涡核", "涡心", "涡在哪", "真涡量", "网格涡量",
        "多模态", "涡量场", "拟合", "lighthill", "行波", "相速度", "波数",
        "来流速度", "预测", "正向模型",
    )
    if any(k in low for k in direct):
        return True
    if "画" in q and any(k in q for k in ("压力", "速度", "涡", "场", "云图", "模态")):
        return True
    if "计算" in q and any(k in q for k in ("涡", "压力", "速度")):
        return True
    return False


def maybe_answer(q: str) -> dict | None:
    if not _looks_like_tool(q):
        return None
    # Known tools use the deterministic router; the LLM is a fallback for
    # ambiguous requests, not a mandatory round-trip on every tool call.
    plan = plan_rules(q) or plan_llm(q)
    if not plan:
        return None
    tool = plan["tool"]
    args = plan.get("args") or {}
    try:
        result = TOOLS[tool](**args)
    except Exception as exc:
        return {"reply": "工具暂时不可用，请检查数据索引和输入参数。", "sources": [], "kind": "error"}

    if result.get("need"):
        return {
            "reply": result["summary"],
            "sources": [],
            "kind": "need_params",
            "plan": plan,
        }

    reply = summarize_llm(q, result, plan)
    if result.get("followup"):
        reply += "\n\n" + result["followup"]
    out = {
        "reply": reply,
        "sources": result.get("sources", []),
        "kind": plan.get("branch", "tool"),
        "plan": plan,
    }
    if result.get("figure"):
        out["image"] = "/outputs/" + result["figure"]
        out["links"] = [{"label": "打开图", "href": "/outputs/" + result["figure"]}]
    if result.get("metrics"):
        out["metrics"] = result["metrics"]
    return out

"""Figures for the guard agent (matplotlib, no external services)."""

from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib import font_manager

from . import config, metrics, store

for _name in ("Microsoft YaHei", "SimHei", "Noto Sans CJK SC", "DejaVu Sans"):
    try:
        font_manager.findfont(_name, fallback_to_default=False)
        plt.rcParams["font.sans-serif"] = [_name]
        break
    except Exception:
        continue
plt.rcParams["axes.unicode_minus"] = False

_Q = {
    "p": ("压强 p/(ρU²)", "RdBu_r"),
    "ux": ("x 方向速度 u_x [m/s]", "coolwarm"),
    "uy": ("y 方向速度 u_y [m/s]", "coolwarm"),
}


def field_plot(t: float, quantity: str = "p", out: str | Path = "outputs/field.png",
               index_dir=None) -> Path:
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    fr = store.split_surfaces(store.frame_at(t, index_dir=index_dir))
    label, cmap = _Q.get(quantity, _Q["p"])
    val = fr["upper"][quantity]
    lo = fr["lower"][quantity]

    fig, axes = plt.subplots(1, 2, figsize=(11, 4.2), gridspec_kw={"width_ratios": [1.5, 1]})
    ax = axes[0]
    xs = np.concatenate([fr["upper"]["x"], fr["lower"]["x"]])
    xq = np.linspace(float(xs.min()), float(xs.max()), 220)
    yu = np.interp(xq, fr["upper"]["x"], fr["upper"]["y"])
    yl = np.interp(xq, fr["lower"]["x"], fr["lower"]["y"])
    pu = np.interp(xq, fr["upper"]["x"], val)
    pl = np.interp(xq, fr["lower"]["x"], lo)
    s = np.linspace(0.0, 1.0, 30)
    X = np.repeat(xq[:, None], len(s), axis=1)
    Y = yu[:, None] * (1 - s)[None, :] + yl[:, None] * s[None, :]
    P = pu[:, None] * (1 - s)[None, :] + pl[:, None] * s[None, :]
    fill = ax.pcolormesh(X, Y, P, cmap=cmap, shading="gouraud")
    ax.scatter(fr["upper"]["x"], fr["upper"]["y"], c=val, cmap=cmap, s=9, label="上表面")
    ax.scatter(fr["lower"]["x"], fr["lower"]["y"], c=lo, cmap=cmap, s=9, marker="s", label="下表面")
    ax.set_aspect(4.0)
    ax.set_xlabel("x [m]")
    ax.set_ylabel("y [m]")
    ax.set_title(f"表面场 t={fr['time']:.4f} s（y 放大 ×4，插值示意）")
    ax.legend(loc="upper right", fontsize=8, markerscale=1.5)
    fig.colorbar(fill, ax=ax, fraction=0.035, pad=0.02, label=label)

    ax = axes[1]
    ax.plot(fr["upper"]["x"], val, "-o", ms=2.2, lw=1.1, color="#c53030", label="上表面")
    ax.plot(fr["lower"]["x"], lo, "-s", ms=2.2, lw=1.1, color="#2b6cb0", label="下表面")
    ax.set_xlabel("x [m]")
    ax.set_ylabel(label)
    ax.set_title("上/下表面分布")
    ax.grid(alpha=0.25)
    ax.legend(fontsize=8)

    fig.tight_layout()
    fig.savefig(out, dpi=170)
    plt.close(fig)
    return out


def metrics_plot(out: str | Path = "outputs/metrics.png") -> Path:
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    rows = metrics.table()
    quantities = ["p", "ux", "uy"]
    datasets = ["dmd_v2", "dmd_old"]
    colors = {"dmd_v2": "#2b6cb0", "dmd_old": "#718096"}
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.0), sharey=True)
    width = 0.35
    for ax, metric in zip(axes, ("A", "B")):
        xpos = np.arange(len(quantities))
        for j, ds in enumerate(datasets):
            vals = []
            for q in quantities:
                hit = [r for r in rows if r["dataset"] == ds and r["quantity"] == q]
                vals.append(hit[0][metric] if hit else np.nan)
            ax.bar(xpos + (j - 0.5) * width, vals, width, label=ds, color=colors[ds], alpha=0.9)
            for x, v in zip(xpos + (j - 0.5) * width, vals):
                if np.isfinite(v):
                    ax.text(x, v + 0.004, f"{v:.3f}", ha="center", va="bottom", fontsize=7)
        ax.set_xticks(xpos)
        ax.set_xticklabels(["p", "u_x", "u_y"])
        ax.set_ylim(0.78, 1.02)
        ax.grid(axis="y", alpha=0.25)
        ax.set_title(f"指标 {metric}（{'形状' if metric == 'A' else '绝对'}）")
    axes[0].set_ylabel("score")
    axes[1].legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(out, dpi=170)
    plt.close(fig)
    return out


def series_plot(probe: int, quantity: str = "p", t0: float = 0.1, t1: float = 1.0,
                out: str | Path = "outputs/series.png", index_dir=None) -> Path:
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    d = store.query(probe, t0, t1, quantity, index_dir=index_dir)
    label, _ = _Q.get(quantity, _Q["p"])
    fig, ax = plt.subplots(figsize=(7.2, 3.4))
    ax.plot(d["time"], d["value"], lw=1.0, color="#2b6cb0")
    ax.set_xlabel("time [s]")
    ax.set_ylabel(label)
    ax.set_title(f"探针 {probe}（{d['n']} 点）")
    ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(out, dpi=170)
    plt.close(fig)
    return out


def overview(out: str | Path = "outputs/overview.png", t: float = 0.2) -> Path:
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    fr = store.split_surfaces(store.frame_at(t))
    fig, axes = plt.subplots(2, 2, figsize=(11, 7.2))

    ax = axes[0, 0]
    sc = ax.scatter(fr["upper"]["x"], fr["upper"]["y"], c=fr["upper"]["p"], cmap="RdBu_r", s=8)
    ax.scatter(fr["lower"]["x"], fr["lower"]["y"], c=fr["lower"]["p"], cmap="RdBu_r", s=8, marker="s")
    ax.set_aspect(4.0)
    ax.set_title(f"鱼体表面压强，t={fr['time']:.4f} s（y ×4）")
    ax.set_xlabel("x [m]"); ax.set_ylabel("y [m]")
    fig.colorbar(sc, ax=ax, fraction=0.04, pad=0.02)

    ax = axes[0, 1]
    ax.plot(fr["upper"]["x"], fr["upper"]["p"], color="#c53030", lw=1.1, label="upper")
    ax.plot(fr["lower"]["x"], fr["lower"]["p"], color="#2b6cb0", lw=1.1, label="lower")
    ax.set_title("沿弦压强分布")
    ax.set_xlabel("x [m]"); ax.set_ylabel("p/(ρU²)")
    ax.grid(alpha=0.25); ax.legend(fontsize=8)

    ax = axes[1, 0]
    rows = metrics.table()
    for ds, color in (("dmd_v2", "#2b6cb0"), ("dmd_old", "#718096")):
        vals = [r["A"] for r in rows if r["dataset"] == ds]
        ax.plot(["p", "u_x", "u_y"], vals, "o-", color=color, label=ds)
    ax.set_ylim(0.94, 1.0)
    ax.set_title("指标 A（形状）")
    ax.grid(alpha=0.25); ax.legend(fontsize=8)

    ax = axes[1, 1]
    for ds, color in (("dmd_v2", "#2b6cb0"), ("dmd_old", "#718096")):
        vals = [r["B"] for r in rows if r["dataset"] == ds]
        ax.plot(["p", "u_x", "u_y"], vals, "o-", color=color, label=ds)
    ax.set_ylim(0.84, 1.0)
    ax.set_title("指标 B（绝对）")
    ax.grid(alpha=0.25); ax.legend(fontsize=8)

    fig.tight_layout()
    fig.savefig(out, dpi=170)
    plt.close(fig)
    return out

"""Compare two indexed datasets on their overlapping time window."""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor

import numpy as np

from . import config, metrics, store


def _series(index_dir, probe: int, t0: float, t1: float, quantity: str):
    d = store.query(probe, t0, t1, quantity, index_dir=index_dir)
    return np.asarray(d["time"], dtype=float), np.asarray(d["value"], dtype=float)


def load_matrix(index_dir, quantity: str, t0: float, t1: float, max_workers: int = 16):
    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        rows = list(ex.map(lambda p: _series(index_dir, p, t0, t1, quantity), range(config.N_PROBES)))
    times = rows[0][0]
    mat = np.stack([r[1] for r in rows], axis=1)
    return times, mat


def _trim_mask(trim: int) -> np.ndarray:
    if trim <= 0:
        return np.arange(config.N_PROBES)
    up = np.arange(trim, config.N_SIDE - trim)
    lo = np.arange(config.N_SIDE + trim, 2 * config.N_SIDE - trim)
    return np.concatenate([up, lo])


def _prepare(index_a, index_b, quantity: str, t0: float | None, t1: float | None):
    ma = store.manifest(index_a)
    mb = store.manifest(index_b)
    t0 = max(ma["time_start"], mb["time_start"]) if t0 is None else t0
    t1 = min(ma["time_end"], mb["time_end"]) if t1 is None else t1
    t0 = float(t0)
    t1 = float(t1)
    if t1 <= t0:
        raise ValueError("no overlapping time window")

    ta, Ma = load_matrix(index_a, quantity, t0, t1)
    tb, Mb = load_matrix(index_b, quantity, t0, t1)
    Ma_on_b = np.empty_like(Mb)
    for j in range(Ma.shape[1]):
        Ma_on_b[:, j] = np.interp(tb, ta, Ma[:, j])
    return tb, Mb, Ma_on_b


def compare_many(index_a, index_b, quantity: str = "p", t0: float | None = None,
                 t1: float | None = None, trims=(0, 24)) -> list[dict]:
    """Load both matrices once, return one result per trim value."""
    tb, Mb, Ma_on_b = _prepare(index_a, index_b, quantity, t0, t1)
    out = []
    for trim in trims:
        mask = _trim_mask(int(trim))
        score = metrics.score(Mb[:, mask], Ma_on_b[:, mask])
        out.append({
            "a": str(index_a),
            "b": str(index_b),
            "quantity": quantity,
            "t0": round(float(tb[0]), 6),
            "t1": round(float(tb[-1]), 6),
            "frames": int(len(tb)),
            "probes": int(mask.size),
            "trim": int(trim),
            "A": score["A"],
            "B": score["B"],
            "RMSE": score["RMSE"],
        })
    return out


def compare(index_a, index_b, quantity: str = "p", t0: float | None = None,
            t1: float | None = None, trim: int = 0) -> dict:
    """Compare dataset A (reference) with B (prediction) on B's time grid."""
    return compare_many(index_a, index_b, quantity, t0, t1, trims=(trim,))[0]


def compare_physical(quantity: str = "p", trim: int = 0) -> dict:
    """DMD v2 vs the runnable package's physical output, on the overlap [0.1, 1.0]."""
    return compare(config.INDEX, config.INDEX_PHYSICAL, quantity, trim=trim)

"""A small closed-loop research agent: locate → compare → critic → conclude.

This is the "agent" part on top of the tools: it decides which checks to run,
applies the guardrails to the observed numbers, and writes a reproducible record.
It is deliberately bounded to the bionic-fish flow project.
"""

from __future__ import annotations

import json
import time
import uuid
from pathlib import Path

from . import compare, config, runner, store

EXPERIMENTS = config.ROOT / "data" / "experiments.jsonl"


def _now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")


def _find_index(freq: float, run_dir: str | Path | None = None) -> Path | None:
    if run_dir:
        d = Path(run_dir)
        for p in (d, d / "index"):
            if (p / "manifest.json").exists():
                return p
        return None
    if abs(freq - 2.0) < 1e-9 and (config.INDEX_PHYSICAL / "manifest.json").exists():
        return config.INDEX_PHYSICAL
    runs = config.ROOT / "data" / "runs"
    if not runs.exists():
        return None
    hits = []
    for d in runs.glob(f"*_f{freq:g}"):
        idx = d / "index"
        if (idx / "manifest.json").exists():
            hits.append(idx)
    return max(hits, key=lambda p: p.stat().st_mtime) if hits else None


def _critic(freq: float, t_end: float, full: dict, tr: dict) -> list[dict]:
    checks = []
    if abs(freq - 2.0) > 1e-9:
        checks.append({
            "level": "BLOCK", "code": "FREQ_MISMATCH",
            "message": f"DMD 只在 2.0 Hz 上拟合；{freq:g} Hz 的 A/B 不是精度，只说明外推失败。",
        })
    if t_end < 0.1:
        checks.append({
            "level": "BLOCK", "code": "STARTUP_TRANSIENT",
            "message": "t_end<0.1 s 整段落在启动瞬态内，p/力系数不能当稳态结论。",
        })
    if abs(full["A"] - tr["A"]) > 0.10:
        checks.append({
            "level": "WARN", "code": "CUSP_DOMINANT",
            "message": f"全 404 A={full['A']:.3f}，trim 后 A={tr['A']:.3f}；尖点探针主导，必须报 trim。",
        })
    if tr["B"] < 0.30 or tr["A"] < 0.30:
        checks.append({
            "level": "WARN", "code": "MODEL_FORM_GAP",
            "message": f"trim 后 A={tr['A']:.3f} / B={tr['B']:.3f}；这是无黏/尖点的模型形式差距，不能称“精度”。",
        })
    if abs(freq - 2.0) < 1e-9 and tr["A"] >= 0.80 and tr["B"] >= 0.70:
        checks.append({
            "level": "PASS", "code": "USABLE",
            "message": f"2 Hz、trim 后 A={tr['A']:.3f} / B={tr['B']:.3f}；可用于形状复现，不用于外推。",
        })
    return checks


def _conclusion(freq: float, verdict: str, full: dict, tr: dict) -> str:
    if verdict == "BLOCK":
        return (
            f"结论：不能用 DMD 处理 {freq:g} Hz 工况。DMD 的拟合频率是 2.0 Hz；"
            f"当前对比（全 404 A={full['A']:.3f}，trim A={tr['A']:.3f}，B={tr['B']:.3f}）"
            "只说明外推失败，不是模型精度。要预测新工况，只能用物理模型重算。"
        )
    if verdict == "WARN":
        return (
            f"结论：物理模型与 DMD 存在模型形式差距（trim A={tr['A']:.3f}，B={tr['B']:.3f}）。"
            "形状可参考，绝对幅值不可当精度；必须声明 trim 与时间窗。"
        )
    return (
        f"结论：在 2 Hz、trim 后 A={tr['A']:.3f}、B={tr['B']:.3f}，可用于形状复现；"
        "不能外推到新频率/新几何。"
    )


def research(goal: str = "extrapolation", freq: float = 3.0, t_end: float = 1.0,
             dt: float = 0.001, trim: int = 24, quantity: str = "p",
             execute: bool = False, run_dir: str | Path | None = None) -> dict:
    steps: list[dict] = []
    hypothesis = (
        f"DMD（2.0 Hz 拟合）能否用于 {freq:g} Hz 的物理场？"
        if abs(freq - 2.0) > 1e-9 else
        "物理模型与 DMD 在 2.0 Hz 上是否一致？"
    )

    idx = _find_index(freq, run_dir)
    if idx is None:
        if not execute:
            return {
                "status": "need_data",
                "message": f"没有 {freq:g} Hz 的现成索引；加 --execute 先跑，或提供 --run-dir。",
                "freq": freq,
            }
        steps.append({"n": 1, "action": "run_physical",
                      "params": {"freq": freq, "t_end": t_end, "dt": dt},
                      "observation": "开始运行物理模型（可能 1–4 分钟）"})
        res = runner.run_physical(freq=freq, t_end=t_end, dt=dt, do_compare=False)
        if res.get("status") != "ok":
            return {"status": "error", "message": "run failed", "run": res, "steps": steps}
        idx = Path(res["index"])
        steps[-1]["observation"] = f"完成：{res['run_id']}，{res['table_mb']} MB"
    else:
        steps.append({"n": 1, "action": "locate_data",
                      "params": {"freq": freq},
                      "observation": str(idx)})

    rows = compare.compare_many(config.INDEX, idx, quantity, trims=(0, trim))
    full, tr = rows[0], rows[-1]
    steps.append({
        "n": 2, "action": "compare",
        "params": {"reference": str(config.INDEX), "target": str(idx),
                   "quantity": quantity, "trims": [0, trim]},
        "observation": {
            "full": {k: full[k] for k in ("A", "B", "RMSE", "probes")},
            "trim": {k: tr[k] for k in ("A", "B", "RMSE", "probes")},
        },
    })

    checks = _critic(freq, t_end, full, tr)
    verdict = "BLOCK" if any(c["level"] == "BLOCK" for c in checks) else (
        "WARN" if any(c["level"] == "WARN" for c in checks) else "PASS")
    steps.append({"n": 3, "action": "critic",
                  "params": {"rules": [c["code"] for c in checks]},
                  "observation": checks})

    conclusion = _conclusion(freq, verdict, full, tr)
    exp_id = "exp-" + uuid.uuid4().hex[:10]
    record = {
        "id": exp_id,
        "ts": _now(),
        "goal": goal,
        "hypothesis": hypothesis,
        "params": {"freq": freq, "t_end": t_end, "dt": dt, "trim": trim,
                   "quantity": quantity, "execute": execute},
        "steps": steps,
        "metrics": {"full": full, "trim": tr},
        "critic": checks,
        "verdict": verdict,
        "conclusion": conclusion,
        "artifacts": {"index": str(idx)},
    }

    md_path = config.OUTPUTS / f"research_{exp_id}.md"
    md = [
        f"# Research record {exp_id}",
        "",
        f"- 目标：{goal}",
        f"- 假设：{hypothesis}",
        f"- 参数：freq={freq:g}, t_end={t_end:g}, dt={dt:g}, trim={trim}, quantity={quantity}",
        "",
        "## 步骤",
        "",
    ]
    for s in steps:
        md.append(f"{s['n']}. **{s['action']}** — {s['observation']}")
    md += [
        "",
        "## 指标",
        "",
        "| trim | probes | A | B | RMSE |",
        "|---|---|---|---|---|",
        f"| 0 | {full['probes']} | {full['A']:.4f} | {full['B']:.4f} | {full['RMSE']:.4f} |",
        f"| {trim} | {tr['probes']} | {tr['A']:.4f} | {tr['B']:.4f} | {tr['RMSE']:.4f} |",
        "",
        "## 护栏判定",
        "",
    ]
    md += [f"- **[{c['level']}] {c['code']}** — {c['message']}" for c in checks]
    md += ["", "## 结论", "", conclusion, ""]
    md_path.write_text("\n".join(md), encoding="utf-8")
    record["artifacts"]["record_md"] = str(md_path)

    EXPERIMENTS.parent.mkdir(parents=True, exist_ok=True)
    with EXPERIMENTS.open("a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")

    return {"status": "ok", **record}


def log(n: int = 10) -> list[dict]:
    if not EXPERIMENTS.exists():
        return []
    out = []
    for line in EXPERIMENTS.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line:
            try:
                out.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return out[-n:]

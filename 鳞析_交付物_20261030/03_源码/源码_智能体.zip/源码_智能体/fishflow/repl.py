"""Small interactive shell: `python -m fishflow.repl`.

No extra dependency; useful when you want to poke the data without DSH.
"""

from __future__ import annotations

import sys

from . import config, diagnose, report, research, runner, store
from .compare import compare_many

HELP = """
可用命令：
  /q <probe> <t0> <t1> [p|ux|uy]   查一个探针（例：/q 17 0.1 0.2 p）
  /compare [trim]                  物理模型 vs DMD（默认 trim=24）
  /research <freq>                 闭环：定位→对比→判定（例：/research 3）
  /report                          生成 HTML 报告
  /runs                            看历史运行
  /help                            帮助
  /quit                            退出

直接输入一句中文问题，会走护栏问答，例如：
  DMD 能不能外推到 25 秒之后？
"""


def _q(line: str) -> None:
    parts = line.split()
    if len(parts) < 4:
        print("用法：/q <probe> <t0> <t1> [p|ux|uy]")
        return
    probe, t0, t1 = int(parts[1]), float(parts[2]), float(parts[3])
    q = parts[4] if len(parts) > 4 else "p"
    d = store.query(probe, t0, t1, q)
    vals = d["value"]
    if not vals:
        print("没有数据")
        return
    print(f"探针 {probe} / {q} / {d['n']} 点：min={min(vals):.4f} max={max(vals):.4f} "
          f"mean={sum(vals)/len(vals):.4f} first={vals[0]:.4f} last={vals[-1]:.4f}")


def _compare(line: str) -> None:
    parts = line.split()
    trim = int(parts[1]) if len(parts) > 1 else 24
    rows = compare_many(config.INDEX, config.INDEX_PHYSICAL, "p", trims=(0, trim))
    for r in rows:
        print(f"trim={r['trim']:3d}  probes={r['probes']:3d}  A={r['A']:.4f}  "
              f"B={r['B']:.4f}  RMSE={r['RMSE']:.4f}")


def _research(line: str) -> None:
    parts = line.split()
    freq = float(parts[1]) if len(parts) > 1 else 3.0
    r = research.research(freq=freq)
    if r.get("status") != "ok":
        print(r.get("message", "research failed"))
        return
    print(f"verdict: {r['verdict']}")
    print(r["conclusion"])
    print("record:", r["artifacts"].get("record_md", ""))


def main() -> int:
    if hasattr(sys.stdin, "reconfigure"):
        sys.stdin.reconfigure(encoding="utf-8", errors="replace")
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    print("=" * 66)
    print("  鳞析 · 交互模式（输入 /help 看命令）")
    print("=" * 66)
    while True:
        try:
            line = input("鳞析> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not line:
            continue
        if line in ("/quit", "/exit", "quit", "exit"):
            break
        try:
            if line == "/help":
                print(HELP)
            elif line.startswith("/q "):
                _q(line)
            elif line.startswith("/compare"):
                _compare(line)
            elif line.startswith("/research"):
                _research(line)
            elif line == "/report":
                out = report.build()
                print("HTML:", out["html"])
            elif line == "/runs":
                for r in runner.list_runs():
                    print(f"{r['run_id']}  {r['status']:8s} {r['percent']:5.1f}%  {r['path']}")
            elif line.startswith("/"):
                print("未知命令；输入 /help")
            else:
                print(diagnose.format_text(diagnose.answer(line)))
        except Exception as exc:
            print(f"错误：{type(exc).__name__}: {exc}")
    print("再见。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

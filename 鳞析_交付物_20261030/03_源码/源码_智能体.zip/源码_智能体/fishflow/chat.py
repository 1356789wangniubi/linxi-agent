"""Conversational backend for the local chat UI.

The agent persona is a bionic-fish flow assistant.  Domain questions go through
the deterministic tools (so numbers are never invented); general questions can
optionally go to an OpenAI-compatible local/campus model via env vars.
"""

from __future__ import annotations

import json
import os
import re
import time
import urllib.request
from typing import Any

from . import agent as agent_mod
from . import config, diagnose, lateral_line, papers, sim_agent, store, user_csv, validate_user
from .compare import compare_many

_CACHE: dict[str, tuple[float, Any]] = {}
CACHE_TTL = 300


def _cached(key: str, fn):
    hit = _CACHE.get(key)
    if hit and time.time() - hit[0] < CACHE_TTL:
        return hit[1]
    val = fn()
    _CACHE[key] = (time.time(), val)
    return val


PERSONA = (
    "我是**鳞析**，一个**鱼类侧线仿真**助手。"
    "你可以问我侧线是什么、表浅/管道神经丘怎么建模、阵列怎么布置、偶极子源怎么定位、"
    "涡/尾流怎么感知，也可以让我直接画一个侧线信号。"
    "这条鱼的数据、R² 和 DMD 的问题我也能答。"
)

HELP = """我可以做这些：

**先想清楚**
- “我该怎么开始？” / “带我理一遍思路”

**侧线本身**
- 侧线是什么？表浅和管道神经丘有什么区别？
- 侧线能感知什么？能感知涡吗？

**侧线仿真**
- 侧线仿真怎么做？传感器模型怎么建？
- 阵列怎么布置？偶极子源怎么定位？
- 用什么软件？机器学习/强化学习怎么用？

**直接看信号**
- “给我看一个偶极子源的侧线信号”
- “我的 404 探针能当侧线用吗？”

**引导仿真**
- “我给你一条鱼，帮我做侧线仿真”
- 填参数 → 出阵列图 + 信噪比 + 源定位误差

**检验你的结果**
- “检验我的仿真” → 上传 CSV → 指标 + 四联图
- “坐标查压强” → 打开 x/y/t 查询页

**这条鱼的数据**
- 查探针 17 在 0.1 到 0.2 秒的压强
- p 的 R² 0.99，为什么还说压强不准？
- 3 Hz 工况能不能用 DMD？

**十篇论文**
- “十篇论文是哪十篇？” / “Tu 2014 的 DMD 有什么局限？”
"""

GUIDE = """遇到“一条鱼/一个仿真结果”，我建议按 5 步走：

1. **先问数据从哪来**：谁算的、二维还是三维、单位是什么、时间窗是否含启动瞬态。
2. **再问模型假设**：势流/无黏/细长体/线性 DMD？假设不成立，后面的 R² 再高也不能直接信。
3. **再问口径**：A 是形状、B 是绝对；B 的分母是参考还是预测？两边单位一致吗？
4. **再做对照**：和参考数据、物理模型、文献趋势分别比；不只看一个数。
5. **最后写边界**：能支持什么结论、不能支持什么；还缺哪块数据。

你可以直接说“带我走一遍”，我就按这 5 步问你。"""

SYSTEM = """你是“鳞析”，一个鱼类侧线仿真助手。
事实边界（必须遵守）：
- 鱼类侧线：表浅神经丘感受局部流速，管道神经丘感受孔口压差；仿真必须加传感模型、噪声和自身运动干扰。
- 侧线仿真流程：流场（解析/CFD）→ 鱼体/传感器几何 → 传感模型 → 信号 → 解码 → 验证。
- 这条鱼的数据是二维无黏势流、404 个表面探针、dt=0.0005 s；可以作为“密集压力阵列”降采样，但没有边界层和涡。
- DMD 在 2.0 Hz 上拟合，留出测试 R²=-7.11，不能外推；物理模型可外推。
- 不要编数字，不要编用户日志；不确定就说不确定。"""


def _fmt_diag(r: dict) -> dict:
    if r.get("status") != "ok":
        return {
            "reply": r.get("message", "这个问题我暂时答不了。"),
            "sources": [],
            "kind": "need_more_info",
        }
    ev = "\n".join(f"- {e}" for e in r["evidence"])
    reply = f"**{r['title']}**\n\n{r['answer']}\n\n**依据**\n{ev}\n\n**护栏**：{r['guardrail']}"
    return {"reply": reply, "sources": r["evidence"], "kind": "guardrail"}


def _probe_query(q: str) -> dict | None:
    m = re.search(r"探针\s*(\d+)", q)
    if not m:
        return None
    probe = int(m.group(1))
    tm = re.search(r"(\d+(?:\.\d+)?)\s*(?:到|~|-|—|至)\s*(\d+(?:\.\d+)?)", q)
    t0, t1 = (float(tm.group(1)), float(tm.group(2))) if tm else (0.1, 0.2)
    quantity = "p"
    if "u_x" in q or "x方向" in q or "x 方向" in q or "x 速度" in q:
        quantity = "ux"
    elif "u_y" in q or "y方向" in q or "y 方向" in q or "y 速度" in q:
        quantity = "uy"
    index_dir = config.INDEX_PHYSICAL if "物理" in q else config.INDEX
    d = store.query(probe, t0, t1, quantity, index_dir=index_dir)
    if not d["value"]:
        return {"reply": "这个时间窗里没有数据。", "sources": [], "kind": "query"}
    vals = d["value"]
    label = {"p": "压强 p/(ρU²)", "ux": "x 方向速度", "uy": "y 方向速度"}[quantity]
    reply = (
        f"探针 **{probe}** 在 **{t0:g}–{t1:g} s** 的 {label}：\n\n"
        f"- 点数：{d['n']}\n"
        f"- 最小：{min(vals):.4f}\n"
        f"- 最大：{max(vals):.4f}\n"
        f"- 均值：{sum(vals)/len(vals):.4f}\n"
        f"- 首/末：{vals[0]:.4f} / {vals[-1]:.4f}"
    )
    return {"reply": reply, "sources": [f"data/index{'/physical' if '物理' in q else ''}"],
            "kind": "query"}


def _compare() -> dict:
    def work():
        return compare_many(config.INDEX, config.INDEX_PHYSICAL, "p", trims=(0, 24))

    rows = _cached("compare", work)
    full, tr = rows[0], rows[1]
    reply = (
        "物理模型 vs DMD（p，时间窗 [0.1, 1.0]）：\n\n"
        f"- 全 404 探针：A={full['A']:.3f}，B={full['B']:.3f}，RMSE={full['RMSE']:.2f}\n"
        f"- 剔除鼻尖/尾缘各 24（308 探针）：A={tr['A']:.3f}，B={tr['B']:.3f}，RMSE={tr['RMSE']:.2f}\n\n"
        "低 R² 是**无黏 + 尖点**的模型形式差距，不是相位/单位 bug；"
        "形状可参考，绝对幅值不能当精度。"
    )
    return {"reply": reply, "sources": ["compare --physical --trim 24"], "kind": "compare"}


def _research_3hz() -> dict:
    from . import research

    r = _cached("research3", lambda: research.research(freq=3.0))
    if r.get("status") != "ok":
        return {"reply": r.get("message", "3 Hz 数据还没准备好。"), "sources": [], "kind": "research"}
    reply = (
        f"**判定：{r['verdict']}**\n\n{r['conclusion']}\n\n"
        f"记录：`{r['artifacts'].get('record_md','')}`"
    )
    return {"reply": reply, "sources": [s.get("action", "") for s in r["steps"]], "kind": "research"}


def _llm(q: str, history: list[dict] | None) -> str | None:
    url = os.environ.get("FISHFLOW_LLM_URL")
    if not url:
        return None
    model = os.environ.get("FISHFLOW_LLM_MODEL")
    if not model:
        model = "glm-5.3-flash" if "bigmodel.cn" in url else "qwen2.5:7b-instruct"
    key = os.environ.get("FISHFLOW_LLM_KEY") or os.environ.get("ZHIPU_API_KEY")
    if not key and "bigmodel.cn" in url:
        try:
            from .secret_store import load as _load_secret
            key = _load_secret("zhipu")
        except Exception:
            key = None
    if not key and ("11434" in url or "localhost" in url or "127.0.0.1" in url):
        key = "ollama"
    if not key:
        return None
    msgs = [{"role": "system", "content": SYSTEM}]
    for h in (history or [])[-6:]:
        if h.get("role") in ("user", "assistant") and h.get("content"):
            msgs.append({"role": h["role"], "content": h["content"]})
    msgs.append({"role": "user", "content": q})
    body = json.dumps({"model": model, "messages": msgs, "temperature": 0.2,
                       "max_tokens": 1024}).encode("utf-8")
    req = urllib.request.Request(
        url, data=body,
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {key}"},
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        return data["choices"][0]["message"]["content"].strip()
    except Exception:
        return None


def _is_lateral(q: str) -> bool:
    keys = ("侧线", "lateral", "神经丘", "neuromast", "偶极子", "dipole",
            "阵列", "涡", "尾流", "管道", "表浅")
    ql = q.lower()
    return any(k in ql for k in keys)


def _lateral_demo(q: str) -> dict:
    if "404" in q or "我的数据" in q or "探针" in q:
        r = lateral_line.from_probes()
        reply = (
            "把 **404 个表面探针**的上表面降采样成 **16 点阵列**，"
            "热图是每个点的压力随时间变化，右边是 4 个代表点的时序。\n\n"
            "这可以当作“表浅神经丘阵列”的代理；但它是二维无黏势流，没有边界层和涡，"
            "适合验证阵列/解码流程，不适合声称真实侧线精度。"
        )
        href = "/outputs/ll_from_probes.png"
        src = "lateral_line.from_probes（404 探针降采样）"
    else:
        r = lateral_line.simulate_dipole()
        reply = (
            "这是一个 **2 Hz 振动偶极子 + 16 传感器阵列** 的最小侧线仿真：\n\n"
            "- 左图：偶极子压力场，黑点是体侧阵列；\n"
            "- 右图：4 个传感器上的压力时序；\n"
            "- 源在 (0.55, 0.22)，阵列在 y=0。\n\n"
            "它用的是解析偶极子，不是 CFD；适合讲清“源—传播—阵列信号”的关系。"
        )
        href = "/outputs/ll_dipole.png"
        src = "lateral_line.simulate_dipole（解析偶极子，2 Hz）"
    return {
        "reply": reply,
        "sources": [src],
        "kind": "lateral_demo",
        "links": [{"label": "打开图", "href": href}],
    }


def _is_sim_request(q: str) -> bool:
    asks = ("给你一条鱼", "给你条鱼", "我给你一条", "帮我做", "引导我", "开始仿真",
            "做一个仿真", "跑一个仿真", "跑个仿真", "帮我仿真", "带我做")
    know = ("怎么", "流程", "步骤", "是什么", "区别", "为什么", "原理")
    return any(k in q for k in asks) and not any(k in q for k in know)


def _sim_form() -> dict:
    return {
        "reply": (
            "可以。先把这条鱼和场景定下来，我带你跑一遍：\n\n"
            "1. 体长/体高/流速；\n"
            "2. 侧线传感器数量；\n"
            "3. 振动源位置/频率；\n"
            "4. 噪声。\n\n"
            "下面用默认值就行，也可以改成你的鱼。跑完会给你：阵列信号图、信噪比、源定位误差。"
        ),
        "sources": [],
        "kind": "sim_form",
        "form": sim_agent.form(),
    }


def answer(message: str, history: list[dict] | None = None) -> dict:
    q = (message or "").strip()
    if not q:
        return {"reply": "你想问什么？可以直接说，比如“3 Hz 能不能用 DMD？”", "sources": [], "kind": "empty"}

    low = q.lower()
    # meta
    if any(k in q for k in ("你是谁", "你是什么", "介绍一下你")):
        return {"reply": PERSONA, "sources": [], "kind": "meta"}
    if any(k in q for k in ("能做什么", "会什么", "怎么用", "帮助", "help")):
        return {"reply": HELP, "sources": [], "kind": "meta"}
    if q in ("你好", "您好", "在吗", "hi", "hello", "哈喽"):
        return {"reply": "你好，我是鳞析。你可以问侧线是什么、怎么仿真、阵列怎么布置，也可以让我画一个侧线信号。",
                "sources": [], "kind": "greeting"}
    if any(k in q for k in ("谢谢", "感谢")):
        return {"reply": "不客气。要查数据、做对比或出报告，随时说。", "sources": [], "kind": "thanks"}

    # ten-paper reading pack
    pr = papers.answer(q)
    if pr:
        return pr

    if any(k in q for k in ("怎么开始", "我该怎么", "带我", "思路", "理一遍")):
        return {"reply": GUIDE, "sources": [], "kind": "guide"}

    # validation upload
    has_pasted_data = bool(
        re.search(r"(?:^|[,\s])(?:t|time|时间)\s*=", q, re.I)
        and re.search(r"(?:p|pressure|压强|压力|ux|u_x|uy|u_y|x速度|y速度)\s*=", q, re.I)
    )
    if any(k in q for k in ("检验我的", "校验我的", "我的仿真", "是否正确",
                            "帮我看看对不对", "对比我的", "检查我的",
                            "没有文件", "口述数据", "粘贴数据", "哪里错", "为什么不对")) and not has_pasted_data:        return {
            "reply": (
                "可以。请上传你的仿真 CSV，**或者直接把数据粘贴进来**，我会做三件事：\n\n"
                "1. 读你的数据，推断鱼体尺寸/探针覆盖；\n"
                "2. 和参考索引对齐，算 A/B、RMSE、偏差、均值比；\n"
                "3. 给你四联图 + 表格，并指出单位/时间/列映射问题。\n\n"
                "CSV 至少要有 `time`，以及 `probe` 或 `x,y`；物理量至少给 `p/ux/uy` 之一。"
            ),
            "sources": [],
            "kind": "validate_form",
        }

    # data pasted directly into chat
    if re.search(r"(?:^|[,\s])(?:t|time|时间)\s*=", q, re.I) and re.search(
            r"(?:p|pressure|压强|压力|ux|u_x|uy|u_y|x速度|y速度)\s*=", q, re.I):
        try:
            built = user_csv.parse_to_csv(q)
        except Exception as exc:
            return {"reply": f"数据没解析成功：{exc}", "sources": [], "kind": "error"}
        if any(k in q for k in ("检验", "校验", "对不对", "正确", "哪里错", "为什么不对", "什么问题", "怎么错")):
            v = validate_user.validate(built["csv"])
            v["csv_file"] = built["file"]
            v["image"] = "/outputs/" + v["figure"]
            v["kind"] = "validate"
            v["links"] = [{"label": "打开校验图", "href": v["image"]},
                          {"label": "下载 CSV", "href": "/outputs/" + built["file"]}]
            v["reply"] = v["reply"] + f"\n\n已从你的输入生成 `{built['file']}`。"
            return v
        return {
            "reply": f"已从你的数据生成 **{built['rows']} 行** CSV：`{built['file']}`。\n\n"
                     "你可以点“检验”上传它，或直接说“检验这份数据”。",
            "sources": [],
            "kind": "user_csv",
            "links": [{"label": "下载 CSV", "href": "/outputs/" + built["file"]}],
        }

    # synthetic sample
    if any(k in q for k in ("示例数据", "生成一份数据", "给我一个模板", "没有数据")):
        built = user_csv.sample_from_reference()
        return {
            "reply": f"给你生成了一份**示例 CSV**（{built['rows']} 行，来自参考索引，不是实测）："
                     f"`{built['file']}`。\n\n"
                     "它只用于检查检验流程；不要把它当你的实验结果。",
            "sources": [],
            "kind": "user_csv",
            "links": [{"label": "下载示例 CSV", "href": "/outputs/" + built["file"]}],
        }

    # coordinate lookup page
    if "坐标" in q and any(k in q for k in ("压强", "压力", "速度")) and any(k in q for k in ("查询", "查", "输入", "显示", "平台")):
        return {
            "reply": "打开坐标查询页，输入 x/y/t 就能查最近的压强和速度：",
            "sources": [],
            "kind": "point",
            "links": [{"label": "打开坐标查询", "href": "/point"}],
        }

    # LLM-planned tool branches: query / compute / simulate
    tool_reply = agent_mod.maybe_answer(q)
    if tool_reply:
        return tool_reply

    # guided simulation
    if _is_sim_request(q):
        return _sim_form()

    # lateral-line domain: demo first, then knowledge
    if _is_lateral(q):
        if any(k in q for k in ("看", "画", "演示", "信号", "长什么样", "仿真一下")):
            return _lateral_demo(q)
        lr = lateral_line.answer(q)
        if lr.get("status") == "ok":
            return {"reply": lr["reply"], "sources": lr["sources"], "kind": "lateral"}

    # probe
    probe = _probe_query(q)
    if probe:
        return probe

    # 3Hz / extrapolation
    if ("3" in q and ("hz" in low or "赫兹" in q)) or ("3 hz" in low) or ("三赫兹" in q):
        return _research_3hz()

    # compare
    if ("物理模型" in q and ("dmd" in low or "对比" in q or "差多少" in q)):
        return _compare()

    # report
    if any(k in q for k in ("报告", "证据", "导出", "pdf")):
        return {
            "reply": "报告在这里：单文件 HTML，图/动画/证据链都内嵌，点下面的按钮打开。",
            "sources": ["outputs/guard_report.html"],
            "kind": "report",
            "links": [{"label": "打开报告", "href": "/outputs/guard_report.html"},
                      {"label": "看 28 秒视频", "href": "/outputs/demo_reel.gif"}],
        }

    # guardrail knowledge
    r = diagnose.answer(q)
    if r.get("status") == "ok":
        return _fmt_diag(r)

    # optional LLM for general questions
    llm = _llm(q, history)
    if llm:
        return {"reply": llm, "sources": ["local/campus LLM"], "kind": "llm"}

    return {
        "reply": (
            "这个问题不在我的资料范围内。我目前最擅长：\n\n"
            "- 侧线是什么 / 表浅 vs 管道神经丘\n"
            "- 侧线仿真流程 / 传感模型 / 阵列布置\n"
            "- 偶极子源 / 涡与尾流 / 源定位\n"
            "- 404 探针能不能当侧线\n"
            "- 这条鱼的数据 / R² / DMD\n\n"
            "你可以换个问法，或者点下面的示例。"
        ),
        "sources": [],
        "kind": "fallback",
    }

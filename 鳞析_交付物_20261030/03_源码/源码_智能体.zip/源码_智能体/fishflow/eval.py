"""10+ question benchmark for the guardrail router.

Run: python -m fishflow.eval
It prints a scorecard and exits non-zero if any expected route is missed.
"""

from __future__ import annotations

import sys

from . import diagnose

CASES = [
    ("DMD 能不能外推到 25 秒之后？", "dmd_no_extrapolation"),
    ("p 的 R² 都 0.99 了，为什么 RMSE 还这么大？", "metric_ab"),
    ("u_x 为什么卡在 0.83？", "hankel_pitfalls"),
    ("首帧 p 幅度 2015，要不要剔除？", "trim_rules"),
    ("探针 0 和 202 为什么特殊？", "cusp_probes"),
    ("要预测新工况，用物理模型还是 DMD？", "method_choice"),
    ("只做 POD 不加 Hankel 行不行？", "hankel_necessity"),
    ("pressure 的单位是什么？", "pressure_unit"),
    ("主表和旧方法表有什么区别？", "data_sources"),
    ("换一条鱼还能用这个 DMD 吗？", "scope_limits"),
    ("毛刺都集中在哪里？", "spikes"),
    ("25 段里 p 最差是多少？", "segment_windows"),
    ("POD 95% 能量需要几阶？", "pod_energy"),
    ("u_y 的主导频率是多少？", "frequency"),
    ("物理模型和 DMD 差多少？", "physical_run_gap"),
]


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    rows = []
    ok = 0
    for q, expected in CASES:
        r = diagnose.answer(q)
        got = r.get("matched") if r.get("status") == "ok" else None
        hit = got == expected
        ok += int(hit)
        rows.append((q, expected, got, hit))

    width = max(len(q) for q, _, _, _ in rows)
    for q, expected, got, hit in rows:
        mark = "OK " if hit else "MISS"
        print(f"{mark}  {q:<{width}}  expected={expected:<22} got={got}")

    print(f"\n{ok}/{len(rows)} = {ok/len(rows):.1%}")
    return 0 if ok == len(rows) else 1


if __name__ == "__main__":
    sys.exit(main())

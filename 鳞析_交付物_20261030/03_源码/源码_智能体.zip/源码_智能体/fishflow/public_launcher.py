"""Own an authenticated server before exposing a public tunnel."""
from __future__ import annotations

import argparse
import base64
import os
from pathlib import Path
import secrets
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parents[1]


def access_code(root: Path = ROOT) -> str:
    value = os.environ.get("FISHFLOW_ACCESS_CODE", "")
    path = root / "secrets" / "access_code.txt"
    if not value and path.exists():
        if path.stat().st_size > 256:
            raise ValueError("Invalid access-code file")
        value = path.read_text(encoding="utf-8").strip()
    if not value:
        value = secrets.token_urlsafe(24)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(value, encoding="utf-8")
    if not 16 <= len(value) <= 128 or not value.isascii() or any(c.isspace() for c in value):
        raise ValueError("Use a new independent random access code (16-128 ASCII characters); replace the old local access-code file yourself")
    return value


def port_in_use(port: int) -> bool:
    with socket.socket() as sock:
        sock.settimeout(0.5)
        return sock.connect_ex(("127.0.0.1", port)) == 0


def verify_auth(port: int, code: str) -> bool:
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    url = f"http://127.0.0.1:{port}/"
    try:
        opener.open(url, timeout=1).close()
        return False
    except urllib.error.HTTPError as exc:
        if exc.code != 401:
            return False
    header = base64.b64encode(f"fish:{code}".encode()).decode("ascii")
    request = urllib.request.Request(url, headers={"Authorization": f"Basic {header}"})
    with opener.open(request, timeout=1) as response:
        return response.status == 200


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--lan", action="store_true")
    args = parser.parse_args()
    if port_in_use(args.port):
        print("Port is occupied. Stop the old server first; no tunnel was opened.")
        return 1
    try:
        code = access_code()
    except ValueError as exc:
        print(str(exc))
        return 1
    env = os.environ.copy()
    env["FISHFLOW_ACCESS_CODE"] = code
    if not args.lan:
        env.setdefault("FISHFLOW_LLM_URL", "https://open.bigmodel.cn/api/paas/v4/chat/completions")
        env.setdefault("FISHFLOW_LLM_MODEL", "glm-5.3-flash")
    server = subprocess.Popen(
        [sys.executable, "-m", "fishflow.chat_server", "--host",
         "0.0.0.0" if args.lan else "127.0.0.1", "--no-open", "--port", str(args.port)],
        cwd=ROOT, env=env,
        creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
    )
    tunnel = None
    try:
        deadline = time.monotonic() + 20
        ready = False
        while time.monotonic() < deadline and server.poll() is None:
            try:
                if verify_auth(args.port, code):
                    ready = True
                    break
            except (OSError, ValueError):
                pass
            time.sleep(0.25)
        if not ready:
            print("Authenticated server failed to start; no tunnel was opened.")
            return 1
        print("Access code (share privately only):", code)
        print("Keep this window open. Ctrl+C stops this session.")
        if args.lan:
            print(f"LAN mode, port {args.port}. Username: fish; password: access code.")
            return server.wait()
        host_dir = ROOT / ".sshhome" / ".ssh"
        host_dir.mkdir(parents=True, exist_ok=True)
        tunnel = subprocess.Popen([
            "ssh", "-F", "NUL" if os.name == "nt" else "/dev/null",
            "-o", f"UserKnownHostsFile={host_dir / 'known_hosts'}",
            "-o", "StrictHostKeyChecking=accept-new", "-o", "ServerAliveInterval=20",
            "-o", "ExitOnForwardFailure=yes", "-R", f"80:127.0.0.1:{args.port}",
            "nokey@localhost.run",
        ], cwd=ROOT)
        while tunnel.poll() is None:
            if server.poll() is not None:
                print("Server stopped; closing tunnel.")
                return 1
            time.sleep(0.25)
        return tunnel.returncode
    except KeyboardInterrupt:
        return 0
    finally:
        for proc in (tunnel, server):
            if proc is not None and proc.poll() is None:
                proc.terminate()
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait()


if __name__ == "__main__":
    raise SystemExit(main())

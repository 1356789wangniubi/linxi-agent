"""Fish lateral-line knowledge + a small simulation demo.

The knowledge is a curated FAQ for the chat persona.  The simulator is a 2-D
oscillating dipole and a 16-sensor array; it is deliberately simple and
transparent, not a validated CFD model.
"""

from __future__ import annotations

import time
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib import font_manager

for _name in ("Microsoft YaHei", "SimHei", "DejaVu Sans"):
    try:
        font_manager.findfont(_name, fallback_to_default=False)
        plt.rcParams["font.sans-serif"] = [_name]
        break
    except Exception:
        continue
plt.rcParams["axes.unicode_minus"] = False

from . import config, store

OUT = config.OUTPUTS

TOPICS = [
    {
        "id": "what",
        "title": "鱼类侧线是什么",
        "keywords": ["侧线是什么", "什么是侧线", "lateral line", "侧线系统", "神经丘", "neuromast"],
        "answer": (
            "鱼类侧线是覆盖在头部和体表的机械感觉系统，用来感知水流、压力梯度和附近物体造成的扰动。"
            "它的基本感受单元是神经丘（neuromast）：毛细胞被胶质的顶帽（cupula）包着，水流让顶帽偏转，"
            "毛细胞就把机械位移转成神经脉冲。侧线让鱼能在浑浊、黑暗环境里完成趋流、避障、捕食、集群和躲避捕食者。"
        ),
        "refs": ["Zhai, Zheng & Xie, Fish lateral line inspired perception and flow-aided control: a review (2020)"],
    },
    {
        "id": "types",
        "title": "表浅神经丘 vs 管道神经丘",
        "keywords": ["表浅", "管道", "superficial", "canal", "两种神经丘", "区别"],
        "answer": (
            "表浅神经丘直接暴露在皮肤表面，主要响应局部流速，高频敏感，但容易受自身摆动和背景噪声干扰。"
            "管道神经丘位于皮下管道里，管道通过小孔与外界相通，感受的是相邻孔之间的压力差；"
            "管道相当于一个带通滤波器，能压低低频自噪声、扩展有效感受范围。"
            "仿真时：表浅用“局部速度 → 顶帽偏转”建模；管道用“孔口压力差 → 管道/顶帽动力学”建模。"
        ),
        "refs": ["Zhai et al. 2020 review, §2 (morphology and sensing principles)"],
    },
    {
        "id": "sense",
        "title": "侧线能感知什么",
        "keywords": ["感知什么", "能测什么", "测流速", "测压力", "感知涡", "涡", "尾流", "偶极子", "障碍物", "同类"],
        "answer": (
            "侧线主要提供局部流场信息：流速大小/方向、压力/压力梯度、涡量和尾流结构。"
            "由此可以推断：上游障碍物或捕食者、振动偶极子式的猎物、同伴的位置与游动相位、"
            "以及自己相对水流的运动。它不是“远程声呐”，感受范围随流场衰减，通常在几个体长以内最有效。"
        ),
        "refs": ["Zhai et al. 2020 review, §4 (hydrodynamic sensing and vortex detection)"],
    },
    {
        "id": "pipeline",
        "title": "侧线仿真怎么做",
        "keywords": ["怎么仿真", "仿真流程", "怎么做", "步骤", "建模", "侧线仿真"],
        "answer": (
            "一个最小闭环通常分 6 步：\n"
            "1. **流场**：解析模型（偶极子/点涡）或 CFD（IB、LBM、有限体积）；\n"
            "2. **鱼体/传感器几何**：体表或管道孔的位置、朝向、数量；\n"
            "3. **传感模型**：表浅=局部速度→顶帽；管道=孔口压差→管道动力学；\n"
            "4. **信号**：加噪声、带宽、饱和、自身摆动干扰；\n"
            "5. **解码**：源定位、涡检测、趋流/避障控制；\n"
            "6. **验证**：和生物实验或机器鱼实验对照。\n"
            "只做“画流场”不算侧线仿真，关键在传感器模型和后面的解码。"
        ),
        "refs": ["Zhai et al. 2020 review, §3–5", "Kármán gaiting framework (2026): lateral-line array + CPG + RL"],
    },
    {
        "id": "sensor_model",
        "title": "传感器模型怎么建",
        "keywords": ["传感器模型", "传感模型", "顶帽", "cupula", "噪声", "带宽", "饱和", "延迟"],
        "answer": (
            "表浅神经丘可以近似成“局部法向速度 → 一阶/二阶高通滤波 → 非线性饱和”；"
            "管道神经丘是“孔口压差 → 二阶带通（管道-顶帽）”。"
            "实际仿真至少加三样：传感器噪声、带宽限制、自身摆动产生的大信号。"
            "如果忽略自身信号，解码器在真实鱼上会被自己的尾拍淹没——这是最常见的坑。"
        ),
        "refs": ["Zhai et al. 2020 review, sensor principles", "常见人工侧线实现：压力/流速传感器阵列 + 带通"],
    },
    {
        "id": "array",
        "title": "侧线阵列怎么布置",
        "keywords": ["阵列", "布置", "传感器", "几个传感器", "间距", "位置", "优化", "稀疏"],
        "answer": (
            "先看你要感知的波长：空间采样至少每波长 2 个点（Nyquist），工程上常用 8–32 个传感器。"
            "沿体侧、头部、或管道孔位布置；不要全放在波节上。"
            "如果目标固定（如源定位），可以用 Fisher 信息/CRLB 或数据驱动方法优化位置；"
            "如果目标变化，优先保证覆盖和冗余，而不是追求单任务最优。"
        ),
        "refs": ["Zhai et al. 2020 review, sensor placement discussion", "源定位/稀疏传感的一般结论"],
    },
    {
        "id": "dipole",
        "title": "偶极子源与源定位",
        "keywords": ["偶极子", "dipole", "源定位", "定位", "振动源", "猎物"],
        "answer": (
            "振动偶极子是侧线研究里最常用的“猎物/振动源”模型。它的势场按 1/r 衰减，速度按 1/r² 衰减，"
            "所以传感器信号随距离快速变小。定位通常用：多传感器幅值比/相位差、波束形成、最大似然，"
            "或直接用 CNN/RNN 回归。难点是源方向、边界反射、以及鱼自身运动带来的多普勒/相位变化。"
        ),
        "refs": ["Zhai et al. 2020 review, dipole source detection", "人工侧线源定位文献"],
    },
    {
        "id": "wake",
        "title": "涡/尾流感知",
        "keywords": ["涡", "尾流", "vortex", "wake", "卡门", "karman", "能量", "省力"],
        "answer": (
            "侧线对非定常涡很敏感：涡核经过传感器时会产生特征性的压力/速度波形。"
            "鱼可以利用上游鱼或圆柱的尾流省力（Kármán gaiting），关键是找到涡街里的合适站位和相位。"
            "仿真上需要非定常流场（CFD 或涡方法），只靠定常势流看不到涡的输运。"
        ),
        "refs": ["Kármán gaiting framework (2026)", "Zhai et al. 2020 review, vortex detection"],
    },
    {
        "id": "self",
        "title": "自身摆动干扰",
        "keywords": ["自身", "自运动", "干扰", "efference", "自己摆动", "本体"],
        "answer": (
            "鱼自己摆动产生的压力/速度场通常比外部小信号大一个量级以上。"
            "常见处理：① 用 efference copy（把自身运动参数送进模型）做前馈抵消；"
            "② 用高通/带通滤波去掉低频自噪声；③ 训练时把自身运动作为条件输入；"
            "④ 用差分/参考传感器。完全不处理，解码器在真实鱼上基本不可用。"
        ),
        "refs": ["侧线感知与自运动分离的一般结论", "Zhai et al. 2020 review, flow-aided control"],
    },
    {
        "id": "ml",
        "title": "机器学习/强化学习怎么用",
        "keywords": ["机器学习", "深度学习", "强化学习", "rl", "cnn", "rnn", "神经网络", "学习"],
        "answer": (
            "常见三种用法：① 用 CNN/RNN 直接从多传感器时序做源定位/涡检测；"
            "② 用 RL 学“怎么游”来最大化感知信息或省力（active sensing / Kármán gaiting）；"
            "③ 用自监督/域随机化做 sim-to-real。"
            "建议先把传感模型和基线（最大似然/模板匹配）做对，再上学习；否则网络学到的可能是仿真伪影。"
        ),
        "refs": ["Kármán gaiting framework (2026): STP-TD3 + CPG", "Zhai et al. 2020 review, future work"],
    },
    {
        "id": "software",
        "title": "用什么软件/工具",
        "keywords": ["软件", "工具", "用什么软件", "用什么工具", "openfoam", "fluent", "ibamr", "lbm", "python", "matlab", "cfd"],
        "answer": (
            "解析/快速原型：Python + NumPy（偶极子、点涡、阵列信号）；"
            "高保真：OpenFOAM、IBAMR、Fluent、XFlow、LBM（如 Palabos）；"
            "刚体/流固耦合：MuJoCo + 简化水动力，或 IB + 刚体求解器；"
            "传感与解码：Python（scikit-learn/PyTorch）。"
            "如果只是验证算法，先用解析模型 + 真实传感器噪声，比一上来做 3D CFD 更划算。"
        ),
        "refs": ["工程实践建议；具体软件选择取决于保真度和算力"],
    },
    {
        "id": "probes",
        "title": "404 探针能不能当侧线",
        "keywords": ["404", "探针", "我的数据", "表面压力", "能当侧线", "降采样", "阵列"],
        "answer": (
            "可以，但要降采样和加传感模型：404 个表面探针相当于一个“密集压力阵列”，"
            "可以按体侧/头部选 8–32 个点，当做表浅神经丘的代理；"
            "管道神经丘则要用相邻孔的压力差。注意你现有数据是二维、无黏势流，"
            "没有边界层和涡，所以它适合验证“阵列+解码”的流程，不适合声称真实侧线精度。"
        ),
        "refs": ["本项目数据说明：二维无黏、404 探针、dt=0.0005"],
    },
    {
        "id": "behavior",
        "title": "侧线在行为中的作用",
        "keywords": ["趋流", "集群", "避障", "捕食", "行为", "洄游", "黑暗", "blind"],
        "answer": (
            "侧线最典型的四个作用：① 趋流（rheotaxis）——感知水流方向并保持朝向；"
            "② 集群（schooling）——感知同伴尾流和相对位置；③ 避障——识别上游物体/壁面造成的流场畸变；"
            "④ 捕食/避敌——探测振动偶极子式的猎物或捕食者。"
            "它在黑暗、浑浊环境里尤其重要；盲鱼（blind cavefish）就是靠侧线完成这些任务的。"
        ),
        "refs": ["Zhai et al. 2020 review, behavior sections", "blind cavefish lateral-line studies"],
    },
    {
        "id": "robot",
        "title": "人工侧线/机器鱼怎么实现",
        "keywords": ["机器鱼侧线", "机器鱼", "人工侧线", "传感器实现", "mems", "实验平台", "机器人"],
        "answer": (
            "人工侧线通常用压力传感器、热膜/热线流速计、或 MEMS 流量传感器做成阵列，"
            "贴在机器鱼体侧或管道孔位；后端做滤波、特征提取和源定位。"
            "难点不在单个传感器，而在：封装/防水、阵列一致性、自身推进噪声、"
            "以及 sim-to-real 的标定。建议先做“静态源定位”验证阵列，再做“游动中感知”。"
        ),
        "refs": ["Zhai et al. 2020 review, artificial lateral line systems", "机器鱼侧线实验平台文献"],
    },
    {
        "id": "vs",
        "title": "侧线 vs 视觉",
        "keywords": ["视觉", "眼睛", "区别", "其他感官", "声呐", "谁更重要"],
        "answer": (
            "视觉是远场、高分辨率、依赖光照；侧线是近场、机械感觉、在黑暗/浑浊里仍可用，"
            "而且对“流”而不是“光”敏感。两者互补：视觉负责“是什么/在哪”，"
            "侧线负责“水流怎么变/有没有东西扰动”。仿真时不要用视觉指标去评侧线，"
            "侧线的优势在近场、动态、无光条件。"
        ),
        "refs": ["Zhai et al. 2020 review, multimodal sensing discussion"],
    },
    {
        "id": "eval",
        "title": "怎么评估侧线仿真",
        "keywords": ["评估侧线仿真", "评估", "指标", "怎么证明", "定位误差", "检测率", "鲁棒性"],
        "answer": (
            "分三层：① 传感层——仿真信号和实验信号的波形/频谱/相关；"
            "② 解码层——定位误差、检测率/虚警率、延迟；"
            "③ 任务层——趋流/避障/跟随的成功率、能耗。"
            "还要做噪声、稀疏、传感器故障、自身运动变化的鲁棒性测试；只报一个“准确率”不够。"
        ),
        "refs": ["侧线感知/机器鱼实验的一般评估实践"],
    },
    {
        "id": "pitfalls",
        "title": "最常见的坑",
        "keywords": ["坑", "注意", "误区", "为什么效果差", "失败"],
        "answer": (
            "五个高频坑：① 用理想传感器，不加噪声/带宽；② 忽略自身摆动；"
            "③ 只做定常流，没有涡；④ 传感器全放在波节/太少；"
            "⑤ 拿仿真精度当真实侧线精度。"
            "先做“传感层对照”，再做“解码层”，最后才谈控制。"
        ),
        "refs": ["Zhai et al. 2020 review, open problems", "本项目 DMD/物理模型的踩坑记录"],
    },
]


def _score(q: str, entry: dict) -> float:
    ql = q.lower().replace(" ", "")
    s = 0.0
    for kw in entry["keywords"]:
        k = kw.lower().replace(" ", "")
        if k and k in ql:
            s += 1.0 + 0.12 * len(k)
    return s


def answer(question: str) -> dict:
    scored = sorted(((_score(question, e), e) for e in TOPICS), key=lambda x: x[0], reverse=True)
    best_score, best = scored[0]
    if best_score <= 0:
        if "侧线" in question:
            best = TOPICS[0]
        else:
            return {"status": "miss"}
    refs = "\n".join(f"- {r}" for r in best["refs"])
    reply = f"**{best['title']}**\n\n{best['answer']}\n\n**参考**\n{refs}"
    return {"status": "ok", "id": best["id"], "title": best["title"],
            "reply": reply, "sources": best["refs"]}


def _dipole_field(x, y, xs, ys, m, mdot, rho=1.0):
    dx, dy = x - xs, y - ys
    r2 = dx * dx + dy * dy
    r = np.sqrt(r2) + 1e-12
    ux = (m / (2 * np.pi)) * (1 / r2 - 2 * dx * dx / (r2 * r2))
    uy = (m / (2 * np.pi)) * (-2 * dx * dy / (r2 * r2))
    dphi_dt = (mdot / (2 * np.pi)) * dx / r2
    p = -rho * dphi_dt - 0.5 * rho * (ux * ux + uy * uy)
    return ux, uy, p


def simulate_dipole(out: str | Path = "outputs/ll_dipole.png") -> dict:
    """Oscillating 2-D dipole + 16-sensor lateral-line array."""
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    xs, ys = 0.55, 0.22
    m0, f = 1.0, 2.0
    t = np.linspace(0, 0.5, 401)
    m = m0 * np.sin(2 * np.pi * f * t)
    mdot = m0 * 2 * np.pi * f * np.cos(2 * np.pi * f * t)

    sensors = np.linspace(0.0, 1.0, 16)
    sx = sensors
    sy = np.zeros_like(sensors)

    # time series at sensors
    signals = np.zeros((len(t), len(sensors)))
    for k, (tt, mm, md) in enumerate(zip(t, m, mdot)):
        _, _, p = _dipole_field(sx, sy, xs, ys, mm, md)
        signals[k] = p

    # field snapshot at a phase with strong signal
    tt = t[np.argmax(np.abs(signals).max(axis=1))]
    mm = np.sin(2 * np.pi * f * tt)
    md = m0 * 2 * np.pi * f * np.cos(2 * np.pi * f * tt)
    gx, gy = np.meshgrid(np.linspace(-0.1, 1.1, 180), np.linspace(-0.25, 0.45, 140))
    ux, uy, p = _dipole_field(gx, gy, xs, ys, mm, md)
    p = np.where(np.hypot(gx - xs, gy - ys) < 0.12, np.nan, p)

    fig, axes = plt.subplots(1, 2, figsize=(11, 4.2), gridspec_kw={"width_ratios": [1.2, 1]})
    ax = axes[0]
    vmax = np.nanpercentile(np.abs(p), 95)
    im = ax.pcolormesh(gx, gy, p, cmap="RdBu_r", vmin=-vmax, vmax=vmax, shading="auto")
    ax.quiver(gx[::10, ::10], gy[::10, ::10], ux[::10, ::10], uy[::10, ::10],
              color="k", alpha=0.28, scale=22, width=0.002)
    ax.plot(sx, sy, "o-", color="#0f172a", ms=4, lw=0.8, label="16 传感器")
    ax.plot([xs], [ys], "*", color="#f59e0b", ms=16, label="偶极子源")
    ax.set_aspect("equal")
    ax.set_xlim(-0.1, 1.1); ax.set_ylim(-0.25, 0.45)
    ax.set_xlabel("x [m]"); ax.set_ylabel("y [m]")
    ax.set_title(f"振动偶极子压力场（t={tt:.3f}s）")
    ax.legend(fontsize=7, loc="upper right")
    fig.colorbar(im, ax=ax, fraction=0.035, pad=0.02, label="归一化压强")

    ax = axes[1]
    for idx, color in [(0, "#94a3b8"), (5, "#2563eb"), (10, "#dc2626"), (15, "#16a34a")]:
        ax.plot(t, signals[:, idx], lw=1.1, color=color,
                label=f"sensor {idx} (x={sensors[idx]:.2f})")
    ax.set_xlabel("t [s]"); ax.set_ylabel("pressure (norm.)")
    ax.set_title("阵列上的侧线信号")
    ax.grid(alpha=0.25); ax.legend(fontsize=7)
    fig.tight_layout()
    fig.savefig(out, dpi=170)
    plt.close(fig)
    return {"figure": str(out), "sensors": len(sensors), "freq": f,
            "peak": float(np.nanmax(np.abs(signals)))}


def from_probes(out: str | Path = "outputs/ll_from_probes.png") -> dict:
    """Downsample the 404-probe pressure table into a 16-point array."""
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    probes = np.unique(np.linspace(0, 201, 16).astype(int))
    t0, t1 = 0.1, 0.6
    rows = []
    times = None
    for p in probes:
        d = store.query(int(p), t0, t1, "p")
        if times is None:
            times = np.asarray(d["time"])
        rows.append(np.asarray(d["value"]))
    mat = np.stack(rows, axis=1)
    fig, axes = plt.subplots(1, 2, figsize=(11, 3.8), gridspec_kw={"width_ratios": [1.2, 1]})
    ax = axes[0]
    im = ax.pcolormesh(times, probes, mat.T, cmap="RdBu_r", shading="auto")
    ax.set_xlabel("t [s]"); ax.set_ylabel("probe id")
    ax.set_title("404 探针降采样为 16 点阵列（上表面）")
    fig.colorbar(im, ax=ax, fraction=0.035, pad=0.02, label="p/(ρU²)")
    ax = axes[1]
    for k, color in [(0, "#94a3b8"), (5, "#2563eb"), (10, "#dc2626"), (15, "#16a34a")]:
        ax.plot(times, mat[:, k], lw=1.0, color=color, label=f"probe {probes[k]}")
    ax.set_xlabel("t [s]"); ax.set_ylabel("p/(ρU²)")
    ax.set_title("4 个代表点的信号")
    ax.grid(alpha=0.25); ax.legend(fontsize=7)
    fig.tight_layout()
    fig.savefig(out, dpi=170)
    plt.close(fig)
    return {"figure": str(out), "probes": probes.tolist()}

"""Check the configured LLM endpoint without printing the key."""

from __future__ import annotations

import json
import os
import sys
import urllib.request

from .secret_store import load


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    url = os.environ.get("FISHFLOW_LLM_URL") or "https://open.bigmodel.cn/api/paas/v4/chat/completions"
    model = os.environ.get("FISHFLOW_LLM_MODEL") or "glm-5.3-flash"
    key = os.environ.get("FISHFLOW_LLM_KEY") or load("zhipu")
    if not key:
        print("no key: run python -m fishflow.secret_setup")
        return 1
    body = json.dumps({
        "model": model,
        "messages": [{"role": "user", "content": "只回复 OK"}],
        "temperature": 0,
        "max_tokens": 8,
    }).encode("utf-8")
    req = urllib.request.Request(
        url, data=body,
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {key}"},
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            data = json.loads(r.read().decode("utf-8"))
        text = data["choices"][0]["message"]["content"]
        print(f"OK  model={model}  reply={text[:80]!r}")
        return 0
    except Exception as exc:
        print(f"FAIL {type(exc).__name__}: {exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

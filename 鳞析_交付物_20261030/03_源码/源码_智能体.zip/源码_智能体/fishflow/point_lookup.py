"""Coordinate -> pressure/velocity lookup from the 404-probe index."""

from __future__ import annotations

import hashlib

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from . import config, store

for _name in ("Microsoft YaHei", "SimHei", "DejaVu Sans"):
    try:
        from matplotlib import font_manager
        font_manager.findfont(_name, fallback_to_default=False)
        plt.rcParams["font.sans-serif"] = [_name]
        break
    except Exception:
        continue
plt.rcParams["axes.unicode_minus"] = False


def lookup(x: float, y: float, t: float = 0.2, index_dir=None) -> dict:
    fr = store.frame_at(float(t), index_dir=index_dir)
    d = np.hypot(fr["x"] - float(x), fr["y"] - float(y))
    order = np.argsort(d)[:3]
    w = 1.0 / (d[order] + 1e-9)
    w = w / w.sum()
    p = float(np.sum(w * fr["p"][order]))
    ux = float(np.sum(w * fr["ux"][order]))
    uy = float(np.sum(w * fr["uy"][order]))
    nearest = int(fr["probe"][order[0]])

    key = hashlib.md5(f"{x:.4f},{y:.4f},{t:.4f}".encode()).hexdigest()[:10]
    out = config.OUTPUTS / f"point_{key}.png"
    fig, ax = plt.subplots(figsize=(8.2, 3.0))
    sc = ax.scatter(fr["x"], fr["y"], c=fr["p"], cmap="RdBu_r", s=12)
    ax.plot([x], [y], "o", ms=10, mfc="none", mec="#16a34a", mew=2, label="你的点")
    ax.plot([fr["x"][order[0]]], [fr["y"][order[0]]], "x", ms=8, color="k", label="最近探针")
    ax.set_aspect(4.0)
    ax.set_title(f"x={x:.3f}, y={y:.3f}, t={fr['time']:.3f}s：p={p:.3f}")
    ax.set_xlabel("x [m]"); ax.set_ylabel("y [m]")
    ax.legend(fontsize=7, loc="upper right")
    fig.colorbar(sc, ax=ax, fraction=0.035, pad=0.02, label="p")
    fig.tight_layout(); fig.savefig(out, dpi=150); plt.close(fig)

    return {
        "x": float(x), "y": float(y), "t": float(fr["time"]),
        "p": p, "ux": ux, "uy": uy,
        "nearest_probe": nearest,
        "nearest_distance": float(d[order[0]]),
        "neighbors": [int(fr["probe"][i]) for i in order],
        "figure": out.name,
    }

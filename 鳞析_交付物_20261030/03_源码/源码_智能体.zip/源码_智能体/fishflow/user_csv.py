"""Build a user CSV from pasted key-value data or from a reference sample."""

from __future__ import annotations

import io
import re
import uuid
from pathlib import Path

import numpy as np
import pandas as pd

from . import config, store

OUT = config.OUTPUTS
ALIASES = {
    "t": "time", "time": "time", "时间": "time", "时刻": "time",
    "probe": "probe", "probe_id": "probe", "探针": "probe", "探针号": "probe",
    "p": "p", "pressure": "p", "压强": "p", "压力": "p",
    "ux": "ux", "u_x": "ux", "x速度": "ux", "x方向速度": "ux", "vx": "ux",
    "uy": "uy", "u_y": "uy", "y速度": "uy", "y方向速度": "uy", "vy": "uy",
    "x": "x", "y": "y", "坐标x": "x", "坐标y": "y",
}


def _clean(text: str) -> str:
    return (text.replace("，", ",").replace("；", ";")
                .replace("：", ":").replace("＝", "=")
                .replace("（", "(").replace("）", ")"))


def _norm_cols(df: pd.DataFrame) -> pd.DataFrame:
    m = {}
    for c in df.columns:
        k = str(c).strip().lower().replace(" ", "")
        m[c] = ALIASES.get(k, k)
    return df.rename(columns=m)


def parse_to_csv(text: str) -> dict:
    text = _clean(text or "").strip()
    if not text:
        raise ValueError("没有收到数据")
    # If it already looks like a CSV with a header, use it.
    first = text.splitlines()[0].lower()
    if "time" in first and ("," in first or "\t" in first):
        df = pd.read_csv(io.StringIO(text))
    else:
        records = []
        for part in re.split(r"[\n;]+", text):
            pairs = re.findall(r"([A-Za-z_\u4e00-\u9fff]+)\s*[=:]\s*(-?\d+(?:\.\d+)?)", part)
            if not pairs:
                continue
            rec = {}
            for k, v in pairs:
                kk = ALIASES.get(k.strip().lower(), k.strip().lower())
                rec[kk] = float(v)
            if "time" in rec:
                records.append(rec)
        if not records:
            raise ValueError(
                "没解析出数据。请用 key=value，例如：\n"
                "t=0.2, probe=17, p=-0.03, ux=0.45, uy=0.18\n"
                "多行就每行一组；也可以直接粘贴带表头的 CSV。"
            )
        df = pd.DataFrame(records)

    df = _norm_cols(df)
    if "time" not in df.columns:
        raise ValueError("缺少 time/时间 列")
    if not ({"probe"} <= set(df.columns) or {"x", "y"} <= set(df.columns)):
        raise ValueError("需要 probe，或者 x 和 y")
    if not ({"p", "ux", "uy"} & set(df.columns)):
        raise ValueError("至少需要 p、ux、uy 中的一个")
    for c in ("time", "probe", "x", "y", "p", "ux", "uy"):
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df[np.isfinite(df["time"])]
    if df.empty:
        raise ValueError("time 没有有效数值")

    csv_text = df.to_csv(index=False)
    name = "user_data_" + uuid.uuid4().hex[:8] + ".csv"
    (OUT / name).write_text(csv_text, encoding="utf-8")
    return {"csv": csv_text, "file": name, "rows": int(len(df)),
            "columns": list(df.columns)}


def sample_from_reference(probes=(17, 100, 200)) -> dict:
    rows = []
    for t in (0.2, 0.21, 0.22):
        fr = store.frame_at(t)
        for p in probes:
            i = int(p)
            rows.append({
                "time": round(float(fr["time"]), 6),
                "probe": int(p),
                "p": round(float(fr["p"][i]), 6),
                "ux": round(float(fr["ux"][i]), 6),
                "uy": round(float(fr["uy"][i]), 6),
            })
    df = pd.DataFrame(rows)
    csv_text = df.to_csv(index=False)
    name = "user_data_sample_" + uuid.uuid4().hex[:6] + ".csv"
    (OUT / name).write_text(csv_text, encoding="utf-8")
    return {"csv": csv_text, "file": name, "rows": int(len(df)),
            "columns": list(df.columns), "synthetic": True}

"""Windows DPAPI-backed local secret storage.

The Zhipu API key is never written to source, .bat files, or docs.  It is stored
as a DPAPI blob bound to the current Windows user; only that user can decrypt it.

Fallback: if `FISHFLOW_LLM_KEY` or `ZHIPU_API_KEY` is set, that wins.
"""

from __future__ import annotations

import base64
import ctypes
import os
from ctypes import wintypes
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SECRETS = ROOT / "secrets"
CRYPTPROTECT_UI_FORBIDDEN = 0x1


class _DATA_BLOB(ctypes.Structure):
    _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_ubyte))]


def _blob(data: bytes):
    buf = (ctypes.c_ubyte * len(data)).from_buffer_copy(data)
    return _DATA_BLOB(len(data), buf), buf


def _protect(data: bytes) -> bytes:
    if os.name != "nt":
        raise RuntimeError("DPAPI is only available on Windows")
    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    in_blob, keep = _blob(data)
    out_blob = _DATA_BLOB()
    ok = crypt32.CryptProtectData(
        ctypes.byref(in_blob), None, None, None, None,
        CRYPTPROTECT_UI_FORBIDDEN, ctypes.byref(out_blob),
    )
    if not ok:
        raise OSError(ctypes.get_last_error(), "CryptProtectData failed")
    try:
        return ctypes.string_at(out_blob.pbData, out_blob.cbData)
    finally:
        kernel32.LocalFree(out_blob.pbData)


def _unprotect(data: bytes) -> bytes:
    if os.name != "nt":
        raise RuntimeError("DPAPI is only available on Windows")
    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    in_blob, keep = _blob(data)
    out_blob = _DATA_BLOB()
    ok = crypt32.CryptUnprotectData(
        ctypes.byref(in_blob), None, None, None, None,
        CRYPTPROTECT_UI_FORBIDDEN, ctypes.byref(out_blob),
    )
    if not ok:
        raise OSError(ctypes.get_last_error(), "CryptUnprotectData failed")
    try:
        return ctypes.string_at(out_blob.pbData, out_blob.cbData)
    finally:
        kernel32.LocalFree(out_blob.pbData)


def save(name: str, value: str) -> Path:
    SECRETS.mkdir(exist_ok=True)
    path = SECRETS / f"{name}.key"
    blob = _protect(value.encode("utf-8"))
    path.write_text(base64.b64encode(blob).decode("ascii"), encoding="ascii")
    try:
        ctypes.windll.kernel32.SetFileAttributesW(str(path), 0x2)  # hidden
    except Exception:
        pass
    return path


def load(name: str = "zhipu") -> str | None:
    for env in ("FISHFLOW_LLM_KEY", "ZHIPU_API_KEY"):
        v = os.environ.get(env)
        if v:
            return v
    path = SECRETS / f"{name}.key"
    if not path.exists():
        return None
    try:
        blob = base64.b64decode(path.read_text(encoding="ascii"))
        return _unprotect(blob).decode("utf-8")
    except Exception:
        return None


def has(name: str = "zhipu") -> bool:
    return load(name) is not None

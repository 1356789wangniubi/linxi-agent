"""Three-minute demo transcript for the guard agent.

Run:  python -m fishflow.demo
It prints the three golden questions, the guarded answers, and then writes the
evidence report and figures under outputs/.
"""

from __future__ import annotations

import argparse
import time
import webbrowser
from pathlib import Path

from . import config, diagnose, metrics, provenance, report, store


QUESTIONS = [
    "DMD 能不能外推到 25 秒之后？",
    "p 的 R² 都 0.99 了，为什么还说压强不准？",
    "u_x 为什么卡在 0.83？",
]


def main() -> int:
    import sys
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser()
    ap.add_argument("--open", action="store_true", help="open the HTML report in a browser")
    args = ap.parse_args()
    config.ensure_dirs()
    print("=" * 72)
    print("  鳞析 · 仿生鱼流场方法学护栏 Agent")
    print("  原则：不联网、不编数、不让你用错口径")
    print("=" * 72)

    man = store.manifest()
    print(f"\n索引：{man['n_frames']:,} 帧 × {man['n_probes']} 探针 = {man['n_rows']:,} 行")
    print(f"时间：{man['time_start']}–{man['time_end']} s，dt={man['dt']} s")

    t0 = time.time()
    d = store.query(17, 0.1, 0.2, "p")
    print(f"\n查询探针 17 / 0.1–0.2 s：{d['n']} 个点，{(time.time()-t0)*1000:.1f} ms")

    for i, q in enumerate(QUESTIONS, 1):
        print("\n" + "-" * 72)
        print(f"Q{i}｜{q}")
        r = diagnose.answer(q)
        if r["status"] != "ok":
            print(r.get("message"))
            continue
        print(f"\nA｜{r['title']}（confidence {r['confidence']:.2f}）")
        print(r["answer"])
        print("\n依据：")
        for e in r["evidence"]:
            print("  -", e)
        print("\n护栏：", r["guardrail"])
        provenance.append(r["title"], r["evidence"], "demo", {"question": q})

    print("\n" + "-" * 72)
    print("闭环｜检查 3 Hz 工况是否可外推（自动 3 步：定位→对比→判定）")
    from . import research
    rr = research.research(freq=3.0)
    if rr.get("status") == "ok":
        print(f"\n判定：{rr['verdict']}")
        print(rr["conclusion"])
        print(f"记录：{rr['artifacts']['record_md']}")
    else:
        print(rr.get("message", "research skipped"))

    print("\n" + "=" * 72)
    print("生成报告与图 ...")
    out = report.build()
    print(f"  HTML : {out['html']}")
    print(f"  MD   : {out['md']}")
    for f in out["figures"]:
        print(f"  FIG  : {f}")
    if args.open:
        uri = Path(out["html"]).resolve().as_uri()
        print(f"  打开  : {uri}")
        webbrowser.open(uri)

    mean = metrics.mean_scores()
    print("\n权威指标（全窗口平均）：")
    for k, v in mean.items():
        print(f"  {k}: A={v['A']:.4f}  B={v['B']:.4f}")
    print("\n完成。所有数字来自 交付包/06_指标 与 data/index；未读取老师原始数据。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

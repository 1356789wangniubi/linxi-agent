"""Short GIF of the surface pressure field (demo artifact)."""

from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.animation import FuncAnimation, PillowWriter

from . import store

LABEL = {
    "p": "pressure p/(ρU²)",
    "ux": "u_x [m/s]",
    "uy": "u_y [m/s]",
}


def animate_field(t0: float = 0.1, t1: float = 0.46, fps: int = 12,
                  out: str | Path = "outputs/field_animation.gif",
                  quantity: str = "p", dpi: int = 120) -> Path:
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    times = np.linspace(float(t0), float(t1), int(round((t1 - t0) * fps)) + 1)
    frames = [store.frame_at(float(t)) for t in times]

    vals = np.concatenate([f[quantity] for f in frames])
    vmin, vmax = np.percentile(vals, [2, 98])

    fig, ax = plt.subplots(figsize=(7.2, 3.5))
    f0 = frames[0]
    sc = ax.scatter(f0["x"], f0["y"], c=f0[quantity], cmap="RdBu_r",
                    s=14, vmin=vmin, vmax=vmax)
    ax.set_aspect(4.0)
    ax.set_xlim(1.98, 3.02)
    ax.set_ylim(-0.11, 0.11)
    ax.set_xlabel("x [m]")
    ax.set_ylabel("y [m]")
    title = ax.set_title(f"t = {f0['time']:.3f} s")
    fig.colorbar(sc, ax=ax, fraction=0.035, pad=0.02, label=LABEL.get(quantity, quantity))

    def update(i):
        f = frames[i]
        sc.set_offsets(np.column_stack([f["x"], f["y"]]))
        sc.set_array(f[quantity])
        title.set_text(f"t = {f['time']:.3f} s")
        return sc, title

    ani = FuncAnimation(fig, update, frames=len(frames), blit=False)
    fig.tight_layout()
    ani.save(str(out), writer=PillowWriter(fps=fps), dpi=dpi)
    plt.close(fig)
    return out


if __name__ == "__main__":
    print(animate_field())

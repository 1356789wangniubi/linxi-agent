"""Metric definitions and authoritative comparisons.

Two conventions are deliberately kept separate:
  A: per-frame spatial correlation squared  (shape; scale-invariant)
  B: 1 - SSE/SST over all points             (absolute; scale-sensitive)
Mixing them is the single most common way to get a wrong conclusion here.
"""

from __future__ import annotations

import numpy as np

from . import config

_KEY_MAP = {
    "新方法：POD+Hankel+DMD": "dmd_v2",
    "旧方法：直接 Hankel-DMD": "dmd_old",
}


def authoritative() -> dict:
    raw = config.load_json(config.METRICS_JSON)
    out = {}
    for k, v in raw.items():
        key = _KEY_MAP.get(k, k)
        if isinstance(v, dict) and "p" in v:
            out[key] = v
    return out


def holdout() -> dict:
    return config.load_json(config.HOLDOUT_JSON)


def segments() -> dict:
    return config.load_json(config.SEGMENTS_JSON)


def r2_a(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Per-frame spatial correlation squared, averaged over frames.

    y_true/y_pred: shape (n_frames, n_probes).
    """
    a = np.asarray(y_true, dtype=float)
    b = np.asarray(y_pred, dtype=float)
    if a.ndim == 1:
        a = a[None, :]
        b = b[None, :]
    a = a - a.mean(axis=1, keepdims=True)
    b = b - b.mean(axis=1, keepdims=True)
    num = (a * b).sum(axis=1)
    den = np.sqrt((a * a).sum(axis=1) * (b * b).sum(axis=1)) + 1e-30
    r = num / den
    return float(np.mean(r * r))


def r2_b(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    a = np.asarray(y_true, dtype=float).ravel()
    b = np.asarray(y_pred, dtype=float).ravel()
    sse = float(((a - b) ** 2).sum())
    sst = float(((a - a.mean()) ** 2).sum()) + 1e-30
    return 1.0 - sse / sst


def rmse(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    a = np.asarray(y_true, dtype=float)
    b = np.asarray(y_pred, dtype=float)
    return float(np.sqrt(np.mean((a - b) ** 2)))


def score(y_true: np.ndarray, y_pred: np.ndarray) -> dict:
    return {"A": r2_a(y_true, y_pred), "B": r2_b(y_true, y_pred), "RMSE": rmse(y_true, y_pred)}


def table() -> list[dict]:
    """Flat table of the authoritative whole-window metrics."""
    raw = authoritative()
    rows = []
    for ds, key in (("dmd_v2", "新方法（POD+Hankel+DMD）"), ("dmd_old", "旧方法（直接 Hankel-DMD）")):
        d = raw.get(ds)
        if not d:
            continue
        for q in ("p", "ux", "uy"):
            if q in d:
                rows.append({
                    "dataset": ds,
                    "quantity": q,
                    "A": float(d[q]["metricA_per_frame_corr2"]),
                    "B": float(d[q]["metricB_1_minus_SSE_SST"]),
                    "RMSE": float(d[q]["RMSE"]),
                    "frames": int(d.get("_frames", config.N_FRAMES)),
                })
    return rows


def mean_scores() -> dict:
    raw = authoritative()
    out = {}
    for ds in ("dmd_v2", "dmd_old"):
        d = raw.get(ds)
        if not d:
            continue
        out[ds] = {
            "A": float(np.mean([d[q]["metricA_per_frame_corr2"] for q in ("p", "ux", "uy")])),
            "B": float(np.mean([d[q]["metricB_1_minus_SSE_SST"] for q in ("p", "ux", "uy")])),
        }
    return out


def format_pair(dataset: str = "dmd_v2") -> str:
    raw = authoritative().get(dataset, {})
    parts = []
    for q in ("p", "ux", "uy"):
        if q in raw:
            parts.append(f"{q}: A={raw[q]['metricA_per_frame_corr2']:.4f} / "
                         f"B={raw[q]['metricB_1_minus_SSE_SST']:.4f} / "
                         f"RMSE={raw[q]['RMSE']:.4f}")
    return "; ".join(parts)

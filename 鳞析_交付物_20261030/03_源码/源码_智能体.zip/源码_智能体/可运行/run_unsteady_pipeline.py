"""
run_unsteady_pipeline.py - 完整连续时序运行与数据标准化导出脚本（二维版）

本次改动
--------
1. 几何换成**二维**（见 fish_model.py）：弦长 1.0 m、上下表面各 202 点 = **404 个探针**，
   与老师表格的探针数一致；厚度剖面、体波幅度、频率、相位全部取自老师数据。
2. 时间步长 dt = 0.0010 s，时间从 t = 0 起严格等间隔推进。
3. 探针值取**轮廓顶点**上的值（相邻面元平均），使 x 坐标与老师表格逐点对齐。
4. 新增 `export_probe_table()`：导出与老师表格同格式的 TSV。
5. 新增 `embed_into_html()`：把本次结果回写进离线看板。
"""

import json
import os

import numpy as np
import pandas as pd

from fish_model import UnsteadyFishModel
from source_panel import UnsteadyPanelSolver

# ---- 与老师数据对齐的参数 -------------------------------------------------
DT_DEFAULT = 0.0010          # 时间步长 [s]
T_END_DEFAULT = 1.0          # 仿真总时长 [s]
FREQ_DEFAULT = 2.0           # 鱼体摆动频率 [Hz]（老师数据实测 2.000000 Hz）
U_INF_DEFAULT = 1.0          # 来流 [m/s]
LENGTH_DEFAULT = 1.0         # 弦长 [m]（老师数据实测 1.000 m）
N_SIDE_DEFAULT = 202         # 每面条轮廓点数（共 404 个探针，与老师一致）

# ---- 压强单位约定 --------------------------------------------------------
# 论文的 IBAMR 是无量纲化 CFD（L=1, U=1, rho=1），输出的"pressure"数值上
# 是 p/(ρU²)，即 Pa/1000。老师数据的量级比实测支持这一点：
#     老师 |v| 均值 0.599 m/s -> 动压 ½ρ|v|² = 179 Pa
#     老师 p 幅度后段 0.166   -> ×ρ = 166 Pa   （同量级 ✓）
# 且 ×ρ 后模型/老师的幅值比从 3300 倍降到 2.9 倍，与边界层效应(2.56 倍)一致。
# 注意：换单位**不改变 R²**（R² 对缩放不变），只影响绝对幅值。
PRESSURE_UNIT_DEFAULT = 'kinematic'

# ---- 边界层修正（默认关闭；诊断用）---------------------------------------
# 交付物是**只考虑鱼自身运动**的纯势流解，所以这里默认 None。
# 打开后 u_y 的 R² 从 0.769 提到 0.951（见 不契合原因分析.md），但那是诊断。
# 黏性 -> 无滑移 -> 物面切向速度被压低。实测老师物面切向速度只有势流的 39%，
# 介于无滑移(0.071)与势流(1.070)之间，像探针落在边界层内部。
BL_DEFAULT = None        # None 关闭；'laminar' / 'turbulent'
BL_DEPTH_DEFAULT = 5.0e-4     # 探针离壁距离 [m]
BL_RE_DEFAULT = 1.0e6         # 以弦长为基准的雷诺数
BL_MODEL_DEFAULT = 'turbulent'


def _vertex_values(panel_values):
    """把面元中点上的量平均到轮廓顶点上（顶点 i = 相邻两面元 i-1, i 的平均）。

    老师表格的探针在**几何点**上，而面元法解出的是**面元中点**上的量；
    平均回顶点后 x 坐标才能与老师表格逐点对齐。
    """
    pv = np.asarray(panel_values, dtype=float)
    return 0.5 * (np.roll(pv, 1) + pv)


def _probe_arrays(state, panel_values):
    """按老师表格的探针顺序（0..n-1 上表面 吻->尾，n..2n-1 下表面 吻->尾）
    返回 (x, y, values) 三个长度 2n 的数组。
    """
    n = len(state["x"])
    vv = _vertex_values(panel_values)
    # 闭合轮廓顶点：0..n-1 是下表面 吻->尾；n..2n-2 是上表面 尾->吻
    lower_x, lower_y = state["x"], state["y_lo"]
    lower_v = vv[:n]
    # 上表面探针 0 是吻端（顶点 0，与下表面共用）；探针 k>=1 -> 顶点 2n-1-k
    up_idx = np.array([0] + [2 * n - 1 - k for k in range(1, n)])
    upper_v = vv[up_idx]

    x = np.concatenate([state["x"], lower_x])
    y = np.concatenate([state["y_up"], lower_y])
    v = np.concatenate([upper_v, lower_v])
    return x, y, v


def _probe_normals(state):
    """按探针顺序返回**单位外法向** (nx, ny)。

    面元法向平均到顶点后**必须重新归一化** —— 鼻/尾处相邻面元夹角大，
    直接平均会明显短于 1。二维数据只有 x、y 分量，nz 恒为 0。
    """
    n = len(state["x"])
    pn = np.asarray(state["normals"], dtype=float)
    vn = 0.5 * (np.roll(pn, 1, axis=0) + pn)
    ln = np.linalg.norm(vn, axis=1, keepdims=True)
    vn = vn / np.maximum(ln, 1e-30)
    up_idx = np.array([0] + [2 * n - 1 - k for k in range(1, n)])
    nx = np.concatenate([vn[up_idx, 0], vn[:n, 0]])
    ny = np.concatenate([vn[up_idx, 1], vn[:n, 1]])
    return nx, ny


def export_probe_table(rec, path="probe_table.tsv", n_probe=2 * N_SIDE_DEFAULT,
                       freq=FREQ_DEFAULT, u_inf=U_INF_DEFAULT,
                       length=LENGTH_DEFAULT, dt=DT_DEFAULT, n_side=N_SIDE_DEFAULT):
    """导出与老师表格同格式的 TSV，便于直接逐行对比。

    rec : (nstep*n_probe, 14) 数组，列序同 surface_flow_timeseries.csv
          [time_step, time, point_id, x, y, z, nx, ny, nz, u_x, u_y, u_z, pressure, cp]
    """
    header = ("No of probe\tTime\tX-coord of probe\tY-coord of probe\t"
              "pressure\tX velocity\tY velocity")
    # [pid, time, x, y, pressure, u_x, u_y]
    # **与老师文件逐位对齐**：
    #   x / y 先按 6 位取整再打印 12 位 —— 老师的 x / y 本身就是 6 位精确
    #   （2.001667 而非 2.001666…），这样两张表可以逐字符 diff，Δx 精确为 0。
    #   pressure / velocity 直接打印 12 位，保留全部有效数字。
    #   注意：CSV 里保留完整双精度，不做任何舍入。
    out = np.column_stack([rec[:, 2], rec[:, 1],
                           np.round(rec[:, 3], 6), np.round(rec[:, 4], 6),
                           rec[:, 12], rec[:, 9], rec[:, 10]])
    with open(path, "w", encoding="utf-8") as f:
        f.write(header + "\n")
        for row in out:
            f.write("%d\t%.12f\t%.12f\t%.12f\t%.12f\t%.12f\t%.12f\n"
                    % (int(row[0]), row[1], row[2], row[3], row[4], row[5], row[6]))
    n_step = int(len(out) // n_probe)
    t_first = float(out[0, 1])
    t_last = float(out[-1, 1])
    meta = {
        "file": path,
        "rows": int(rec.shape[0]),
        "columns": header.split("\t"),
        "probes_per_step": int(n_probe),
        "steps": n_step,
        "dt_s": dt,
        "time_first_s": t_first,
        "time_last_s": t_last,
        "row_layout": (
            "每 %d 行 = 同一时刻的 %d 个探针（Time 相同），"
            "第 %d 块起为下一时刻。所以只看开头几行会全是同一个 Time 值 —— "
            "这是正常的，不是时间为 0。" % (n_probe, n_probe, n_probe + 1)
        ),
        "time_column_note": (
            "Time 列共 %d 个不同值：t = %.6f, %.6f, … , %.6f（步长 dt = %g s）。"
            "同一时刻的 %d 行 Time 完全相同。" % (n_step, t_first, t_first + dt, t_last, dt, n_probe)
        ),
        "frequency_hz": freq,
        "u_inf_m_s": u_inf,
        "chord_m": length,
        "pressure_unit": PRESSURE_UNIT_DEFAULT,
        "geometry": "2D (upper 202 + lower 202); thickness/wave fitted from probe_fish2_stream",
        "method": "unsteady 2D source panel + Kutta condition + unsteady Bernoulli",
        "note": "格式与老师表格一致；z 分量、法向量、cp 见 surface_flow_timeseries.csv",
    }
    with open("probe_table_meta.json", "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=4, ensure_ascii=False)

    # 同时写一份纯文本说明，直接回答「Time 看起来全是 0」这个疑问
    readme = f"""probe_table.tsv 说明
{'=' * 60}

列（7 列，与老师表格逐字同格式）：
    No of probe | Time | X-coord of probe | Y-coord of probe | pressure | X velocity | Y velocity

★ Time 列不是「全是 0」—— 是「每个时刻占 {n_probe} 行」

    文件共 {len(out)} 行 = 表头 1 行 + {n_step} 个时刻 × {n_probe} 个探针

    第 1  ~ {n_probe}      行：t = {t_first:.6f} s   （{n_probe} 个探针，Time 相同）
    第 {n_probe + 1} ~ {2 * n_probe}    行：t = {t_first + dt:.6f} s   （{n_probe} 个探针，Time 相同）
    第 {2 * n_probe + 1} ~ {3 * n_probe}    行：t = {t_first + 2 * dt:.6f} s
    …
    最后 {n_probe} 行：t = {t_last:.6f} s

  → 所以只看开头会「一直看到 0.000000000000」，要翻过 {n_probe} 行才出现下一个时间。

时间参数
    dt（时间间隔）   = {dt} s
    起始时刻 t0      = {t_first} s
    终止时刻         = {t_last} s
    时刻总数         = {n_step}
    摆动频率         = {freq} Hz
    一个游泳周期     = {1.0 / freq:g} s = {round((1.0 / freq) / dt)} 个时刻

单位
    pressure / velocity 是 kinematic 单位（ρU²、m/s）
    压强换算成 Pa：× ρU² （ρ = 1000 kg/m³，U = {u_inf} m/s → ×{1000.0 * u_inf ** 2:.0f}）

其他
    探针编号 0..{n_probe - 1}：0..{n_probe // 2 - 1} 上表面（吻→尾），
                              {n_probe // 2}..{n_probe - 1} 下表面（吻→尾）
    x / y 已按 6 位取整以对齐老师表格的网格；完整双精度见 surface_flow_timeseries.csv
"""
    with open("probe_table_说明.txt", "w", encoding="utf-8") as f:
        f.write(readme)
    return path


def surface_force(sub, n_side):
    """从一帧探针表算物面流体力（二维，单位展长）。

        F = -∮ p · n dl

    闭合轮廓顺序：下表面 n..2n-1（吻→尾）+ 上表面 n-1..1（尾→吻）。
    p 为 kinematic 单位（ρU²）、L 为 m 时，返回单位是 ρU²·m。
    """
    s = sub.sort_values("point_id")
    x = s.x.values; y = s.y.values
    nx = s.nx.values; ny = s.ny.values
    p = s.pressure.values
    idx = np.concatenate([np.arange(n_side, 2 * n_side),
                          np.arange(n_side - 1, 0, -1)])
    X = x[idx]; Y = y[idx]; NX = nx[idx]; NY = ny[idx]; P = p[idx]
    X2 = np.roll(X, -1); Y2 = np.roll(Y, -1)
    NX2 = np.roll(NX, -1); NY2 = np.roll(NY, -1); P2 = np.roll(P, -1)
    L = np.hypot(X2 - X, Y2 - Y)
    pm = 0.5 * (P + P2)
    nxm = 0.5 * (NX + NX2); nym = 0.5 * (NY + NY2)
    nn = np.hypot(nxm, nym)
    nn[nn == 0] = 1.0
    fx = -float(np.sum(pm * (nxm / nn) * L))
    fy = -float(np.sum(pm * (nym / nn) * L))
    return fx, fy


def embed_into_html(df, html_path="fish_surface_offline.html", stride=5,
                    u_inf=None, t_end=None, dt=None, freq=None, length=None,
                    pressure_unit=None):
    """把本次仿真结果回写进离线看板的内嵌数据，使界面里看到的就是最新结果。

    stride=5（201 帧）—— 「连续动画」视图需要足够密的帧才流畅：
    dt=0.001 s、f=2 Hz，stride=5 -> 每帧 5 ms -> 一个游泳周期 100 帧。
    精度约定：坐标 6 位（与老师网格一致）、速度 6 位、压强 6 位、cp 6 位。
    这样内嵌数据既够画图，也够「导出老师格式表格」按钮导出可用精度的表。
    """
    import re
    if not os.path.exists(html_path):
        # 兼容整理后的目录结构：只在【明确列出】的少数位置里找同一个看板。
        # 注意：绝不做递归搜索 —— 否则会误命中 _archive 等旧版本备份里的 HTML。
        _here = os.path.dirname(os.path.abspath(__file__))
        _cands = [
            os.path.join(_here, "fish_surface_offline.html"),
            os.path.join(_here, "主界面_流场看板.html"),
            os.path.join(_here, "..", "04_界面", "主界面_流场看板.html"),
        ]
        _found = next((p for p in _cands if os.path.exists(p)), None)
        if _found:
            html_path = _found
        else:
            print(f"[!] 未找到 {html_path}，跳过内嵌数据回写")
            return None
    u_inf = U_INF_DEFAULT if u_inf is None else u_inf
    t_end = T_END_DEFAULT if t_end is None else t_end
    dt = DT_DEFAULT if dt is None else dt
    freq = FREQ_DEFAULT if freq is None else freq
    length = LENGTH_DEFAULT if length is None else length
    pressure_unit = PRESSURE_UNIT_DEFAULT if pressure_unit is None else pressure_unit
    steps = sorted(df["time_step"].unique())
    sel = list(steps[::stride])
    if steps[-1] not in sel:
        sel.append(steps[-1])

    frames = []
    for new_idx, s in enumerate(sel):
        sub = df[df["time_step"] == s]
        t = float(sub["time"].iloc[0])
        pts = [[round(float(r.x), 6), round(float(r.y), 6), 0.0,
                round(float(r.nx), 5), round(float(r.ny), 5), 0.0,
                round(float(r.u_x), 6), round(float(r.u_y), 6), 0.0,
                round(float(r.pressure), 6), round(float(r.cp), 6)]
               for r in sub.itertuples(index=False)]
        frames.append({"step": new_idx, "t": round(t, 4), "pts": pts})

    payload = json.dumps(frames, separators=(", ", ": "))
    with open(html_path, "r", encoding="utf-8") as f:
        html = f.read()
    m = re.search(r"let rawFrames = (\[.*?\]);", html, re.S)
    if not m:
        print(f"[!] {html_path} 里找不到 rawFrames，跳过回写")
        return None
    html = html[:m.start(1)] + payload + html[m.end(1):]

    # 同步更新 caseSummary（原来看板里的 caseSummary 是模板里的固定值，
    # 从来没被更新过，界面会显示 50 步 / 1 Hz / 9.1e6 N 这类陈旧数字）
    fx_list, fy_list = [], []
    n_side = int(df["point_id"].nunique()) // 2
    for s in sel:
        fx, fy = surface_force(df[df["time_step"] == s], n_side)
        fx_list.append(fx)
        fy_list.append(fy)
    fx_arr = np.asarray(fx_list, dtype=float) * float(u_inf) ** 2 * 1000.0  # -> N/m
    fy_arr = np.asarray(fy_list, dtype=float) * float(u_inf) ** 2 * 1000.0
    summary = {
        "simulation_parameters": {
            "t_end": float(t_end),
            "steps": int(len(sel)),
            "steps_full": int(df["time_step"].nunique()),
            "frame_stride": int(stride),
            "frequency_hz": float(freq),
            "u_inf": float(u_inf),
            "fish_length_m": float(length),
            "dt_s": float(dt),
            "pressure_unit": pressure_unit,
        },
        "hydrodynamic_metrics": {
            "mean_thrust_fx_N_per_m": float(fx_arr.mean()),
            "max_lateral_force_fy_N_per_m": float(np.abs(fy_arr).max()),
            "rms_lateral_force_fy_N_per_m": float(np.sqrt((fy_arr ** 2).mean())),
            "force_units_note": f"二维，单位展长；1 ρU²·m = {1000.0 * float(u_inf) ** 2:.0f} N/m",
        },
    }
    ms = re.search(r"let caseSummary = (\{.*?\n\});", html, re.S)
    if ms:
        html = (html[:ms.start(1)]
                + json.dumps(summary, indent=2, ensure_ascii=False)
                + html[ms.end(1):])
        print("[+] 已同步更新 caseSummary（步数 %d / %.1f Hz / 平均 Fx %.1f N/m）"
              % (summary["simulation_parameters"]["steps"],
                 summary["simulation_parameters"]["frequency_hz"],
                 summary["hydrodynamic_metrics"]["mean_thrust_fx_N_per_m"]))
    else:
        print("[!] 未找到 caseSummary，跳过更新")

    with open(html_path, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"[+] 已把 {len(frames)} 帧（每 {stride} 步一帧）回写进 {html_path} "
          f"({len(html)/1024/1024:.2f} MB)")
    return html_path


def run_continuous_simulation(t_end=T_END_DEFAULT, num_steps=None, freq=FREQ_DEFAULT,
                              u_inf=U_INF_DEFAULT, length=LENGTH_DEFAULT,
                              dt=DT_DEFAULT, n_side=N_SIDE_DEFAULT,
                              pressure_unit=PRESSURE_UNIT_DEFAULT,
                              boundary_layer=BL_DEFAULT,
                              bl_probe_depth=BL_DEPTH_DEFAULT,
                              bl_Re=BL_RE_DEFAULT, bl_model=BL_MODEL_DEFAULT):
    """
    运行连续非定常流场时序求解全流程（二维）
    :param t_end: 仿真终止时间 (s)
    :param num_steps: 时间步数；None 时按 dt 自动算（t = 0, dt, 2dt, ...）
    :param freq: 鱼体摆动频率 (Hz)
    :param u_inf: 来流速度 (m/s)
    :param length: 弦长 (m)
    :param dt: 时间步长 (s)
    :param n_side: 每面条轮廓点数（共 2*n_side 个探针）
    :param pressure_unit: 'Pa' 有量纲，或 'kinematic'（ρU² 单位 = Pa/ρ），
                          后者对应无量纲化 CFD（L=1, U=1, ρ=1）的输出约定
    """
    model = UnsteadyFishModel(length=length, n_side=n_side)
    solver = UnsteadyPanelSolver(rho=1000.0, u_inf=u_inf,
                                 pressure_unit=pressure_unit,
                                 boundary_layer=boundary_layer,
                                 bl_probe_depth=bl_probe_depth,
                                 bl_Re=bl_Re, bl_model=bl_model,
                                 x0=model.x0)

    if num_steps is None:
        time_array = np.arange(0.0, t_end + 1e-12, dt)
    else:
        time_array = np.linspace(0.0, t_end, num_steps)

    records = []
    cycle_forces = []
    n_probe = 2 * n_side
    nstep = len(time_array)

    # 预分配结果数组（比逐步构造 40 万个 dict 快得多）
    COLS = ["time_step", "time", "point_id", "x", "y", "z",
            "nx", "ny", "nz", "u_x", "u_y", "u_z", "pressure", "cp"]
    rec = np.zeros((nstep * n_probe, 14), dtype=np.float64)
    # 高精度副本，只用于导出老师格式表（TSV）。
    # CSV 沿用原程序的舍入口径（压强 3 位小数）；TSV 是要和老师数据逐行对比的，
    # 老师数据保留 ~15 位有效数字，所以 TSV 用未舍入值。
    rec_hi = np.zeros((nstep * n_probe, 14), dtype=np.float64)

    print(f"[*] 开始连续时序仿真(二维): 总时长 {t_end}s, dt={dt}s, 步数 {nstep}, "
          f"频率 {freq}Hz, 来流 {u_inf}m/s, 弦长 {length}m, 探针 {n_probe} 个...")

    # 预热一步（t = -dt，不记录）：让 t = 0 处就有上一时刻的势，
    # 否则第 0 步的 ∂Φ/∂t 只能取 0，非定常项缺失、压强不完整。
    warm_state = model.generate_surface_state(-dt, u_inf=u_inf, freq=freq)
    solver.step(-dt, warm_state)

    for step_idx, t in enumerate(time_array):
        # 1. 动网格状态更新（几何、法线、线元长度、物面瞬时速度）
        panel_state = model.generate_surface_state(t, u_inf=u_inf, freq=freq)

        # 2. 求解非定常表面速度场与压强场（无穿透 + 库塔条件 + 非定常伯努利）
        flow_results = solver.step(t, panel_state)

        # 3. 面元中点上的量平均到顶点，再按老师表格的探针顺序排列
        px, py, pp = _probe_arrays(panel_state, flow_results["pressure"])
        _, _, pcp = _probe_arrays(panel_state, flow_results["cp"])
        _, _, pux = _probe_arrays(panel_state, flow_results["v_total"][:, 0])
        _, _, puy = _probe_arrays(panel_state, flow_results["v_total"][:, 1])
        pnx, pny = _probe_normals(panel_state)

        cycle_forces.append(flow_results["total_force"])

        # 4. 写入预分配数组
        #    注意：**不做 np.round** —— CSV 是主数据文件，舍入会永久损失精度。
        #    老师格式的 TSV 由 export_probe_table 单独按约定位数格式化。
        b = step_idx * n_probe
        s = slice(b, b + n_probe)
        rec[s, 0] = step_idx
        rec[s, 1] = float(t)
        rec[s, 2] = np.arange(n_probe)
        rec[s, 3] = px
        rec[s, 4] = py
        rec[s, 5] = 0.0
        rec[s, 6] = pnx                      # 真实物面外法向 x 分量
        rec[s, 7] = pny                      # 真实物面外法向 y 分量
        rec[s, 8] = 0.0                      # 二维数据，法向 z 分量恒为 0
        rec[s, 9] = pux
        rec[s, 10] = puy
        rec[s, 11] = 0.0
        rec[s, 12] = pp
        rec[s, 13] = pcp
        # 高精度副本（TSV 用）
        rec_hi[s, 0] = step_idx
        rec_hi[s, 1] = round(float(t), 6)
        rec_hi[s, 2] = np.arange(n_probe)
        rec_hi[s, 3] = px
        rec_hi[s, 4] = py
        rec_hi[s, 6] = pnx
        rec_hi[s, 7] = pny
        rec_hi[s, 8] = 0.0
        rec_hi[s, 9] = pux
        rec_hi[s, 10] = puy
        rec_hi[s, 12] = pp
        rec_hi[s, 13] = pcp

    # 5. 导出全时序 4D 数据集 (CSV 格式)
    df = pd.DataFrame(rec, columns=COLS)
    df["time_step"] = df["time_step"].astype(int)
    df["point_id"] = df["point_id"].astype(int)
    csv_filename = "surface_flow_timeseries.csv"
    df.to_csv(csv_filename, index=False)
    print(f"[+] 连续表面流场时序数据已成功导出: {csv_filename} (总点数: {len(df)})")

    # 5b. 导出老师格式的探针表 (TSV)——用高精度副本
    probe_file = export_probe_table(rec_hi, path="probe_table.tsv", n_probe=n_probe,
                                    freq=freq, u_inf=u_inf,
                                    length=length, dt=dt, n_side=n_side)
    print(f"[+] 老师格式探针表已导出: {probe_file}")

    # 5c. 把本次结果回写进离线看板（同时同步 caseSummary）
    embed_into_html(df, u_inf=u_inf, t_end=t, dt=dt, freq=freq,
                    length=length, pressure_unit=pressure_unit)

    # 6. 计算并导出动力学指标总结（二维下力是单位展向厚度，N/m）
    forces = np.array(cycle_forces)
    summary = {
        "simulation_parameters": {
            "dimensionality": "2D",
            "t_end": t_end,
            "dt_s": dt,
            "steps": len(time_array),
            "frequency_hz": freq,
            "u_inf": u_inf,
            "chord_m": length,
            "probes": n_probe,
            "pressure_unit": pressure_unit,
            "pressure_unit_note": (
                "无量纲化 CFD 约定 (L=1, U=1, rho=1)：压强单位为 ρU²，"
                "数值 = Pa/1000。对应论文 IBAMR 的输出约定。"
                if pressure_unit == 'kinematic' else
                "有量纲：压强单位 Pa。")
        },
        "hydrodynamic_metrics": {
            "note": ("二维结果，力为单位展向厚度的力（%s 单位）"
                     % ("ρU²L" if pressure_unit == 'kinematic' else "N/m")),
            "mean_thrust_fx": float(np.mean(forces[:, 0])),
            "max_lateral_force_fy": float(np.max(np.abs(forces[:, 1]))),
            "rms_lateral_force_fy": float(np.sqrt(np.mean(forces[:, 1] ** 2)))
        }
    }

    with open("case_summary.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=4, ensure_ascii=False)
    with open("unsteady_case_summary.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=4, ensure_ascii=False)

    print("[+] 动力学时域积分汇总已保存至: case_summary.json 与 unsteady_case_summary.json")
    return df, summary


if __name__ == "__main__":
    run_continuous_simulation()

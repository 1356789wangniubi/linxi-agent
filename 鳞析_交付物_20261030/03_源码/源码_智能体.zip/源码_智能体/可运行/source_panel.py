"""
source_panel.py - 非定常**二维**源面元势流求解器

与三维版的区别
--------------
原版用三维点源核  v = σ·A·r/(4π|r|³) 并硬写对角元 0.5，实测非对角项可达对角项的
36 倍（矩阵失真），势的自项还因 dist→1e-9 而奇异（压强成 1e12 Pa 量级）。
本版改成**二维线段源面元的解析积分核**（Hess-Smith 常源面元法）：

    单位源密度在 P 点的诱导速度（面元局部坐标，A 在 l=0、B 在 l=L）：
        u_l = ln(r1/r2) / (2*pi)
        v_l = (theta2 - theta1) / (2*pi)
    单位源密度在 P 点的速度势：
        Phi = (1/2pi) * ∫ ln r dl
            = [ 0.5*(u*ln(u^2+yl^2) - 2u) + yl*(theta2-theta1) ] / (2*pi)
              (u 从 xl-L 积到 xl)

归一化约定（已在解析圆柱上校验到 1e-14）
    A[i,j] = 诱导速度 · n_i        —— 不乘面元长度
    物面速度 = U_inf + Σ_j v_ij σ_j + 0.5 σ_i n_i
    物面势   = U_inf·x + Σ_j Φ_ij σ_j
    自面元的势是**有限值**（二维的 ln r 可积），无需特殊处理。

非定常伯努利与 ∂Φ/∂t
    p - p_inf = -rho * (∂Φ/∂t + 0.5|V|^2 - 0.5|U_inf|^2)
    面元随鱼体运动，同一索引上的差分是物质导数 DΦ/Dt，需换算：
        ∂Φ/∂t = DΦ/Dt - V_surf · ∇Φ ,   ∇Φ = V_total
"""

import numpy as np


def verts_tangent(verts, nxt, i):
    """第 i 个面元的单位切向量 (tx, ty)。"""
    sx, sy = nxt[i, 0] - verts[i, 0], nxt[i, 1] - verts[i, 1]
    L = float(np.hypot(sx, sy)) or 1.0
    return sx / L, sy / L


class UnsteadyPanelSolver:
    def __init__(self, rho=1000.0, u_inf=1.0, pressure_unit='Pa',
                 boundary_layer=None, bl_probe_depth=5.0e-4, bl_Re=1.0e6,
                 bl_model='laminar', x0=2.0):
        """
        初始化非定常面元法求解器
        :param rho: 流体密度 (kg/m^3, 水默认 1000.0)
        :param u_inf: 远场未扰动来流速度大小 (m/s)
        :param pressure_unit: 'Pa' 有量纲；'kinematic' 用 ρU² 单位（= Pa/rho），
                              对应无量纲化 CFD（L=1, U=1, rho=1）的输出约定
        :param boundary_layer: None 关闭；'laminar'/'turbulent' 开启边界层修正
        :param bl_probe_depth: 探针离壁距离 [m]
        :param bl_Re: 以弦长为基准的雷诺数
        :param x0: 吻端 x 坐标（算顺流距离用）
        """
        self.rho = rho
        self.pressure_unit = pressure_unit
        self.p_scale = 1.0 if pressure_unit == 'kinematic' else float(rho)
        self.boundary_layer = boundary_layer
        self.bl_probe_depth = float(bl_probe_depth)
        self.bl_Re = float(bl_Re)
        self.bl_model = bl_model or 'laminar'
        self.x0 = float(x0)
        self.u_inf = np.array([u_inf, 0.0, 0.0])
        self.prev_phi = None
        self.prev_t = None
        self._yl_sign = None      # 涡势的 atan2 分支取向（第一步冻结）

    # ------------------------------------------------------------------
    def _bl_lambda(self, mid):
        """边界层滑移因子 λ(x) = f(d/δ(x))，逐面元。"""
        x = np.maximum(mid[:, 0] - self.x0, 1e-6)
        Rex = max(self.bl_Re, 1.0) * x
        if self.bl_model == 'laminar':
            delta = 5.0 * x / np.sqrt(Rex)
        else:
            delta = 0.37 * x / Rex ** 0.2
        eta = np.maximum(self.bl_probe_depth, 0.0) / np.maximum(delta, 1e-30)
        if self.bl_model == 'laminar':
            lam = np.where(eta >= 1.0, 1.0, np.sin(0.5 * np.pi * eta))
        else:
            lam = np.clip(eta, 0.0, 1.0) ** (1.0 / 7.0)
        return np.clip(lam, 0.0, 1.0)

    # ------------------------------------------------------------------
    # 二维线段源面元的解析核（矢量化）
    # ------------------------------------------------------------------
    @staticmethod
    def _kernels(mid, verts, nxt, yl_sign=None):
        """返回逐面元的诱导速度影响 (N,N,3) 与势影响 (N,N)。

        全部按"单位源密度"计（不乘面元长度），与解析圆柱校验通过的约定一致。
        yl_sign : (N,N) 分支取向（±1）。给定后势的 atan2 分支不再随时间翻转。
        """
        P = mid[:, None, :]                     # (N,1,3) 场点
        A = verts[None, :, :]                   # (1,N,3) 面元起点
        B = nxt[None, :, :]                     # (1,N,3) 面元终点
        seg = nxt - verts
        L = np.linalg.norm(seg, axis=1)         # (N,)
        tx = seg[:, 0] / L
        ty = seg[:, 1] / L

        d = P - A                               # (N,N,3)
        xl = d[..., 0] * tx[None, :] + d[..., 1] * ty[None, :]
        yl = -d[..., 0] * ty[None, :] + d[..., 1] * tx[None, :]
        Lb = L[None, :]
        xlm = xl - Lb

        # --- 优化：把超越函数调用从 11 次/面元对降到 6 次 ---
        # 原写法分别算了 sqrt(r1), sqrt(r2), log(r1/r2), log(r1^2), log(r2^2)
        # 以及涡势的两个 log；这里统一用 log(r) 复用：
        #     log(r^2) = 2*log(r) ,  log(r1/r2) = log(r1) - log(r2)
        # 并且因为 |yl_w| = |yl|（冻结分支时 yl_w = sign*|yl|），
        #     log(u^2 + yl_w^2) = log(r^2) 也可以复用。
        r1sq = xl * xl + yl * yl
        r2sq = xlm * xlm + yl * yl
        lr1 = 0.5 * np.log(np.maximum(r1sq, 1e-28))     # = log(r1)
        lr2 = 0.5 * np.log(np.maximum(r2sq, 1e-28))     # = log(r2)
        th1 = np.arctan2(yl, xl)
        th2 = np.arctan2(yl, xlm)

        two_pi = 2.0 * np.pi
        u_l = (lr1 - lr2) / two_pi
        v_l = (th2 - th1) / two_pi
        txn = tx[None, :]
        tyn = ty[None, :]
        vx = u_l * txn - v_l * tyn
        vy = u_l * tyn + v_l * txn
        ind_v = np.empty(xl.shape + (3,))
        ind_v[..., 0] = vx
        ind_v[..., 1] = vy
        ind_v[..., 2] = 0.0

        # 势： ∫ ln r dl = 0.5*[u*ln(u^2+yl^2) - 2u] + yl*(th2-th1)
        logterm = (xl * lr1 - xlm * lr2) - (xl - xlm)
        phi = (logterm + yl * (th2 - th1)) / two_pi

        # 涡面元 = 源在局部系旋转 +90°：(u_l, v_l) -> (-v_l, u_l)
        wx = -v_l * txn - u_l * tyn
        wy = -v_l * tyn + u_l * txn
        ind_w = np.empty(xl.shape + (3,))
        ind_w[..., 0] = wx
        ind_w[..., 1] = wy
        ind_w[..., 2] = 0.0

        # 涡的势： (1/2pi) * ∫ theta dl
        #   ∫theta du = u*atan2(yl,u) + (yl/2)*ln(u^2+yl^2)
        # 【关键】atan2 在 (yl≈0, u<0) 处有分支切割。鱼体表面是闭合曲线，
        # 场点相对于别的面元的 yl 会随摆动**穿过零**（实测元素 (265,270) 的
        # yl 从 -2.6e-6 涨到 +8.1e-5），一穿就跳 2*pi*u，除以 dt 后制造出
        # 巨大的伪 ∂Φ/∂t（压强逐步骤跳 ±5000 Pa）。
        # yl 的符号本身就是几何侧别（n·(P-A) ≡ -yl），没有独立判据可以定侧，
        # 所以正确做法是**冻结分支取向**：数学表达式里那个不连续是表示上的
        # 假象，物理上的表面势并不跳。yl_sign 由第一步的几何确定后全程沿用。
        if yl_sign is None:
            yl_w = np.where(np.abs(yl) < 1e-12, 1e-12, yl)
        else:
            yl_w = yl_sign * np.abs(yl)
            yl_w = np.where(np.abs(yl_w) < 1e-12, 1e-12, yl_w)
        th1w = np.arctan2(yl_w, xl)
        th2w = np.arctan2(yl_w, xlm)
        # F(xl) - F(xlm) = xl*th1w - xlm*th2w + 0.5*yl_w*(ln r1^2 - ln r2^2)
        #                = xl*th1w - xlm*th2w + yl_w*(lr1 - lr2)
        phi_w = (xl * th1w - xlm * th2w + yl_w * (lr1 - lr2)) / two_pi

        return ind_v, phi, ind_w, phi_w, yl

    @staticmethod
    def _n_side(state):
        return len(state["x"])

    @staticmethod
    def _te_panels(verts):
        """尾缘两侧的面元编号（a 在尾缘之前，b 在之后）。尾缘 = x 最大处。"""
        xs = verts[:, 0]
        xmax = xs.max()
        idx = np.where(xs > xmax - 1e-7)[0]
        i1, i2 = int(idx[0]), int(idx[-1])
        return (i1 - 1) % len(xs), i2

    def _influence(self, mid, verts, nxt, normals, kutta=False, yl_sign=None):
        ind_v, phi, ind_w, phi_w, yl = self._kernels(mid, verts, nxt, yl_sign)
        A = ind_v[..., 0] * normals[:, None, 0] + ind_v[..., 1] * normals[:, None, 1]
        np.fill_diagonal(A, 0.5)
        idx = np.arange(len(mid))
        ind_v[idx, idx, :] = 0.0
        if not kutta:
            return A, ind_v, phi, yl
        AW = ind_w[..., 0] * normals[:, None, 0] + ind_w[..., 1] * normals[:, None, 1]
        # 自面元的涡项在法向投影上为 0，这里显式清零以消除浮点残差；
        # 速度重建时也按同样的约定（自项不计入），保持矩阵与重建自洽。
        idx = np.arange(len(mid))
        ind_w[idx, idx, :] = 0.0
        return A, ind_v, phi, AW, ind_w, phi_w, yl

    # ------------------------------------------------------------------
    # 单步推进
    # ------------------------------------------------------------------
    def step(self, t, panel_state, kutta=True):
        """
        单时间步迭代推进求解
        :param t: 当前时刻 (s)
        :param panel_state: 来自 fish_model 的动网格状态字典
        :param kutta: True 时加库塔条件（源 + 涡面元，引入环量）。
                      老师几何的尾缘半厚度只有 1.26 mm，在无环量势流里是**真奇点**：
                      不解库塔条件时 |V| 最大会到 7.7 m/s、压强到 -2.9e4 Pa。
        :return: flow_results 包含流场总速度、动压强、压力系数与瞬时水动力合力
        """
        mid = panel_state["collocation"]
        normals = panel_state["normals"]
        lens = panel_state["areas"]          # 二维下为线元长度
        v_surf = panel_state["v_surf"]
        verts_all = panel_state["vertices"]  # (N+1, 1, 3)
        N = len(mid)

        verts = verts_all[:-1, 0, :]
        nxt = verts_all[1:, 0, :]

        # 1. 非定常动边界无穿透相容性条件:
        #    (U_inf + V_ind)·n = V_surf·n   =>   V_ind·n = (V_surf - U_inf)·n
        rhs = np.sum((v_surf - self.u_inf) * normals, axis=-1)

        # 2. 组装并求解面元线性代数方程组
        #    分支取向 yl_sign 在第一次求解时由当前几何确定，之后全程沿用，
        #    避免 yl 穿过零时 atan2 分支翻转制造出虚假的 ∂Φ/∂t 尖峰。
        if self._yl_sign is None:
            _, _, _, _, yl0 = self._kernels(mid, verts, nxt)
            self._yl_sign = np.where(yl0 >= 0.0, 1.0, -1.0)
        if not kutta:
            A, ind_v, phi_matrix, _ = self._influence(mid, verts, nxt, normals,
                                                      yl_sign=self._yl_sign)
            sigma = np.linalg.solve(A, rhs)
            gamma = 0.0
            v_ind = np.einsum("ijk,j->ik", ind_v, sigma)
            phi_induced = phi_matrix @ sigma
        else:
            A, ind_v, phi_matrix, AW, ind_w, phi_w, _ = self._influence(
                mid, verts, nxt, normals, kutta=True, yl_sign=self._yl_sign)
            a, b = self._te_panels(verts)
            ta, tb = verts_tangent(verts, nxt, a), verts_tangent(verts, nxt, b)
            # 未知量 [sigma_0..sigma_{N-1}, gamma]
            big = np.zeros((N + 1, N + 1))
            big[:N, :N] = A
            big[:N, N] = AW.sum(axis=1)
            # 库塔条件：尾缘两侧切向速度大小相等（轮廓方向相反，故相加为 0）
            rowk = np.zeros(N + 1)
            for j in range(N):
                rowk[j] = (ind_v[a, j, 0] * ta[0] + ind_v[a, j, 1] * ta[1]
                           + ind_v[b, j, 0] * tb[0] + ind_v[b, j, 1] * tb[1])
            rowk[N] = (ind_w[a, :, 0] * ta[0] + ind_w[a, :, 1] * ta[1]
                       + ind_w[b, :, 0] * tb[0] + ind_w[b, :, 1] * tb[1]).sum()
            big[N, :] = rowk
            big_rhs = np.zeros(N + 1)
            big_rhs[:N] = rhs
            ux, uy = self.u_inf[0], self.u_inf[1]
            big_rhs[N] = -(ux * ta[0] + uy * ta[1] + ux * tb[0] + uy * tb[1])
            sol = np.linalg.solve(big, big_rhs)
            sigma = sol[:N]
            gamma = float(sol[N])
            v_ind = np.einsum("ijk,j->ik", ind_v, sigma) + gamma * ind_w.sum(axis=1)
            phi_induced = phi_matrix @ sigma + gamma * (phi_w.sum(axis=1))

        # 3. 体表总流体速度 = U_inf + 其他面元诱导 + 自面元 0.5*sigma*n
        v_self = 0.5 * sigma[:, None] * normals
        v_total = self.u_inf + v_ind + v_self          # 势流速度（= ∇φ）

        # 4. 速度势 Phi = U_inf·x + Σ Φ_ij σ_j (+ gamma 涡项)
        phi_total = mid @ self.u_inf + phi_induced

        # 5. ∂Phi/∂t：面元随鱼体运动，同一索引差分给出 DPhi/Dt，需换算到空间固定点
        #    ⚠ 必须用**势流速度** v_total（φ 是势流的势，∇φ = v_total），
        #      所以边界层修正放在这一步**之后**。
        dphi_dt = np.zeros(N)
        if self.prev_phi is not None and self.prev_t is not None:
            dt = t - self.prev_t
            if dt > 1e-12:
                dphi_dt = (phi_total - self.prev_phi) / dt
                dphi_dt = dphi_dt - np.sum(v_surf * v_total, axis=-1)

        self.prev_phi = phi_total.copy()
        self.prev_t = t

        # 5b. 边界层修正：黏性 -> 无滑移 -> 物面切向速度被压低。
        #     探针在离壁 d 处，eta = d/delta(x)，
        #     v_probe = v_body + lambda(x)·(v_pot - v_body)，lambda = f(eta)。
        #     任何 lambda 都自动满足动边界条件（v_body·n 与 v_pot·n 相同）。
        if self.boundary_layer is not None:
            lam = self._bl_lambda(mid)
            v_total = v_surf + lam[:, None] * (v_total - v_surf)

        # 6. 非定常伯努利方程
        v_mag_sq = np.sum(v_total ** 2, axis=-1)
        u_inf_sq = float(np.sum(self.u_inf ** 2))
        p_dynamic = -self.p_scale * (dphi_dt + 0.5 * v_mag_sq - 0.5 * u_inf_sq)
        cp = 1.0 - (v_mag_sq / (u_inf_sq + 1e-12)) - (2.0 / (u_inf_sq + 1e-12)) * dphi_dt

        # 7. 线积分获取瞬时合力（二维下单位厚度）: dF = - p * n * dl
        force_elements = -p_dynamic[:, None] * normals * lens[:, None]
        total_force = np.sum(force_elements, axis=0)

        return {
            "v_total": v_total,
            "pressure": p_dynamic,
            "cp": cp,
            "total_force": total_force,
            "phi": phi_total,
            "sigma": sigma,
            "gamma": gamma,
        }

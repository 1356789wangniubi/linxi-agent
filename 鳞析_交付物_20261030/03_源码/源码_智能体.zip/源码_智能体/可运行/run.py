"""
run.py - 仿生鱼流场求解与可视化一键启动器 (Python 原生跨平台启动脚本)
"""

import sys
import os
import subprocess
import webbrowser
from pathlib import Path

PACKAGE_DIR = Path(__file__).resolve().parent


def wait_for_exit():
    if sys.stdin and sys.stdin.isatty():
        try:
            input("\n按回车键退出...")
        except EOFError:
            pass


def main():
    # Always run from the extracted package directory, regardless of the caller's current working directory.
    os.chdir(PACKAGE_DIR)
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except AttributeError:
            pass
    print("=" * 60)
    print("  仿生鱼连续表面非定常流场与压强场求解系统")
    print("=" * 60)
    print()

    # 1. 检查必要依赖库
    print("[1/4] 检查 Python 科学计算依赖环境...")
    missing_pkgs = []
    for pkg in ["numpy", "pandas"]:
        try:
            __import__(pkg)
        except ImportError:
            missing_pkgs.append(pkg)

    if missing_pkgs:
        print(f"[警告] 检测到缺少依赖包: {', '.join(missing_pkgs)}")
        print(f"[*] 正在自动尝试安装依赖...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", *missing_pkgs])
            print("[+] 依赖安装成功！")
        except Exception as e:
            print(f"[错误] 自动安装依赖失败: {e}")
            print(f"请手动运行: pip install {' '.join(missing_pkgs)}")
            wait_for_exit()
            return 1
    else:
        print("[+] 依赖检查通过 (numpy, pandas)")

    # 2. 运行物理机理与边界相容性自检
    print("\n[2/4] 执行物理机理与动边界相容性自检 (verify_package.py)...")
    from verify_package import test_unsteady_run, test_probe_import_contract
    try:
        test_unsteady_run()
        test_probe_import_contract()
    except Exception as e:
        print(f"[错误] 自检未通过: {e}")
        wait_for_exit()
        return 1

    # 3. 运行连续流场仿真推进与 4D 数据集导出
    print("\n[3/4] 运行连续时序流场仿真并导出 4D 数据集 (run_unsteady_pipeline.py)...")
    from run_unsteady_pipeline import (run_continuous_simulation, DT_DEFAULT,
                                       T_END_DEFAULT, FREQ_DEFAULT,
                                       U_INF_DEFAULT, LENGTH_DEFAULT)
    try:
        # 用模块里的默认参数：dt = 0.0010 s，t 从 0 起，频率 2 Hz（与老师数据对齐）
        run_continuous_simulation(t_end=T_END_DEFAULT, num_steps=None,
                                  freq=FREQ_DEFAULT, u_inf=U_INF_DEFAULT,
                                  length=LENGTH_DEFAULT, dt=DT_DEFAULT)
    except Exception as e:
        print(f"[错误] 仿真计算失败: {e}")
        wait_for_exit()
        return 1

    # 4. 打开离线交互式可视化页面（含两个视图入口）
    print("\n[4/4] 启动离线交互式可视化页面...")
    # 兼容三种位置：同目录 / 交付包的 04_界面 / 上级目录
    candidates = [
        os.path.abspath("fish_surface_offline.html"),
        os.path.abspath("主界面_流场看板.html"),
        os.path.abspath(os.path.join("..", "04_界面", "主界面_流场看板.html")),
        os.path.abspath(os.path.join("..", "..", "04_界面", "主界面_流场看板.html")),
        os.path.abspath(os.path.join("..", "..", "fish_surface_offline.html")),
    ]
    html_path = next((p for p in candidates if os.path.exists(p)), None)
    if html_path:
        webbrowser.open("file://" + html_path)
        print(f"[+] 已在默认浏览器打开: {html_path}")
        print("    顶部有两个入口：")
        print("      🔬 交互流场 —— 三维旋转查看表面流场（原有功能）")
        print("      🎬 连续动画 —— 侧视鱼体连续摆动，颜色表示速度/压强大小（新增）")
    else:
        print("[警告] 未找到可视化文件，请手动打开：")
        for p in candidates:
            print("         " + p)

    print("\n" + "=" * 60)
    print("  全流程运行成功！")
    print("  • 4D时序数据集: surface_flow_timeseries.csv")
    print("  • 老师格式探针表: probe_table.tsv（完整 1001 帧）")
    print("    └ 界面右上角「⬇ 导出老师格式表格」导出的是看板内嵌帧（201 帧）")
    print("  • 动力学指标总结: case_summary.json")
    print("  • 交互式看板: fish_surface_offline.html（🔬 交互流场 / 🎬 连续动画）")
    print("=" * 60)
    if sys.stdin and sys.stdin.isatty():
        wait_for_exit()
    return 0

if __name__ == "__main__":
    sys.exit(main())

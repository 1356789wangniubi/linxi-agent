"""
Convert a probe stream (tab-delimited or CSV) to surface_flow_timeseries.csv.

The supplied probe_fish2_stream file is a 1.94 GB, 20,200,000-row text stream.
This converter reads it row by row, so memory use does not grow with file size.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path
from typing import Dict, Optional, Sequence, Union

OUTPUT_COLUMNS = [
    "time_step", "time", "point_id", "x", "y", "z", "nx", "ny", "nz",
    "u_x", "u_y", "u_z", "pressure", "cp",
]


def _key(value: str) -> str:
    return "".join(ch for ch in value.strip().lower() if ch.isalnum())


ALIASES = {
    "time": ("time", "t"),
    "time_step": ("timestep", "step", "frame", "iteration"),
    "point_id": ("pointid", "probe", "noofprobe", "probeid", "id"),
    "x": ("x", "xcoord", "xcoordofprobe", "xcoordinate"),
    "y": ("y", "ycoord", "ycoordofprobe", "ycoordinate"),
    "z": ("z", "zcoord", "zcoordofprobe", "zcoordinate"),
    "nx": ("nx", "normalx"),
    "ny": ("ny", "normaly"),
    "nz": ("nz", "normalz"),
    "u_x": ("ux", "xvelocity", "velocityx", "u"),
    "u_y": ("uy", "yvelocity", "velocityy", "v"),
    "u_z": ("uz", "zvelocity", "velocityz", "w"),
    "pressure": ("pressure", "p", "staticpressure"),
    "cp": ("cp", "pressurecoefficient", "pressurecoef"),
}


def _column_map(header: Sequence[str]) -> Dict[str, int]:
    normalized = {_key(name): i for i, name in enumerate(header)}
    result: Dict[str, int] = {}
    for field, aliases in ALIASES.items():
        for alias in aliases:
            if alias in normalized:
                result[field] = normalized[alias]
                break
    required = ("time", "x", "y", "pressure")
    missing = [name for name in required if name not in result]
    if missing:
        raise ValueError(
            "输入文件缺少必要列: " + ", ".join(missing) +
            "; 需要 Time、X/Y 坐标和 pressure（支持原始探针表头）"
        )
    return result


def _float(row: Sequence[str], index: Optional[int], default: float = 0.0) -> float:
    if index is None or index >= len(row):
        return default
    text = row[index].strip()
    if not text:
        return default
    try:
        value = float(text)
    except ValueError:
        return default
    return value if math.isfinite(value) else default


def _int_or_float(value: float):
    return int(value) if float(value).is_integer() else value


def convert_probe_file(input_path: Union[str, Path], output_path: Union[str, Path],
                       summary_path: Optional[Union[str, Path]] = None) -> dict:
    """Stream *input_path* into the package's canonical 14-column CSV schema."""
    source = Path(input_path)
    target = Path(output_path)
    if not source.is_file():
        raise FileNotFoundError(f"输入文件不存在: {source}")
    target.parent.mkdir(parents=True, exist_ok=True)

    rows = 0
    frames = 0
    points_in_frame = 0
    current_time_key = None
    point_fallback = 0
    first_time = None
    last_time = None
    delimiter = None
    field_map: Dict[str, int] = {}

    with source.open("r", encoding="utf-8-sig", errors="replace", newline="") as src:
        first_line = src.readline()
        if not first_line:
            raise ValueError("输入文件为空")
        delimiter = "\t" if "\t" in first_line else ","
        header = next(csv.reader([first_line], delimiter=delimiter))
        field_map = _column_map(header)

        with target.open("w", encoding="utf-8", newline="") as dst:
            writer = csv.writer(dst)
            writer.writerow(OUTPUT_COLUMNS)
            reader = csv.reader(src, delimiter=delimiter)
            for row in reader:
                if not row or all(not cell.strip() for cell in row):
                    continue
                time_index = field_map["time"]
                if time_index >= len(row):
                    continue
                time_text = row[time_index].strip()
                if not time_text:
                    continue
                try:
                    time_value = float(time_text)
                except ValueError:
                    continue
                time_key = time_text
                if current_time_key is None:
                    current_time_key = time_key
                    first_time = time_value
                elif time_key != current_time_key:
                    frames += 1
                    current_time_key = time_key
                    point_fallback = 0
                    points_in_frame = 0
                last_time = time_value

                point_id = _float(row, field_map.get("point_id"), point_fallback)
                x = _float(row, field_map.get("x"))
                y = _float(row, field_map.get("y"))
                z = _float(row, field_map.get("z"))
                u_x = _float(row, field_map.get("u_x"))
                u_y = _float(row, field_map.get("u_y"))
                u_z = _float(row, field_map.get("u_z"))
                pressure = _float(row, field_map.get("pressure"))
                # Probe streams do not contain surface normals or Cp. Keep the
                # schema compatible and record those fields as zero until a
                # source with those physical quantities is supplied.
                cp = _float(row, field_map.get("cp"))
                writer.writerow([
                    frames, time_value, _int_or_float(point_id), x, y, z,
                    _float(row, field_map.get("nx")),
                    _float(row, field_map.get("ny")),
                    _float(row, field_map.get("nz")),
                    u_x, u_y, u_z, pressure, cp,
                ])
                rows += 1
                points_in_frame += 1
                point_fallback += 1

    if rows == 0:
        raise ValueError("输入文件没有可解析的数据行")
    # frames is a zero-based last frame index; convert to count.
    frame_count = frames + 1
    summary = {
        "source": str(source),
        "output": str(target),
        "delimiter": delimiter,
        "rows": rows,
        "frames": frame_count,
        "last_frame_points": points_in_frame,
        "first_time": first_time,
        "last_time": last_time,
        "columns": OUTPUT_COLUMNS,
        "notes": [
            "原始探针流没有表面法向量，因此 nx/ny/nz 和 cp 在缺失时写为 0。",
            "这保证字段兼容，不把探针数据伪装成具有完整表面法向的 CFD 面元数据。",
        ],
    }
    if summary_path is None:
        summary_path = target.with_name(target.stem + "_import_summary.json")
    with Path(summary_path).open("w", encoding="utf-8") as fp:
        json.dump(summary, fp, ensure_ascii=False, indent=2)
    return summary


def main() -> int:
    parser = argparse.ArgumentParser(description="将探针时序流式转换为标准 4D CSV")
    parser.add_argument("--input", required=True, help="原始 probe_fish2_stream 文件路径")
    parser.add_argument("--output", default="surface_flow_timeseries.csv", help="输出 CSV 路径")
    parser.add_argument("--summary", default=None, help="输出导入摘要 JSON 路径")
    args = parser.parse_args()
    summary = convert_probe_file(args.input, args.output, args.summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

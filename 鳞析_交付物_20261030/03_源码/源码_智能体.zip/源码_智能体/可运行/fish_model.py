"""
fish_model.py - 连续时空鱼体几何与运动学网格生成器（二维版）

与三维版的区别
--------------
原版把鱼体当成三维回转体（横截面为椭圆，N = nx * n_theta 个四边形面元）。
本版改成**二维闭合轮廓**（上下表面各 n_side 个点），与老师表格一致：
    - 弦长 1.0 m，x 从 2.0 到 3.0（与老师表格的 X-coord 同一坐标系，可直接对比）
    - 每面条轮廓 202 点，共 404 个探针（老师表格就是 404 个）
    - 厚度剖面 h(xc)、体波幅度包络 A(xc)、频率、相位**全部取自老师数据**（反推得到）

类名 `UnsteadyFishModel`、方法 `generate_surface_state()` 与返回字典的键
一律保持不变，只是数组退化为 z = 0 的二维情形，所以求解器与主程序无需改接口。

几何与运动学（由 `probe_fish2_stream` 精确反推，残差均 ≤ 1e-7 m）
----------------------------------------------------------------
    xc = (x - x0) / chord
    h(xc)  = 0.17813998*sqrt(xc) - 0.07559996*xc - 0.21095999*xc^2
             + 0.17057996*xc^3 - 0.06089999*xc^4            半厚度 [m]
    A(xc)  = 0.16*xc^2 - 0.08*xc + 0.02                     体波幅度 [m]
    y_c(x,t) = A(xc) * cos(2*pi*f*(t - t0) - 2*pi*xc + psi0) 弯曲中心线
    y_up = y_c + h ,  y_lo = y_c - h
    f = 2.000000 Hz ,  psi0 = 1.577080 rad ,  t0 = 0
"""

import numpy as np

# ---- 老师数据反推得到的常数 ------------------------------------------------
CHORD = 1.0                  # 弦长 [m]
X0 = 2.0                     # 吻端 x（与老师表格同一坐标系）[m]
N_SIDE = 202                 # 每面条轮廓的点数（共 404 个探针）
T0 = 0.0005                  # 相位参考时刻 [s]（老师数据的第一帧在 t=0.0005，
                             # 取这个值后本模型在任意 t 的几何与老师数据**逐点重合**）
FREQ_DEFAULT = 2.0           # 体波频率 [Hz]（老师数据实测 2.000000 Hz）
PSI0 = 1.577080              # 相位常数 [rad]（老师数据实测 1.577080）

# 厚度剖面系数（升幂，第一项配 sqrt(xc)）
H_COEF = (0.17813998, -0.07559996, -0.21095999, 0.17057996, -0.06089999)
# 体波幅度包络系数（升幂，二次）
A_COEF = (0.02, -0.08, 0.16)


def make_xc(n_side=N_SIDE, chord=CHORD):
    """归一化弦向网格 xc ∈ [0, 1]，鼻部按老师数据的比例加密。

    注意：返回**归一化坐标**（与 chord 无关），实际坐标用 `x0 + chord*xc`。
    原写法这里除了一个 chord、调用处又乘了一次 chord，导致 chord≠1 时网格长度出错。
    `chord` 形参保留仅为接口兼容，不参与计算。
    """
    base = np.concatenate([[0.0, 1.0 / 3.0], np.arange(1.0, 201.0)])   # 202 点, 0..200
    u = base / base[-1]                                                # 归一化参数 0..1
    if n_side == len(base):
        return base * 0.005                                            # 0 .. 1.0
    t = np.linspace(0.0, 1.0, n_side)
    return np.interp(t, u, base) / base[-1]


class UnsteadyFishModel:
    def __init__(self, length=CHORD, height=None, width=None,
                 nx=None, n_theta=None, n_side=N_SIDE, x0=X0):
        """
        初始化**二维**鱼体几何与离散参数。

        为兼容原三维接口，仍接受 height/width/nx/n_theta 形参，但二维版不使用它们。
        :param length: 弦长 (m)
        :param n_side: 每面条轮廓的点数（共 2*n_side 个面元/探针）
        :param x0: 吻端 x 坐标 (m)
        """
        self.L = float(length)
        self.x0 = float(x0)
        self.n_side = int(n_side)
        self.xc = make_xc(self.n_side, self.L)
        self.x = self.x0 + self.L * self.xc

    # ------------------------------------------------------------------
    # 形状与运动学
    # ------------------------------------------------------------------
    def thickness_envelope(self, x):
        """半厚度 h(xc) [m]（与时间无关）。返回数组，便于直接调用。"""
        x = np.asarray(x, dtype=float)
        xc = np.clip((x - self.x0) / self.L, 0.0, 1.0)
        s = np.sqrt(np.maximum(xc, 0.0))
        h = (H_COEF[0] * s + H_COEF[1] * xc + H_COEF[2] * xc ** 2
             + H_COEF[3] * xc ** 3 + H_COEF[4] * xc ** 4)
        return np.maximum(h, 0.0)

    def amplitude_envelope(self, xc):
        """体波幅度包络 A(xc) [m]。"""
        xc = np.asarray(xc, dtype=float)
        return A_COEF[0] + A_COEF[1] * xc + A_COEF[2] * xc ** 2

    def kinematics_displacement(self, x, t, freq=FREQ_DEFAULT, wavelength=None,
                                c1=None, c2=None):
        """弯曲中心线 y_c 与其时间导数 ∂y_c/∂t。

            y_c(x,t) = A(xc) * cos(2*pi*f*(t - t0) - 2*pi*xc + psi0)

        （老师数据实测：沿体轴相位恰好累计 -2*pi，即波长 = 1 个体长、向尾传播。）

        :return: (y_c, dy_c/dt)
        """
        x = np.asarray(x, dtype=float)
        xc = np.clip((x - self.x0) / self.L, 0.0, 1.0)
        amp = self.amplitude_envelope(xc)
        w = 2.0 * np.pi * freq
        phase = w * (t - T0) - 2.0 * np.pi * xc + PSI0
        y_c = amp * np.cos(phase)
        v_c = -amp * w * np.sin(phase)
        return y_c, v_c

    # ------------------------------------------------------------------
    # 单帧几何与动边界速度
    # ------------------------------------------------------------------
    def generate_surface_state(self, t, u_inf=1.0, freq=FREQ_DEFAULT, wavelength=None):
        """生成指定时刻 t 的**二维**鱼体表面面元状态。

        轮廓顺序（与老师表格的探针编号一致）：
            上表面 吻->尾  (n_side 点)   -> 探针 0 .. n_side-1
            下表面 尾->吻  （作为闭合轮廓的后续，逆时针）
        闭合轮廓（逆时针）为：下表面 吻->尾，再上表面 尾->吻。
        外法线取 (t_y, -t_x)，仅对逆时针围线成立。

        :return: dict，键与三维版完全一致：
            - 'collocation': 面元形心 (N, 3)，z 恒为 0
            - 'normals':     单位外法线 (N, 3)，nz 恒为 0
            - 'areas':       面元长度 (N,)，二维下即线元长度 [m]
            - 'v_surf':      物面瞬时绝对运动速度 (N, 3)，vx=vz=0
            - 'vertices':    轮廓顶点 (N+1, 1, 3)，供求解器还原面元
            - 'upper_index' / 'lower_index': 输出探针编号到面元的映射
        """
        x = self.x
        n = self.n_side
        y_c, v_c = self.kinematics_displacement(x, t, freq=freq)
        h = self.thickness_envelope(x)

        y_up = y_c + h
        y_lo = y_c - h

        # 闭合轮廓：下表面 吻->尾，再上表面 尾->吻（逆时针）
        lo = np.column_stack([x, y_lo, np.zeros(n)])
        up = np.column_stack([x, y_up, np.zeros(n)])
        # 下表面吻端点与上表面首点重合，去掉一个
        verts = np.vstack([lo, up[:0:-1]])              # (2n-1, 3)

        # 面元几何
        nxt = np.roll(verts, -1, axis=0)
        seg = nxt - verts
        lens = np.linalg.norm(seg, axis=1)
        tang = seg / lens[:, None]
        nrm = np.column_stack([tang[:, 1], -tang[:, 0], np.zeros_like(tang[:, 0])])
        mid = 0.5 * (verts + nxt)

        # 物面瞬时速度：体坐标下 x 固定，只有 y 方向运动 (0, dy/dt, 0)
        vpts_lo = np.column_stack([np.zeros(n), v_c, np.zeros(n)])
        vpts_up = np.column_stack([np.zeros(n), v_c, np.zeros(n)])
        vpts = np.vstack([vpts_lo, vpts_up[:0:-1]])     # 与 verts 同序
        v_surf = 0.5 * (vpts + np.roll(vpts, -1, axis=0))   # 面元中点的平均速度

        # 输出探针编号映射：0..n-1 = 上表面（吻->尾），n..2n-1 = 下表面（吻->尾）
        # 轮廓中：索引 0..n-1 是下表面吻->尾；索引 n-1..2n-2 是上表面尾->吻
        upper_index = np.arange(2 * n - 2, n - 2, -1)   # 上表面 尾->吻 的轮廓索引
        lower_index = np.arange(0, n)

        # 顶点表凑成 (N+1, 1, 3) 形状以便求解器还原每个面元的四个顶点逻辑
        # 二维下"四边形"退化为一条线段：用 [P1, P2, P2, P1] 表示
        quads = np.stack([verts, nxt, nxt, verts], axis=1)   # (N, 4, 3)

        return {
            "collocation": mid,
            "normals": nrm,
            "areas": lens,
            "v_surf": v_surf,
            "vertices": np.concatenate([verts, verts[:1]], axis=0)[:, None, :],
            "quads": quads,
            "upper_index": upper_index,
            "lower_index": lower_index,
            "x": x,
            "y_up": y_up,
            "y_lo": y_lo,
            "y_c": y_c,
            "v_c": v_c,
            "h": h,
        }

"""
verify_package.py - 检验连续时变流场物理机理、动边界相容性与输出接口规范
"""

import numpy as np
from pathlib import Path
from tempfile import TemporaryDirectory

from import_probe_data import convert_probe_file
from fish_model import UnsteadyFishModel
from source_panel import UnsteadyPanelSolver


def test_unsteady_run():
    print("[*] 正在执行模块物理性与接口综合自检...")

    # 1. 动网格与几何有效性检查（二维：弦长 1.0 m，上下表面各 n_side 点）
    model = UnsteadyFishModel()
    solver = UnsteadyPanelSolver(rho=1000.0, u_inf=1.0)

    t0 = 0.0
    state_0 = model.generate_surface_state(t0, u_inf=1.0, freq=2.0)
    N_panels = len(state_0["collocation"])
    assert N_panels == 2 * model.n_side - 1, \
        f"网格面元数量预期为 {2 * model.n_side - 1}，实际为 {N_panels}"
    assert np.all(state_0["areas"] > 0), "存在退化或长度非正的面元"

    # 二维轮廓必须逆时针（有向面积 > 0），否则外法线方向反了
    v = state_0["vertices"][:-1, 0, :]
    area_signed = 0.5 * np.sum(v[:, 0] * np.roll(v[:, 1], -1)
                               - np.roll(v[:, 0], -1) * v[:, 1])
    assert area_signed > 0, f"轮廓不是逆时针（有向面积 {area_signed:.3e}），外法线方向错误"

    # 2. 初始时间步求解测试
    res_0 = solver.step(t0, state_0)
    assert res_0["pressure"].shape == (N_panels,), "压强矩阵维度不匹配"
    assert res_0["v_total"].shape == (N_panels, 3), "速度矢量矩阵维度不匹配"
    assert not np.isnan(res_0["pressure"]).any(), "初时刻压强计算中出现 NaN"
    assert np.all(np.isfinite(res_0["pressure"])), "压强出现非有限数值"

    # 3. 连续时间步步进与时间导数检验
    t1 = 0.05
    state_1 = model.generate_surface_state(t1, u_inf=1.0, freq=2.0)
    res_1 = solver.step(t1, state_1)

    assert not np.isnan(res_1["pressure"]).any(), "时间步进中压强计算出现 NaN"
    assert not np.isnan(res_1["v_total"]).any(), "时间步进中流速计算出现 NaN"

    # 4. 动边界无穿透相容性条件检验: (V_fluid · n) 必须与 (V_surf · n) 严格相符
    v_norm_fluid = np.sum(res_1["v_total"] * state_1["normals"], axis=-1)
    v_norm_surf = np.sum(state_1["v_surf"] * state_1["normals"], axis=-1)
    diff = np.max(np.abs(v_norm_fluid - v_norm_surf))
    assert diff < 1e-4, f"动边界无穿透相容条件偏差过大: {diff}"
    print(f"[PASS] 动边界相容性检验通过: 最大法向速度残差 = {diff:.2e}")

    # 4b. 尖尾奇异性检验：库塔条件应让尾缘速度有限
    #     （老师几何的尾缘半厚度只有 1.26 mm，无环量势流里是真奇点，
    #       不解库塔条件时 |V| 最大会到 7.7 m/s 且随网格加密发散）
    sp = np.linalg.norm(res_1["v_total"], axis=1)
    assert sp.max() < 4.0, f"尾缘速度过大（{sp.max():.3f} m/s），库塔条件可能未生效"
    assert np.isfinite(res_1["gamma"]), "环量 gamma 非有限"
    print(f"[PASS] 库塔条件检验通过: |V|max = {sp.max():.4f} m/s, gamma = {res_1['gamma']:+.5f}")

    # 5. 动力学合力连续性检验
    f0 = res_0["total_force"]
    f1 = res_1["total_force"]
    assert np.all(np.isfinite(f0)) and np.all(np.isfinite(f1)), "水动力积分结果存在非有限数值"

    print("[PASS] 模块自检全部通过：4D动网格、非定常时间导数 dPhi/dt 及连续压强场计算正常！")


def test_probe_import_contract():
    """Exercise the same tabular header used by probe_fish2_stream."""
    # 不用 tempfile.TemporaryDirectory：它会给目录设 0o700 权限（chmod），
    # 在部分受限/沙盒环境会被拒绝，导致整个自检失败。
    # 这里改为在脚本目录下建普通子目录，用完手动清理。
    import shutil
    _base = Path(__file__).resolve().parent
    tmp_path = _base / "_verify_tmp"
    shutil.rmtree(tmp_path, ignore_errors=True)
    tmp_path.mkdir(parents=True, exist_ok=True)
    try:
        source = tmp_path / "probe_fish2_stream"
        target = tmp_path / "surface_flow_timeseries.csv"
        source.write_text(
            "No of probe\tTime\tX-coord of probe\tY-coord of probe\tpressure\tX velocity\tY velocity\n"
            "0\t0.0005\t2.0\t0.0\t39995\t0.94\t0.0\n"
            "1\t0.0005\t2.01\t0.01\t39990\t0.95\t0.01\n"
            "0\t0.0010\t2.0\t0.0\t39980\t0.93\t0.02\n",
            encoding="utf-8",
        )
        summary = convert_probe_file(source, target)
        assert summary["rows"] == 3 and summary["frames"] == 2
        header = target.read_text(encoding="utf-8").splitlines()[0]
        assert header == ",".join([
            "time_step", "time", "point_id", "x", "y", "z", "nx", "ny", "nz",
            "u_x", "u_y", "u_z", "pressure", "cp"
        ])
        print("[PASS] 探针时序导入接口与标准 14 列数据格式正常！")
    finally:
        shutil.rmtree(tmp_path, ignore_errors=True)


if __name__ == "__main__":
    test_unsteady_run()
    test_probe_import_contract()

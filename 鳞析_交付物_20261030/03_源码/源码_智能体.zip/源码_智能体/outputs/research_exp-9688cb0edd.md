# Research record exp-9688cb0edd

- 目标：extrapolation
- 假设：物理模型与 DMD 在 2.0 Hz 上是否一致？
- 参数：freq=2, t_end=1, dt=0.001, trim=24, quantity=p

## 步骤

1. **locate_data** — C:\Users\29144\Desktop\智能体\data\index_physical
2. **compare** — {'full': {'A': 0.17633098724699617, 'B': 0.0016375139181642462, 'RMSE': 1.7638591394960363, 'probes': 404}, 'trim': {'A': 0.44270882142609075, 'B': 0.0075352341264010025, 'RMSE': 1.8436166151298576, 'probes': 308}}
3. **critic** — [{'level': 'WARN', 'code': 'CUSP_DOMINANT', 'message': '全 404 A=0.176，trim 后 A=0.443；尖点探针主导，必须报 trim。'}, {'level': 'WARN', 'code': 'MODEL_FORM_GAP', 'message': 'trim 后 A=0.443 / B=0.008；这是无黏/尖点的模型形式差距，不能称“精度”。'}]

## 指标

| trim | probes | A | B | RMSE |
|---|---|---|---|---|
| 0 | 404 | 0.1763 | 0.0016 | 1.7639 |
| 24 | 308 | 0.4427 | 0.0075 | 1.8436 |

## 护栏判定

- **[WARN] CUSP_DOMINANT** — 全 404 A=0.176，trim 后 A=0.443；尖点探针主导，必须报 trim。
- **[WARN] MODEL_FORM_GAP** — trim 后 A=0.443 / B=0.008；这是无黏/尖点的模型形式差距，不能称“精度”。

## 结论

结论：物理模型与 DMD 存在模型形式差距（trim A=0.443，B=0.008）。形状可参考，绝对幅值不可当精度；必须声明 trim 与时间窗。

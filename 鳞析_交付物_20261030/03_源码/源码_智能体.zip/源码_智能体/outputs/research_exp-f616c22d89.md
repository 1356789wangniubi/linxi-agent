# Research record exp-f616c22d89

- 目标：extrapolation
- 假设：DMD（2.0 Hz 拟合）能否用于 3 Hz 的物理场？
- 参数：freq=3, t_end=1, dt=0.001, trim=24, quantity=p

## 步骤

1. **locate_data** — C:\Users\29144\Desktop\智能体\data\runs\20261027_223010_f3\index
2. **compare** — {'full': {'A': 0.2332718231605439, 'B': -0.02197145534591205, 'RMSE': 4.827808817538185, 'probes': 404}, 'trim': {'A': 0.3748424247614063, 'B': -0.022863742815194765, 'RMSE': 5.063180501613605, 'probes': 308}}
3. **critic** — [{'level': 'BLOCK', 'code': 'FREQ_MISMATCH', 'message': 'DMD 只在 2.0 Hz 上拟合；3 Hz 的 A/B 不是精度，只说明外推失败。'}, {'level': 'WARN', 'code': 'CUSP_DOMINANT', 'message': '全 404 A=0.233，trim 后 A=0.375；尖点探针主导，必须报 trim。'}, {'level': 'WARN', 'code': 'MODEL_FORM_GAP', 'message': 'trim 后 A=0.375 / B=-0.023；这是无黏/尖点的模型形式差距，不能称“精度”。'}]

## 指标

| trim | probes | A | B | RMSE |
|---|---|---|---|---|
| 0 | 404 | 0.2333 | -0.0220 | 4.8278 |
| 24 | 308 | 0.3748 | -0.0229 | 5.0632 |

## 护栏判定

- **[BLOCK] FREQ_MISMATCH** — DMD 只在 2.0 Hz 上拟合；3 Hz 的 A/B 不是精度，只说明外推失败。
- **[WARN] CUSP_DOMINANT** — 全 404 A=0.233，trim 后 A=0.375；尖点探针主导，必须报 trim。
- **[WARN] MODEL_FORM_GAP** — trim 后 A=0.375 / B=-0.023；这是无黏/尖点的模型形式差距，不能称“精度”。

## 结论

结论：不能用 DMD 处理 3 Hz 工况。DMD 的拟合频率是 2.0 Hz；当前对比（全 404 A=0.233，trim A=0.375，B=-0.023）只说明外推失败，不是模型精度。要预测新工况，只能用物理模型重算。

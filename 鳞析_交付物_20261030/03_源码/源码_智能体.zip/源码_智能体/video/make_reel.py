"""Render a short demo reel GIF from the actual artifacts.

Not a screen recording: a captioned slideshow assembled from the real numbers,
figures and pressure animation.  Output: outputs/demo_reel.gif
"""

from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs"
W, H = 800, 450
FPS = 8
SECONDS = 3.5
BG = (10, 16, 28)
CARD = (17, 28, 48)
CYAN = (56, 189, 248)
RED = (248, 113, 113)
GREEN = (52, 211, 153)
WHITE = (237, 242, 247)
MUTED = (148, 163, 184)

FONT = r"C:\Windows\Fonts\msyh.ttc"
FONT_B = r"C:\Windows\Fonts\msyhbd.ttc"


def font(size: int, bold: bool = False):
    return ImageFont.truetype(FONT_B if bold else FONT, size)


def wrap(draw: ImageDraw.ImageDraw, text: str, f, max_w: int) -> list[str]:
    lines, cur = [], ""
    for ch in text:
        if ch == "\n":
            lines.append(cur)
            cur = ""
            continue
        if draw.textlength(cur + ch, font=f) <= max_w:
            cur += ch
        else:
            lines.append(cur)
            cur = ch
    if cur:
        lines.append(cur)
    return lines


def base() -> Image.Image:
    img = Image.new("RGB", (W, H), BG)
    d = ImageDraw.Draw(img)
    d.rectangle([0, 0, W, 6], fill=CYAN)
    d.text((40, 24), "鳞析 · 仿生鱼流场方法学护栏", font=font(14), fill=MUTED)
    return img


def slide_title() -> Image.Image:
    img = base()
    d = ImageDraw.Draw(img)
    d.text((60, 130), "鳞析", font=font(76, True), fill=WHITE)
    d.text((64, 225), "仿生鱼流场 · 方法学护栏 Agent", font=font(28), fill=CYAN)
    d.text((64, 275), "本地 / 离线 / 每条结论可追溯", font=font(18), fill=MUTED)
    d.text((64, 350), "DEMO  ·  3 分钟看懂它拦住了什么", font=font(16), fill=MUTED)
    return img


def slide_problem() -> Image.Image:
    img = base()
    d = ImageDraw.Draw(img)
    d.text((50, 70), "问题不是算不出来", font=font(34, True), fill=WHITE)
    d.text((50, 115), "是算出来不敢信", font=font(34, True), fill=RED)
    items = [
        ("A 口径 0.9936，B 口径 0.8684", "混用会得相反结论"),
        ("DMD 拟合 0.98，留出测试 R² = −7.11", "它不是预测模型"),
        ("首帧 p=2015（正常 1.3）", "瞬态会吃掉所有自由度"),
    ]
    y = 190
    for a, b in items:
        d.ellipse([54, y + 6, 64, y + 16], fill=CYAN)
        d.text((78, y), a, font=font(19), fill=WHITE)
        d.text((78, y + 28), b, font=font(17), fill=MUTED)
        y += 70
    d.text((50, 400), "这些不是调参问题，是方法学问题。", font=font(17), fill=GREEN)
    return img


def slide_q1() -> Image.Image:
    img = base()
    d = ImageDraw.Draw(img)
    d.text((50, 60), "Q1｜DMD 能不能外推到 25 秒之后？", font=font(24), fill=CYAN)
    d.text((50, 100), "不能。", font=font(54, True), fill=RED)
    lines = [
        "留出测试平均 R² = −7.11（p −1.18 / u_x −17.93 / u_y −2.21）",
        "换 10–1200 任何阶数都一样",
        "要预测新工况 → 物理模型（0.61，可重算）",
        "DMD 是压缩，不是预测。",
    ]
    y = 190
    for t in lines:
        d.text((54, y), "·", font=font(20), fill=CYAN)
        d.text((74, y), t, font=font(18), fill=WHITE)
        y += 46
    return img


def slide_q2() -> Image.Image:
    img = base()
    d = ImageDraw.Draw(img)
    d.text((50, 60), "Q2｜p 的 R² 都 0.99 了，为什么还不准？", font=font(24), fill=CYAN)
    d.text((50, 100), "形状对 ≠ 幅值对", font=font(40, True), fill=WHITE)
    rows = [
        ("A", "逐帧空间相关²（形状，尺度不变）", "0.9936"),
        ("B", "1−SSE/SST（绝对，敏感于幅值）", "0.8684"),
        ("RMSE", "绝对偏差", "1.81"),
    ]
    y = 190
    for k, desc, v in rows:
        d.text((54, y), k, font=font(20, True), fill=CYAN)
        d.text((140, y), desc, font=font(17), fill=WHITE)
        d.text((640, y), v, font=font(20, True), fill=RED if k == "B" else GREEN)
        y += 54
    d.text((54, 380), "只报一个 R²，就是不合格。", font=font(18), fill=GREEN)
    return img


def slide_q3() -> Image.Image:
    img = base()
    d = ImageDraw.Draw(img)
    d.text((50, 60), "Q3｜u_x 为什么卡在 0.83？", font=font(24), fill=CYAN)
    d.text((50, 100), "不是物理极限，是参数卡死", font=font(30, True), fill=WHITE)
    lines = [
        "标准 DMD 模态 ≤ 404；Hankel(d=12) → 1790",
        "nmodes ≤ 0.6K；rr_cap = nmodes；ridge = 1e-9",
        "振幅 b 用联合最小二乘（不是首帧/逐模态）",
        "排查顺序：K → nmodes → rr_cap → ridge → b",
    ]
    y = 180
    for t in lines:
        d.text((54, y), "·", font=font(20), fill=CYAN)
        d.text((74, y), t, font=font(18), fill=WHITE)
        y += 48
    return img


def slide_physical() -> Image.Image:
    img = base()
    d = ImageDraw.Draw(img)
    d.text((50, 60), "物理模型：换了频率也能跑", font=font(28), fill=WHITE)
    pic = Image.open(OUT / "field_3hz.png").convert("RGB")
    pic.thumbnail((620, 220))
    img.paste(pic, (50, 110))
    d.text((50, 350), "3 Hz / 1 s / 1,001 帧 / 216 s", font=font(18), fill=CYAN)
    d.text((50, 378), "与 DMD 对比 A=0.375、B=−0.023：频率不同，只作外推演示", font=font(15), fill=MUTED)
    d.text((50, 404), "可运行包输出与交付包物理表逐位相同。", font=font(15), fill=GREEN)
    return img


def slide_report() -> Image.Image:
    img = base()
    d = ImageDraw.Draw(img)
    d.text((50, 60), "每条结论，都能点到证据", font=font(28), fill=WHITE)
    pic = Image.open(OUT / "figs" / "overview.png").convert("RGB")
    pic.thumbnail((620, 230))
    img.paste(pic, (50, 105))
    d.text((50, 350), "15/15 方法学路由", font=font(18), fill=CYAN)
    d.text((50, 378), "查询 3–5 ms；报告 2.7 s", font=font(18), fill=CYAN)
    d.text((50, 406), "ev-* 证据链：结论 → 实验 → 数据", font=font(15), fill=MUTED)
    return img


def slide_close() -> Image.Image:
    img = base()
    d = ImageDraw.Draw(img)
    d.text((55, 120), "别的队伍让 AI 回答问题", font=font(30), fill=MUTED)
    d.text((55, 175), "我们让 AI 把一次研究做对", font=font(34, True), fill=WHITE)
    d.text((55, 225), "并且每一步都能查。", font=font(34, True), fill=CYAN)
    d.text((55, 320), "鳞析 · fishflow-guard", font=font(20), fill=GREEN)
    d.text((55, 352), "本地离线  ·  会拒绝  ·  可追溯", font=font(16), fill=MUTED)
    return img


def main() -> None:
    slides = [
        slide_title(),
        slide_problem(),
        slide_q1(),
        slide_q2(),
        slide_q3(),
        slide_physical(),
        slide_report(),
        slide_close(),
    ]
    per = int(FPS * SECONDS)
    frames = []
    total = per * len(slides)
    for si, s in enumerate(slides):
        for k in range(per):
            im = s.copy()
            d = ImageDraw.Draw(im)
            # progress bar
            d.rectangle([0, H - 4, W, H], fill=(30, 41, 59))
            d.rectangle([0, H - 4, int(W * (si * per + k + 1) / total), H], fill=CYAN)
            frames.append(im)

    out = OUT / "demo_reel.gif"
    frames[0].save(
        out,
        save_all=True,
        append_images=frames[1:],
        duration=int(1000 / FPS),
        loop=0,
        optimize=True,
    )
    print(out, round(out.stat().st_size / 1e6, 2), "MB", len(frames), "frames")


if __name__ == "__main__":
    main()

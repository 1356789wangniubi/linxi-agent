# 视频生成说明

## 产物

| 文件 | 说明 |
|---|---|
| `outputs/demo_reel.gif` | 28 s，8 页，800×450，0.8 MB，最通用 |
| `outputs/demo_reel.avi` | 28 s，MJPEG，8.4 MB，Windows 上用 VLC/PotPlayer 最稳 |
| `outputs/demo_reel.mp4` | 同内容，MJPEG-in-MP4（不是 H.264） |

## 怎么生成的

```powershell
python video/make_reel.py     # 画 8 页 -> GIF + outputs/reel_frames/*.png
python video/make_video.py    # PNG -> JPEG -> 手写 AVI(MJPEG) -> MP4 封装
```

- `make_reel.py`：Pillow 画幻灯片，数字全部来自 `BENCHMARK.md` / `RUN_INTEGRATION.md`；
- `make_video.py`：不依赖 ffmpeg 也能写出 AVI；
  如果找到 ffmpeg，会额外把 AVI 重新封装成 MP4。

## 为什么 MP4 不是 H.264

本机可用的 ffmpeg 是 QQBrowser 自带的最小构建：

```
--enable-encoder='aac,mp3,flac,mjpeg,png,bmp'
```

没有 `libx264`，所以只能 MJPEG。PowerPoint 的 `CreateVideo` 在本机返回 status=4（失败）。

## 转成 H.264（在另一台机器/装了完整 ffmpeg 的机器上）

```powershell
ffmpeg -i demo_reel.avi -c:v libx264 -crf 20 -pix_fmt yuv420p -movflags +faststart demo_h264.mp4
```

## 想换成真正的屏幕录制

按 [DEMO_SCRIPT.md](../DEMO_SCRIPT.md) 走一遍，用 OBS 或 Windows 录屏；
录完是 H.264 MP4，兼容性最好。

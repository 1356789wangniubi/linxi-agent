"""Write a real MJPEG AVI from rendered frames, then (if ffmpeg is present)
remux/transcode to MP4.

The bundled ffmpeg in this environment has no x264 encoder, so the MP4 is
MJPEG-in-MP4; the AVI is the safest universal file.
"""

from __future__ import annotations

import io
import struct
import subprocess
from pathlib import Path

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
FRAMES = ROOT / "outputs" / "reel_frames"
OUT_AVI = ROOT / "outputs" / "demo_reel.avi"
OUT_MP4 = ROOT / "outputs" / "demo_reel.mp4"

FFMPEG_CANDIDATES = [
    r"C:\Program Files\Tencent\QQBrowser\22.1.7007.400\ffmpeg\ffmpeg.exe",
    r"C:\Program Files\Tencent\QQBrowser\22.0.7003.400\ffmpeg\ffmpeg.exe",
    r"C:\Program Files\Tencent\QQBrowser\21.5.9239.400\ffmpeg\ffmpeg.exe",
]


def _chunk(fourcc: bytes, data: bytes) -> bytes:
    pad = b"\x00" if len(data) % 2 else b""
    return fourcc + struct.pack("<I", len(data)) + data + pad


def _list(kind: bytes, data: bytes) -> bytes:
    return b"LIST" + struct.pack("<I", len(data) + 4) + kind + data


def write_avi(jpegs: list[bytes], path: Path, width: int, height: int, fps: int) -> Path:
    n = len(jpegs)
    max_frame = max(len(j) for j in jpegs)

    avih = struct.pack(
        "<IIIIIIIIIIIIII",
        int(1_000_000 / fps),      # dwMicroSecPerFrame
        max_frame * fps,           # dwMaxBytesPerSec
        0,                         # dwPaddingGranularity
        0x10,                      # AVIF_HASINDEX
        n,                         # dwTotalFrames
        0,                         # dwInitialFrames
        1,                         # dwStreams
        max_frame,                 # dwSuggestedBufferSize
        width, height,
        0, 0, 0, 0,
    )

    strh = struct.pack(
        "<4s4sIHHIIIIIIIIhhhh",
        b"vids", b"MJPG",
        0,            # dwFlags
        0, 0,         # wPriority, wLanguage
        0,            # dwInitialFrames
        1, fps,       # dwScale, dwRate
        0, n,         # dwStart, dwLength
        max_frame,    # dwSuggestedBufferSize
        0xFFFFFFFF,   # dwQuality
        0,            # dwSampleSize
        0, 0, width, height,  # rcFrame
    )

    strf = struct.pack(
        "<IiiHHIIiiII",
        40, width, height, 1, 24,
        0x47504A4D,          # 'MJPG'
        width * height * 3,
        0, 0, 0, 0,
    )

    hdrl = _list(b"hdrl", _chunk(b"avih", avih) + _list(b"strl", _chunk(b"strh", strh) + _chunk(b"strf", strf)))

    header = b"RIFF" + struct.pack("<I", 0) + b"AVI " + hdrl
    movi_start = len(header)
    movi_data = b""
    idx = b""
    for j in jpegs:
        offset = (len(header) + 12 + len(movi_data)) - movi_start
        idx += struct.pack("<4sIII", b"00dc", 0x10, offset, len(j))
        movi_data += _chunk(b"00dc", j)
    movi = _list(b"movi", movi_data)
    idx1 = _chunk(b"idx1", idx)

    body = header + movi + idx1
    body = body[:4] + struct.pack("<I", len(body) - 8) + body[8:]
    path.write_bytes(body)
    return path


def _ffmpeg() -> str | None:
    for p in FFMPEG_CANDIDATES:
        if Path(p).exists():
            return p
    return None


def main() -> int:
    pngs = sorted(FRAMES.glob("frame_*.png"))
    if not pngs:
        print("no frames; run video/make_reel.py first")
        return 1
    jpegs = []
    for p in pngs:
        im = Image.open(p).convert("RGB")
        buf = io.BytesIO()
        im.save(buf, format="JPEG", quality=88, optimize=True)
        jpegs.append(buf.getvalue())
    w, h = Image.open(pngs[0]).size
    write_avi(jpegs, OUT_AVI, w, h, fps=8)
    print(f"AVI {OUT_AVI} {OUT_AVI.stat().st_size/1e6:.2f} MB ({len(jpegs)} frames)")

    ff = _ffmpeg()
    if not ff:
        print("ffmpeg not found; AVI only")
        return 0
    # validate AVI
    r = subprocess.run([ff, "-v", "error", "-i", str(OUT_AVI), "-f", "null", "-"],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    print("validate AVI rc=", r.returncode, (r.stderr or "")[:300])
    # remux MJPEG into MP4 (no re-encode)
    r = subprocess.run([ff, "-y", "-v", "error", "-i", str(OUT_AVI),
                        "-c:v", "copy", "-movflags", "+faststart", str(OUT_MP4)],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    if OUT_MP4.exists() and OUT_MP4.stat().st_size > 10000:
        print(f"MP4 {OUT_MP4} {OUT_MP4.stat().st_size/1e6:.2f} MB")
        r2 = subprocess.run([ff, "-v", "error", "-i", str(OUT_MP4), "-f", "null", "-"],
                            capture_output=True, text=True, encoding="utf-8", errors="replace")
        print("validate MP4 rc=", r2.returncode, (r2.stderr or "")[:300])
    else:
        print("MP4 remux failed:", (r.stderr or "")[:500])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

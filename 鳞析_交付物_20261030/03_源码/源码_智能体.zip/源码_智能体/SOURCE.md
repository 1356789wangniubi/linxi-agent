# 源码包说明

这个包是“鳞析 · 鱼类侧线仿真助手”的可读源码 + 示例产物。

## 包含什么

| 目录/文件 | 内容 |
|---|---|
| `fishflow/` | 全部 Python 源码（聊天、路由、工具、侧线知识、仿真、图像、物理场） |
| `.dsh/skills/fishflow-guard/` | DSH 技能 |
| `tests/` | 冒烟测试 |
| `validation/` | 自测脚本、侧线评测、试用工具包 |
| `video/` | 视频生成脚本 |
| `outputs/` | 示例图、报告、视频、仿真结果 |
| `可运行/` | 二维面元法物理模型源码（不含大 CSV/HTML） |
| `交付包/06_指标/` | 权威指标 JSON |
| `data/index_physical/` | 物理模型 1001 帧索引（约 9.5 MB） |
| `data/experiments.jsonl` | 研究记录 |
| `README.md` / `ARCHITECTURE.md` / `CHAT.md` / `START_HERE.md` | 文档 |
| `chat.bat` / `chat_lan.bat` / `public.bat` / `run_demo.bat` / `view.bat` | 启动脚本 |

## 不包含什么（体积/隐私原因）

- `data/index/`：DMD 404 探针 Parquet 索引，约 **627 MB**；需用主表重建；
- `data/runs/`：运行产物，约 110 MB；
- `交付包/02_主数据表/`：约 **1.86 GB** 原始主表；
- `可运行/probe_table.tsv`、`surface_flow_timeseries.csv`：大 CSV；
- `refs/`：参考 PDF；
- `secrets/`：智谱 key 的 DPAPI 加密文件（不打包、不外传）；
- 老师原始仿真数据（不读、不外传）。

## 跑起来

```powershell
cd 源码_智能体
python -m pip install -r requirements.txt
python -m fishflow.cli doctor
python -m fishflow.chat_server
```

浏览器打开 `http://127.0.0.1:8765/`。

> 因为没有 `data/index`，DMD 查询/压力云图/涡量工具会提示索引未建；
> 侧线知识库、引导仿真、图像轮廓、物理模型真涡量场可以直接用。

## 重建 DMD 索引

把主表放回 `交付包/02_主数据表/`，然后：

```powershell
python -m fishflow.build_index --src "交付包/02_主数据表/<主表>.tsv" --out data/index
```

约 45 秒，生成 404 个 `probe_xxxx.parquet`。

## 入口

| 文件 | 作用 |
|---|---|
| `fishflow/chat_server.py` | HTTP 服务 |
| `fishflow/chat.py` | 聊天入口/人设 |
| `fishflow/agent.py` | LLM/规则路由 + 9 个工具 |
| `fishflow/lateral_line.py` | 侧线知识库 |
| `fishflow/sim_agent.py` | 引导式正向仿真 |
| `fishflow/image_tool.py` | 鱼图 → 轮廓 → H/L |
| `fishflow/physical_field.py` | 面元速度 → 2D 网格 → 真涡量 |

## 说明

公网链接（`*.lhr.life`）是临时隧道，不在源码里；用 `public.bat` 重新生成。

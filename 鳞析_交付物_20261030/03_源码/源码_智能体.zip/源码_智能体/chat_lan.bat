@echo off
cd /d "%~dp0"
chcp 65001 >nul
set "PY=python"
where python >nul 2>nul
if errorlevel 1 set "PY=py -3"
%PY% -m fishflow.public_launcher --lan
pause

@echo off
cd /d "%~dp0"
chcp 65001 >nul
set "PY=python"
where python >nul 2>nul
if errorlevel 1 set "PY=py -3"
set "FISHFLOW_LLM_URL=https://open.bigmodel.cn/api/paas/v4/chat/completions"
set "FISHFLOW_LLM_MODEL=glm-5.3-flash"
%PY% -m fishflow.public_launcher
pause
